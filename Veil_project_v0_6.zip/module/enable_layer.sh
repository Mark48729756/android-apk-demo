#!/system/bin/sh
S=com.depthparallax/com.depthparallax.SubjectOverlayService
CUR=$(settings get secure enabled_accessibility_services)
case "$CUR" in
  *"$S"*) ;;
  ""|null) settings put secure enabled_accessibility_services "$S" ;;
  *) settings put secure enabled_accessibility_services "$CUR:$S" ;;
esac
settings put secure accessibility_enabled 1
