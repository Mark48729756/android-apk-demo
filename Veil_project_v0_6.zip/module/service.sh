#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
mkdir -p /data/adb/depthparallax
[ -f /data/adb/depthparallax/config.json ] || echo '{"strength":0.6,"smooth":0.85,"zoom":1.12,"cut":-1,"feather":0.06,"overlay":true}' > /data/adb/depthparallax/config.json
sleep 5
sh /data/adb/modules/depthparallax/enable_layer.sh
