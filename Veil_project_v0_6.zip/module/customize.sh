SKIPUNZIP=0
API=$(getprop ro.build.version.sdk)
HOS=$(getprop ro.mi.os.version.name)
ui_print "- Depth Parallax 3D"
ui_print "- Android SDK: $API  ${HOS:+HyperOS: $HOS}"
[ "$API" -lt 33 ] && abort "! Нужен Android 13+"
mkdir -p /data/adb/depthparallax
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/apply.sh 0 0 0755
set_perm $MODPATH/enable_layer.sh 0 0 0755
set_perm $MODPATH/action.sh 0 0 0755
ui_print "- Готово. Открой веб-UI модуля (KernelSU/APatch: кнопка Open, Magisk: MMRL/WebUI X)"
