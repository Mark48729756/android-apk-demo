#!/system/bin/sh
# Кнопка Action в менеджере (Magisk 28+/KernelSU/APatch) открывает меню настроек эффекта
am start --user 0 -n com.depthparallax/.SettingsActivity >/dev/null 2>&1 \
  && echo "Veil: меню настроек открыто" \
  || echo "Veil: не удалось открыть меню (перезагрузись после установки)"
