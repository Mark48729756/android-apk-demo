# Veil — Depth, redefined.
1. Залей проект на GitHub.
2. Actions -> build -> Artifacts -> Veil-module -> скачай zip.
3. Установи zip в Magisk/KernelSU/APatch, перезагрузись.
4. Открой WebUI модуля (KsuWebUI / MMRL), выбери фото, "Поставить на обои".
