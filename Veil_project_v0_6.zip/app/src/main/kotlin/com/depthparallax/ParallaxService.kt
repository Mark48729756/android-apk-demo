package com.depthparallax

import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class ParallaxService : WallpaperService() {
    override fun onCreateEngine(): Engine = E()

    inner class E : Engine() {
        private val h = Handler(Looper.getMainLooper())
        private var data: DepthData? = null
        private val verts = FloatArray((DepthData.N + 1) * (DepthData.N + 1) * 2)
        private var w = 1; private var hh = 1
        private var vis = false; private var tilting = false

        private val loop = object : Runnable {
            override fun run() { draw(); if (vis) h.postDelayed(this, 16) }
        }

        private fun load() { DepthData.get(applicationContext, w, hh)?.let { data = it } }

        private fun stopTilt() { if (tilting) { Tilt.stop(); tilting = false } }

        private fun draw() {
            val d = data ?: return
            val s = surfaceHolder
            val c = (try { s.lockHardwareCanvas() } catch (_: Exception) { s.lockCanvas() }) ?: return
            try {
                d.fill(verts)
                c.drawBitmapMesh(d.bg, DepthData.N, DepthData.N, verts, 0, null, 0, null)
            } finally { s.unlockCanvasAndPost(c) }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, f: Int, width: Int, height: Int) {
            w = width; hh = height; load(); draw()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            vis = visible
            if (visible) {
                load()
                if (!tilting) { Tilt.start(applicationContext, data?.smooth ?: 0.85f); tilting = true }
                h.post(loop)
            } else { stopTilt(); h.removeCallbacks(loop) }
        }

        override fun onDestroy() { stopTilt(); h.removeCallbacks(loop) }
    }
}
