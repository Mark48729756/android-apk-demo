package com.depthparallax

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.concurrent.thread

/**
 * Рисует вырезанный объект поверх системных часов на экране блокировки,
 * поэтому часы HyperOS визуально оказываются за объектом.
 */
class SubjectOverlayService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var view: OverlayView? = null
    private var loading = false

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_ON -> h.postDelayed({ refresh() }, 80)
                Intent.ACTION_USER_PRESENT, Intent.ACTION_SCREEN_OFF -> hide()
            }
        }
    }

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(rx, f, Context.RECEIVER_NOT_EXPORTED)
        refresh()
    }

    private fun shouldShow(): Boolean {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!km.isKeyguardLocked || !pm.isInteractive) return false
        val wmgr = WallpaperManager.getInstance(this)
        val info = try { wmgr.getWallpaperInfo(WallpaperManager.FLAG_LOCK) } catch (_: Throwable) { null } ?: wmgr.wallpaperInfo
        return info?.packageName == packageName
    }

    private fun refresh() {
        if (!shouldShow()) { hide(); return }
        if (view != null || loading) return
        val b = wm.maximumWindowMetrics.bounds
        loading = true
        thread {
            val d = DepthData.get(applicationContext, b.width(), b.height())
            h.post {
                loading = false
                if (d != null && d.overlay && view == null && shouldShow()) show(d, b.width(), b.height())
            }
        }
    }

    private fun show(d: DepthData, w: Int, hgt: Int) {
        val v = OverlayView(this, d) { if (!shouldShow()) hide() }
        val lp = WindowManager.LayoutParams(
            w, hgt, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        try { wm.addView(v, lp); view = v } catch (_: Exception) {}
    }

    private fun hide() {
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() {
        hide(); try { unregisterReceiver(rx) } catch (_: Exception) {}
        super.onDestroy()
    }

    private class OverlayView(ctx: Context, private val d: DepthData, private val check: () -> Unit) : View(ctx) {
        private val verts = FloatArray((DepthData.N + 1) * (DepthData.N + 1) * 2)
        private var frame = 0
        private val tick = object : Runnable {
            override fun run() {
                invalidate()
                if (++frame % 30 == 0) check()
                postOnAnimation(this)
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            Tilt.start(context, d.smooth)
            postOnAnimation(tick)
        }

        override fun onDetachedFromWindow() {
            removeCallbacks(tick); Tilt.stop()
            super.onDetachedFromWindow()
        }

        override fun onDraw(c: Canvas) {
            d.fill(verts)
            c.drawBitmapMesh(d.subject, DepthData.N, DepthData.N, verts, 0, null, 0, null)
        }
    }
}
