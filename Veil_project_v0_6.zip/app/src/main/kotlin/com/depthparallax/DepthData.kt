package com.depthparallax

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import org.json.JSONObject
import java.io.File

/** Общий наклон телефона: один сенсор на обои и на верхний слой, чтобы слои двигались синхронно. */
object Tilt : SensorEventListener {
    @Volatile var cx = 0f
    @Volatile var cy = 0f
    private var tx = 0f
    private var ty = 0f
    private var smooth = 0.85f
    private var users = 0
    private var sm: SensorManager? = null

    @Synchronized fun start(ctx: Context, smooth: Float) {
        this.smooth = smooth
        if (users++ == 0) {
            val m = ctx.applicationContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            sm = m
            m.registerListener(this, m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME)
        }
    }

    @Synchronized fun stop() {
        if (users > 0 && --users == 0) sm?.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        tx = (-e.values[0] / 5f).coerceIn(-1f, 1f)
        ty = ((e.values[2] / 9.8f - 0.7f) * 2f).coerceIn(-1f, 1f)
        cx += (tx - cx) * (1 - smooth)
        cy += (ty - cy) * (1 - smooth)
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}

/** Настройки эффекта (config.json в filesDir приложения). */
data class Cfg(
    var strength: Float = 0.6f, var smooth: Float = 0.85f, var zoom: Float = 1.12f,
    var cut: Float = -1f, var feather: Float = 0.06f, var overlay: Boolean = true
) {
    companion object {
        fun load(ctx: Context): Cfg {
            val c = Cfg()
            try {
                val j = JSONObject(File(ctx.filesDir, "config.json").readText())
                c.strength = j.optDouble("strength", 0.6).toFloat()
                c.smooth = j.optDouble("smooth", 0.85).toFloat()
                c.zoom = j.optDouble("zoom", 1.12).toFloat()
                c.cut = j.optDouble("cut", -1.0).toFloat()
                c.feather = j.optDouble("feather", 0.06).toFloat()
                c.overlay = j.optBoolean("overlay", true)
            } catch (_: Exception) {}
            return c
        }

        fun save(ctx: Context, c: Cfg) {
            val j = JSONObject()
            j.put("strength", c.strength.toDouble()); j.put("smooth", c.smooth.toDouble())
            j.put("zoom", c.zoom.toDouble()); j.put("cut", c.cut.toDouble())
            j.put("feather", c.feather.toDouble()); j.put("overlay", c.overlay)
            File(ctx.filesDir, "config.json").writeText(j.toString())
        }
    }
}

/** Фон + вырезанный объект (маска из карты глубины) + глубина для сетки. Кэшируется на процесс. */
class DepthData private constructor(
    val w: Int, val h: Int, val bg: Bitmap, val subject: Bitmap,
    private val depth: FloatArray, val strength: Float, val smooth: Float, val zoom: Float, val overlay: Boolean,
    private val stamp: Long
) {
    /** Заполняет сетку вершин по текущему наклону. Одинаково для обоев и верхнего слоя. */
    fun fill(verts: FloatArray) {
        val z = zoom
        val amp = w * 0.07f * strength * 2
        val cx = Tilt.cx
        val cy = Tilt.cy
        var k = 0
        for (j in 0..N) for (i in 0..N) {
            val d = depth[j * (N + 1) + i]
            verts[k++] = (i * w / N.toFloat() - w / 2f) * z + w / 2f - cx * d * amp
            verts[k++] = (j * h / N.toFloat() - h / 2f) * z + h / 2f - cy * d * amp
        }
    }

    companion object {
        const val N = 48
        private var cache: DepthData? = null

        @Synchronized
        fun get(ctx: Context, w: Int, h: Int): DepthData? {
            val dir = ctx.filesDir
            val f = File(dir, "photo.jpg"); val d = File(dir, "depth.png"); val cf = File(dir, "config.json")
            if (!f.exists() || !d.exists() || w <= 1 || h <= 1) return null
            val st = f.lastModified() + d.lastModified() + cf.lastModified()
            cache?.let { if (it.w == w && it.h == h && it.stamp == st) return it }
            return build(ctx, w, h, Cfg.load(ctx), st)?.also { cache = it }
        }

        /** Сборка без кэша (используется и для превью в настройках). */
        fun build(ctx: Context, w: Int, h: Int, cfg: Cfg, st: Long): DepthData? {
            val dir = ctx.filesDir
            val f = File(dir, "photo.jpg"); val d = File(dir, "depth.png")
            if (!f.exists() || !d.exists() || w <= 1 || h <= 1) return null
            val strength = cfg.strength; val smooth = cfg.smooth; val cut = cfg.cut; val feather = cfg.feather
            val p = BitmapFactory.decodeFile(f.path) ?: return null
            val dm = BitmapFactory.decodeFile(d.path) ?: return null
            val ar = w.toFloat() / h
            fun crop(b: Bitmap): Bitmap {
                val cw: Int; val ch: Int
                if (b.width.toFloat() / b.height > ar) { ch = b.height; cw = (ch * ar).toInt() }
                else { cw = b.width; ch = (cw / ar).toInt() }
                return Bitmap.createBitmap(b, (b.width - cw) / 2, (b.height - ch) / 2, cw, ch)
            }
            val bg = Bitmap.createScaledBitmap(crop(p), w, h, true)
            val dFull = Bitmap.createScaledBitmap(crop(dm), w, h, true)
            p.recycle(); dm.recycle()

            // глубина для сетки
            val ds = Bitmap.createScaledBitmap(dFull, N + 1, N + 1, true)
            val mp = IntArray((N + 1) * (N + 1)); ds.getPixels(mp, 0, N + 1, 0, 0, N + 1, N + 1)
            val depth = FloatArray(mp.size) { ((mp[it] shr 16) and 255) / 255f - 0.5f }

            // маска объекта
            val dp = IntArray(w * h); dFull.getPixels(dp, 0, w, 0, 0, w, h); dFull.recycle()
            val th = if (cut >= 0f) cut else otsu(dp)
            val bp = IntArray(w * h); bg.getPixels(bp, 0, w, 0, 0, w, h)
            val lo = th - feather; val hi = th + feather
            for (i in bp.indices) {
                val g = ((dp[i] shr 16) and 255) / 255f
                val t = ((g - lo) / (hi - lo)).coerceIn(0f, 1f)
                val a = (t * t * (3f - 2f * t) * 255f).toInt()
                bp[i] = (a shl 24) or (bp[i] and 0xFFFFFF)
            }
            val subject = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            subject.setPixels(bp, 0, w, 0, 0, w, h)

            return DepthData(w, h, bg, subject, depth, strength, smooth, cfg.zoom, cfg.overlay, st)
        }

        private fun otsu(px: IntArray): Float {
            val hist = IntArray(256)
            for (v in px) hist[(v shr 16) and 255]++
            val total = px.size
            var sum = 0.0; for (i in 0..255) sum += i * hist[i].toDouble()
            var sb = 0.0; var wB = 0; var best = 0.0; var th = 128
            for (i in 0..255) {
                wB += hist[i]; if (wB == 0) continue
                val wF = total - wB; if (wF == 0) break
                sb += i * hist[i].toDouble()
                val mB = sb / wB; val mF = (sum - sb) / wF
                val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
                if (v > best) { best = v; th = i }
            }
            return th / 255f
        }
    }
}
