// BR Graphics - Zygisk post-process filter for GTA:SA based mobile clients.
// Hooks eglSwapBuffers in the game's process (in memory only, no game files touched)
// and runs the finished frame through a fragment shader.
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>
#include <link.h>
#include <elf.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <cstdint>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#include <atomic>
#include <set>
#include <algorithm>
#include "zygisk.hpp"

#define TAG "BRGFX"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static const char *CONFIG_PATH = "/data/adb/br_graphics/config.ini";

// ---------------------------------------------------------------- io helpers
static bool readAll(int fd, void *buf, size_t n) {
    char *p = (char *)buf;
    while (n) { ssize_t r = read(fd, p, n); if (r <= 0) return false; p += r; n -= r; }
    return true;
}
static bool writeAll(int fd, const void *buf, size_t n) {
    const char *p = (const char *)buf;
    while (n) { ssize_t r = write(fd, p, n); if (r <= 0) return false; p += r; n -= r; }
    return true;
}
static std::string readFile(const char *path) {
    std::string out;
    FILE *f = fopen(path, "r");
    if (!f) return out;
    char b[1024]; size_t n;
    while ((n = fread(b, 1, sizeof b, f)) > 0) out.append(b, n);
    fclose(f);
    return out;
}
static std::map<std::string, std::string> parseCfg(const std::string &txt, std::vector<std::string> *pkgs) {
    std::map<std::string, std::string> m;
    size_t i = 0;
    while (i < txt.size()) {
        size_t e = txt.find('\n', i);
        if (e == std::string::npos) e = txt.size();
        std::string line = txt.substr(i, e - i);
        i = e + 1;
        while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
        if (line.empty() || line[0] == '#') continue;
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq), v = line.substr(eq + 1);
        if (k == "package") { if (pkgs) pkgs->push_back(v); }
        else m[k] = v;
    }
    return m;
}

// ---------------------------------------------------------------- companion (root)
static void companion(int fd) {
    uint32_t len = 0;
    if (!readAll(fd, &len, 4) || len > 512) return;
    std::string name(len, 0);
    if (len && !readAll(fd, &name[0], len)) return;
    std::string cfg = readFile(CONFIG_PATH);
    std::vector<std::string> pkgs;
    auto kv = parseCfg(cfg, &pkgs);
    uint8_t match = 0;
    if (kv["enabled"] != "0")
        for (auto &p : pkgs) if (!p.empty() && name.find(p) != std::string::npos) match = 1;
    writeAll(fd, &match, 1);
    if (match) {
        uint32_t cl = cfg.size();
        writeAll(fd, &cl, 4);
        writeAll(fd, cfg.data(), cl);
    }
}

// ---------------------------------------------------------------- settings
struct Settings {
    float sharp = 0.35f, bloom = 0.25f, contrast = 1.08f, saturation = 1.12f, vignette = 0.28f,
          grain = 0.02f, motionblur = 0.22f, exposure = 1.0f, warmth = 0.03f;
} S;

static bool g_dump = true;
static bool g_post = false;
static std::string g_pkg;
static bool g_patch = true;
// tunables for the in-game shader patch (config.ini keys: sh_*)
static float g_shadowMul = 2.0f, g_shadowSoft = 0.0012f, g_fogMul = 0.85f, g_envMul = 1.7f,
             g_specMul = 2.0f, g_rim = 0.15f, g_shContrast = 1.06f, g_shSat = 1.10f,
             g_shGlow = 0.10f, g_shWarm = 0.02f, g_skyBoost = 1.15f, g_sunGlow = 0.35f,
             g_skyFill = 0.35f, g_sharp = 0.5f, g_bloomP = 0.35f, g_clarity = 0.25f,
             g_filmic = 0.35f, g_grainP = 0.015f;
static bool g_postShader = true;
static int g_shadowTaps = 10;
static float g_emissive = 2.0f;
// v8: dynamic headlights (spot cones in view space, night only) and sun god rays
static float g_head = 1.0f, g_headRange = 45.0f, g_headCone = 0.80f, g_headY = -1.1f, g_headDist = 3.8f,
             g_headSep = 0.7f, g_headDark = 0.28f, g_headFwd = -1.0f;
static float g_rays = 0.40f, g_raysFov = 60.0f, g_raysDens = 0.95f;
static int g_raysTaps = 16;
static float g_ao = 0.35f, g_aoSign = 1.0f;
static float g_form = 0.25f, g_sunLight = 1.0f, g_gloss = 1.2f, g_aces = 0.5f;
static float g_sun[3] = {0, 0, 0};
static std::atomic<bool> g_sunValid{false};
// motion blur: previous frame is bound to the game's own final-pass shader (uniform brPrev / brMix)
static float g_motion = 0.25f;
static GLuint g_prevTex = 0;
static GLint g_prevW = 0, g_prevH = 0;
static EGLContext g_prevCtx = EGL_NO_CONTEXT;
static bool g_prevReady = false, g_haveFinal = false;
static thread_local bool t_lastFinal = false;

static float getf(std::map<std::string, std::string> &m, const char *k, float d) {
    auto it = m.find(k);
    return it == m.end() ? d : (float)atof(it->second.c_str());
}

// ---------------------------------------------------------------- GL post process
static const char *VS =
    "attribute vec2 aPos; varying vec2 vUV;\n"
    "void main(){ vUV = aPos*0.5+0.5; gl_Position = vec4(aPos,0.0,1.0); }\n";

static const char *FS =
    "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
    "varying vec2 vUV;\n"
    "uniform sampler2D uCur; uniform sampler2D uPrev;\n"
    "uniform vec2 uTexel; uniform float uTime;\n"
    "uniform float uSharp,uBloom,uContrast,uSat,uVig,uGrain,uMB,uExp,uWarm;\n"
    "vec3 T(vec2 p){ return texture2D(uCur,p).rgb; }\n"
    "float hash(vec2 p){ return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453); }\n"
    "void main(){\n"
    "  vec2 uv = vUV;\n"
    "  vec3 c = T(uv);\n"
    "  vec3 n=T(uv+vec2(0.0,uTexel.y)), s=T(uv-vec2(0.0,uTexel.y));\n"
    "  vec3 e=T(uv+vec2(uTexel.x,0.0)), w=T(uv-vec2(uTexel.x,0.0));\n"
    "  vec3 avg=(n+s+e+w)*0.25;\n"
    "  vec3 mn=min(c,min(min(n,s),min(e,w))), mx=max(c,max(max(n,s),max(e,w)));\n"
    "  c = clamp(c + (c-avg)*uSharp*2.0, mn-0.05, mx+0.05);\n"
    "  vec3 b = vec3(0.0);\n"
    "  vec2 r1 = uTexel*4.0, r2 = uTexel*9.0;\n"
    "  b += max(T(uv+vec2( r1.x,0.0))-0.65,0.0)+max(T(uv+vec2(-r1.x,0.0))-0.65,0.0);\n"
    "  b += max(T(uv+vec2(0.0, r1.y))-0.65,0.0)+max(T(uv+vec2(0.0,-r1.y))-0.65,0.0);\n"
    "  b += max(T(uv+r1)-0.65,0.0)+max(T(uv-r1)-0.65,0.0)+max(T(uv+vec2(r1.x,-r1.y))-0.65,0.0)+max(T(uv+vec2(-r1.x,r1.y))-0.65,0.0);\n"
    "  b += max(T(uv+vec2( r2.x,0.0))-0.65,0.0)+max(T(uv+vec2(-r2.x,0.0))-0.65,0.0);\n"
    "  b += max(T(uv+vec2(0.0, r2.y))-0.65,0.0)+max(T(uv+vec2(0.0,-r2.y))-0.65,0.0);\n"
    "  c += b*(uBloom/12.0)*2.0;\n"
    "  c = mix(c, texture2D(uPrev,uv).rgb, uMB);\n"
    "  c *= uExp;\n"
    "  c.r *= 1.0+uWarm; c.b *= 1.0-uWarm;\n"
    "  c = (c-0.5)*uContrast+0.5;\n"
    "  float l = dot(c, vec3(0.299,0.587,0.114));\n"
    "  c = mix(vec3(l), c, uSat);\n"
    "  c = clamp(c,0.0,1.0);\n"
    "  c = mix(c, c*c*(3.0-2.0*c), 0.25);\n"
    "  float d = length((uv-0.5)*vec2(1.0,0.8));\n"
    "  c *= 1.0 - uVig*smoothstep(0.30,0.85,d);\n"
    "  c += (hash(uv/uTexel*0.37+uTime)-0.5)*uGrain;\n"
    "  gl_FragColor = vec4(clamp(c,0.0,1.0),1.0);\n"
    "}\n";

struct FX {
    EGLContext ctx = EGL_NO_CONTEXT;
    GLuint prog = 0, texCur = 0, texPrev = 0;
    GLint W = 0, H = 0;
    GLint uCur = 0, uPrev = 0, uTexel = 0, uTime = 0, uSharp = 0, uBloom = 0, uContrast = 0,
          uSat = 0, uVig = 0, uGrain = 0, uMB = 0, uExp = 0, uWarm = 0;
    bool failed = false;
};
static FX fx;

static GLuint compile(GLenum type, const char *src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char log[512]; glGetShaderInfoLog(s, 512, nullptr, log); LOGE("shader: %s", log); glDeleteShader(s); return 0; }
    return s;
}
static bool initFX() {
    GLuint vs = compile(GL_VERTEX_SHADER, VS), fs = compile(GL_FRAGMENT_SHADER, FS);
    if (!vs || !fs) return false;
    fx.prog = glCreateProgram();
    glAttachShader(fx.prog, vs); glAttachShader(fx.prog, fs);
    glBindAttribLocation(fx.prog, 0, "aPos");
    glLinkProgram(fx.prog);
    GLint ok = 0; glGetProgramiv(fx.prog, GL_LINK_STATUS, &ok);
    if (!ok) { LOGE("link failed"); return false; }
#define U(n, s) fx.n = glGetUniformLocation(fx.prog, s)
    U(uCur,"uCur"); U(uPrev,"uPrev"); U(uTexel,"uTexel"); U(uTime,"uTime"); U(uSharp,"uSharp");
    U(uBloom,"uBloom"); U(uContrast,"uContrast"); U(uSat,"uSat"); U(uVig,"uVig"); U(uGrain,"uGrain");
    U(uMB,"uMB"); U(uExp,"uExp"); U(uWarm,"uWarm");
#undef U
    glGenTextures(1, &fx.texCur); glGenTextures(1, &fx.texPrev);
    fx.W = fx.H = 0;
    return true;
}
static void setupTex(GLuint t, int unit, int w, int h) {
    glActiveTexture(GL_TEXTURE0 + unit);
    glBindTexture(GL_TEXTURE_2D, t);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glCopyTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 0, 0, w, h, 0);
}

static void drawFX(EGLDisplay, int w, int h) {
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (w != fx.W || h != fx.H) {
        setupTex(fx.texCur, 0, w, h);
        setupTex(fx.texPrev, 1, w, h);
        fx.W = w; fx.H = h;
    }
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, fx.texCur);
    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, w, h);

    glDisable(GL_BLEND); glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glDisable(GL_SCISSOR_TEST); glDisable(GL_STENCIL_TEST); glDisable(GL_DITHER);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    glViewport(0, 0, w, h);
    glUseProgram(fx.prog);
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, fx.texPrev);
    glUniform1i(fx.uCur, 0); glUniform1i(fx.uPrev, 1);
    glUniform2f(fx.uTexel, 1.0f / w, 1.0f / h);
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    glUniform1f(fx.uTime, (float)(ts.tv_nsec % 1000000) / 1000000.0f);
    glUniform1f(fx.uSharp, S.sharp); glUniform1f(fx.uBloom, S.bloom);
    glUniform1f(fx.uContrast, S.contrast); glUniform1f(fx.uSat, S.saturation);
    glUniform1f(fx.uVig, S.vignette); glUniform1f(fx.uGrain, S.grain);
    glUniform1f(fx.uMB, S.motionblur); glUniform1f(fx.uExp, S.exposure);
    glUniform1f(fx.uWarm, S.warmth);
    static const GLfloat quad[] = {-1, -1, 1, -1, -1, 1, 1, 1};
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, quad);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    // keep the output as "previous frame" for motion blur
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, fx.texPrev);
    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, w, h);
}

static void renderFX(EGLDisplay dpy, EGLSurface surf) {
    if (fx.failed) return;
    EGLContext cur = eglGetCurrentContext();
    if (cur == EGL_NO_CONTEXT) return;
    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w < 64 || h < 64) return;

    // ---- save state
    GLint prog, arrBuf, elemBuf, fbo, actTex, tex0, tex1, vp[4], attr0;
    GLboolean cm[4];
    GLboolean blend = glIsEnabled(GL_BLEND), depth = glIsEnabled(GL_DEPTH_TEST),
              cull = glIsEnabled(GL_CULL_FACE), scis = glIsEnabled(GL_SCISSOR_TEST),
              sten = glIsEnabled(GL_STENCIL_TEST), dith = glIsEnabled(GL_DITHER);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prog);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &arrBuf);
    glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &elemBuf);
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &fbo);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &actTex);
    glGetIntegerv(GL_VIEWPORT, vp);
    glGetBooleanv(GL_COLOR_WRITEMASK, cm);
    glGetVertexAttribiv(0, GL_VERTEX_ATTRIB_ARRAY_ENABLED, &attr0);
    glActiveTexture(GL_TEXTURE0); glGetIntegerv(GL_TEXTURE_BINDING_2D, &tex0);
    glActiveTexture(GL_TEXTURE1); glGetIntegerv(GL_TEXTURE_BINDING_2D, &tex1);

    bool ready = true;
    if (cur != fx.ctx) {
        fx = FX();
        fx.ctx = cur;
        if (!initFX()) { fx.failed = true; ready = false; LOGE("init failed, filter disabled"); }
        else LOGI("filter initialised %dx%d", w, h);
    }
    if (ready) drawFX(dpy, w, h);

    // ---- restore state
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, tex1);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, tex0);
    glActiveTexture(actTex);
    if (!attr0) glDisableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, arrBuf);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elemBuf);
    glUseProgram(prog);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glViewport(vp[0], vp[1], vp[2], vp[3]);
    glColorMask(cm[0], cm[1], cm[2], cm[3]);
    if (blend) glEnable(GL_BLEND); else glDisable(GL_BLEND);
    if (depth) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
    if (cull) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
    if (scis) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
    if (sten) glEnable(GL_STENCIL_TEST); else glDisable(GL_STENCIL_TEST);
    if (dith) glEnable(GL_DITHER); else glDisable(GL_DITHER);
}

// ---------------------------------------------------------------- GOT hook of eglSwapBuffers
// ---------------------------------------------------------------- motion blur plumbing
struct FinalProg { GLint locPrev, locMix, locSun, locRays; };
static std::map<GLuint, FinalProg> g_finalProgs;
static std::set<GLuint> g_finalShaders;
typedef void (*AttachFn)(GLuint, GLuint);
typedef void (*UseFn)(GLuint);
static AttachFn origAttach = nullptr;
static UseFn origUse = nullptr;
static std::mutex g_mx;

static void copyPrev(EGLDisplay, EGLSurface surf);
static void myAttach(GLuint prog, GLuint sh) {
    origAttach(prog, sh);
    std::lock_guard<std::mutex> lk(g_mx);
    if (g_finalShaders.count(sh)) g_finalProgs[prog] = FinalProg{-2, -2, -1, -1};
}
static void myUse(GLuint prog) {
    origUse(prog);
    if (!g_haveFinal) return;
    FinalProg fp;
    {
        std::lock_guard<std::mutex> lk(g_mx);
        auto it = g_finalProgs.find(prog);
        if (it == g_finalProgs.end()) return;
        if (it->second.locPrev == -2) {
            it->second.locPrev = glGetUniformLocation(prog, "brPrev");
            it->second.locMix = glGetUniformLocation(prog, "brMix");
            it->second.locSun = glGetUniformLocation(prog, "brSun");
            it->second.locRays = glGetUniformLocation(prog, "brRays");
        }
        fp = it->second;
    }
    GLint act = 0; glGetIntegerv(GL_ACTIVE_TEXTURE, &act);
    if (fp.locPrev >= 0 && g_motion > 0.0f && g_prevReady) {
        glActiveTexture(GL_TEXTURE7);
        glBindTexture(GL_TEXTURE_2D, g_prevTex);
        glUniform1i(fp.locPrev, 7);
        if (fp.locMix >= 0) glUniform1f(fp.locMix, g_motion);
        glActiveTexture(act);
    }
    if (fp.locRays >= 0) {
        bool ok = g_sunValid.load();
        if (fp.locSun >= 0) glUniform3f(fp.locSun, g_sun[0], g_sun[1], g_sun[2]);
        glUniform1f(fp.locRays, ok ? g_rays : 0.0f);
    }
}
static void copyPrev(EGLDisplay dpy, EGLSurface surf) {
    if (g_motion <= 0.0f || !g_haveFinal) return;
    EGLContext cur = eglGetCurrentContext();
    if (cur == EGL_NO_CONTEXT) return;
    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w < 64 || h < 64) return;
    GLint fbo = 0, act = 0, tex7 = 0;
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &fbo);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &act);
    glActiveTexture(GL_TEXTURE7);
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &tex7);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (cur != g_prevCtx || !g_prevTex) {
        g_prevTex = 0; glGenTextures(1, &g_prevTex);
        g_prevCtx = cur; g_prevW = g_prevH = 0; g_prevReady = false;
    }
    glBindTexture(GL_TEXTURE_2D, g_prevTex);
    if (w != g_prevW || h != g_prevH) {
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glCopyTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 0, 0, w, h, 0);
        g_prevW = w; g_prevH = h;
    } else {
        glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, w, h);
    }
    g_prevReady = true;
    glBindTexture(GL_TEXTURE_2D, tex7);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glActiveTexture(act);
}

typedef EGLBoolean (*SwapFn)(EGLDisplay, EGLSurface);
static SwapFn origSwap = nullptr;
static EGLBoolean mySwap(EGLDisplay d, EGLSurface s) {
    if (g_post) renderFX(d, s);
    copyPrev(d, s);
    return origSwap(d, s);
}


// ---------------------------------------------------------------- game shader dump / override
typedef void (*SrcFn)(GLuint, GLsizei, const GLchar *const *, const GLint *);
static SrcFn origSource = nullptr;


static void replaceAll(std::string &s, const std::string &from, const std::string &to) {
    size_t pos = 0;
    while ((pos = s.find(from, pos)) != std::string::npos) { s.replace(pos, from.size(), to); pos += to.size(); }
}
static std::string f4(float v) { char b[32]; snprintf(b, sizeof b, "%.4f", v); return b; }

// Patches the game's own GLSL ES 3.00 shaders (structure verified against a dump of the client):
//  - world shaders end with  FRAGCOLOR(color);   (vec4 color, shadow map in some)
//  - sky shaders end with    FRAGCOLOR(vec4(color, 1.0));
static bool patchGame(std::string &src, GLint type, int lvl = 0) {
    if (!g_patch || type != GL_FRAGMENT_SHADER) return false;
    if (src.find("#version 300 es") == std::string::npos) return false;
    if (src.find("BRGFX_PATCHED") != std::string::npos) return false;

    // ---------- world (terrain, buildings, props, cars, people)
    if (src.find("u_debugColor") != std::string::npos && src.find("FRAGCOLOR(color);") != std::string::npos) {
        // real shadow map: replace the game's 4-tap filter with a rotated spiral disc (smooth, no banding)
        if (lvl < 1 && g_shadowTaps > 4 && src.find("v_shadowProj") != std::string::npos) {
            size_t a = src.find("for (int i=0;i<4;i++)");
            if (a != std::string::npos) {
                size_t lb = src.find('{', a), rb = (lb == std::string::npos) ? lb : src.find('}', lb);
                if (rb != std::string::npos && src.find("visibility += 0.25 * texture(tex5", a) < rb) {
                    std::string n = std::to_string(g_shadowTaps);
                    std::string rep =
                        "{ float _brRot = 6.2831853 * fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));\n"
                        "  vec2 _brCS = vec2(cos(_brRot), sin(_brRot));\n"
                        "  for (int _bi = 0; _bi < " + n + "; _bi++) {\n"
                        "    float _r = sqrt((float(_bi) + 0.5) / " + n + ".0);\n"
                        "    float _a = float(_bi) * 2.39996323;\n"
                        "    vec2 _o = vec2(cos(_a), sin(_a)) * _r;\n"
                        "    _o = vec2(_o.x * _brCS.x - _o.y * _brCS.y, _o.x * _brCS.y + _o.y * _brCS.x);\n"
                        "    visibility += (1.0 / " + n + ".0) * texture(tex5, vec3(v_shadowProj.xy + _o * " + f4(g_shadowSoft) + ", v_shadowProj.z));\n"
                        "  } }";
                    src.replace(a, rb - a + 1, rep);
                }
            }
        }
        // real shadow-map shadows: stronger and softer
        if (src.find("u_fogColor") != std::string::npos && g_skyFill > 0.0f)
            replaceAll(src, "color.rgb = color.rgb * (1.0 - shadow);",
                       "{ float _brS = clamp(shadow * " + f4(g_shadowMul) + ", 0.0, 0.85);"
                       " color.rgb = color.rgb * (1.0 - _brS) + color.rgb * u_fogColor.rgb * (_brS * " + f4(g_skyFill) + "); }");
        else
            replaceAll(src, "color.rgb = color.rgb * (1.0 - shadow);",
                       "color.rgb = color.rgb * (1.0 - clamp(shadow * " + f4(g_shadowMul) + ", 0.0, 0.85));");
        replaceAll(src, " * 0.0005", " * " + f4(g_shadowSoft));
        // fog density
        replaceAll(src, "mix(color.rgb, u_fogColor.rgb, v_fog)",
                   "mix(color.rgb, u_fogColor.rgb, clamp(v_fog * " + f4(g_fogMul) + ", 0.0, 1.0))");
        // glowing parts (headlights, lamps, lit windows) use the game's emissive term: boost it
        replaceAll(src, "* u_emissiveSaturation;", "* u_emissiveSaturation * " + f4(g_emissive) + ";");
        // car reflections / specular (shaders with an env map)
        replaceAll(src, "* u_envMapCoef;", "* u_envMapCoef * " + f4(g_envMul) + ";");
        replaceAll(src, "spec * 0.4;", "spec * 0.4 * " + f4(g_specMul) + ";");

        // photoreal car/prop optics (shaders with world normal + env map)
        if (lvl < 1) {
            replaceAll(src, "vec3 u_sunLightingColor = vec3(0.2, 0.2, 0.2);",
                       "vec3 u_sunLightingColor = vec3(0.28, 0.26, 0.22) * " + f4(g_sunLight) + ";");
            replaceAll(src, "clamp(fresnelFactor, 0.15, 0.7)", "clamp(fresnelFactor, 0.20, 0.92)");
            if (g_gloss > 0.0f)
                replaceAll(src, "color.rgb += (diffuseVec + specular + envmap.rgb);",
                           "color.rgb += (diffuseVec + specular + envmap.rgb + u_sunLightingColor * pow(max(dot(normalize(v_worldNormal), halfwayDir), 0.0), 220.0) * " + f4(g_gloss) + ");");
        }
        std::string code = "\n  { /*BRGFX_PATCHED*/\n";
        if (src.find("v_eyeNormal") != std::string::npos && src.find("v_eyePos") != std::string::npos &&
            src.find("u_fogColor") != std::string::npos && g_rim > 0.0f) {
            code += "    float _brR = pow(1.0 - clamp(abs(dot(normalize(v_eyeNormal), normalize(v_eyePos))), 0.0, 1.0), 3.0);\n"
                    "    color.rgb += u_fogColor.rgb * _brR * " + f4(g_rim) + ";\n";
        }
        // form shading: surfaces turned away from the sun get darker (uses the game's own N.L varying)
        if (lvl < 1 && g_form > 0.0f && src.find("float diffuse;") != std::string::npos)
            code += "    color.rgb *= mix(" + f4(1.0f - g_form) + ", 1.0, smoothstep(0.0, 0.55, diffuse));\n";
        // cavity AO: concave creases (wall/ground, between objects) get darker, from screen-space derivatives
        if (lvl < 1 && g_ao > 0.0f && src.find("v_eyeNormal") != std::string::npos && src.find("v_eyePos") != std::string::npos) {
            code += "    {\n"
                    "      vec3 _aP = vec3(v_eyePos); vec3 _aN = normalize(vec3(v_eyeNormal));\n"
                    "      vec3 _aDx = dFdx(_aP), _aDy = dFdy(_aP);\n"
                    "      float _aCv = (dot(_aDx, dFdx(_aN)) + dot(_aDy, dFdy(_aN))) / (dot(_aDx, _aDx) + dot(_aDy, _aDy) + 0.0001);\n"
                    "      float _aOcc = clamp(1.0 + _aCv * " + f4(g_ao * g_aoSign) + " * 0.6, 0.55, 1.0);\n"
                    "      color.rgb *= _aOcc;\n"
                    "    }\n";
        }
        if (lvl < 1 && g_head > 0.0f && src.find("v_eyeNormal") != std::string::npos && src.find("v_eyePos") != std::string::npos &&
            src.find("u_fogColor") != std::string::npos) {
            float cin = std::min(g_headCone + 0.12f, 0.995f);
            bool sunKnown = src.find("u_sunPos") != std::string::npos && src.find("u_eye") != std::string::npos;
            std::string nightExpr = "1.0 - smoothstep(" + f4(g_headDark) + ", " + f4(g_headDark + 0.3f) + ", dot(u_fogColor.rgb, vec3(0.299, 0.587, 0.114)))";
            if (sunKnown) nightExpr = "(1.0 - smoothstep(-0.04, 0.12, normalize(u_sunPos - u_eye).z)) * (" + nightExpr + ")";
            code += "    float _brNt = " + nightExpr + ";\n"
                    "    if (_brNt > 0.002) {\n"
                    "      vec3 _brP = vec3(v_eyePos); vec3 _brN = normalize(vec3(v_eyeNormal));\n"
                    "      vec3 _brHD = normalize(vec3(0.0, -0.05, " + f4(g_headFwd) + "));\n"
                    "      float _brAcc = 0.0;\n"
                    "      for (int _hi = 0; _hi < 2; _hi++) {\n"
                    "        vec3 _brLp = vec3((_hi == 0 ? -1.0 : 1.0) * " + f4(g_headSep) + ", " + f4(g_headY) + ", " + f4(g_headFwd * g_headDist) + ");\n"
                    "        vec3 _brD = _brP - _brLp; float _brDist = max(length(_brD), 0.001); vec3 _brLd = _brD / _brDist;\n"
                    "        float _brCone = smoothstep(" + f4(g_headCone) + ", " + f4(cin) + ", dot(_brLd, _brHD));\n"
                    "        float _brFa = clamp(1.0 - _brDist / " + f4(g_headRange) + ", 0.0, 1.0); _brFa *= _brFa;\n"
                    "        float _brNd = 0.2 + 0.8 * max(dot(_brN, -_brLd), 0.0);\n"
                    "        _brAcc += _brCone * _brFa * _brNd * smoothstep(0.8, 3.0, _brDist) / (1.0 + _brDist * 0.12);\n"
                    "      }\n"
                    "      color.rgb += (color.rgb * 2.5 + vec3(0.02)) * vec3(1.0, 0.92, 0.75) * (_brAcc * " + f4(g_head) + " * 4.0 * _brNt);\n"
                    "    }\n";
        }
        code += "    float _brL = dot(color.rgb, vec3(0.299, 0.587, 0.114));\n"
                "    color.r *= 1.0 + " + f4(g_shWarm) + "; color.b *= 1.0 - " + f4(g_shWarm) + ";\n"
                "    color.rgb = mix(vec3(_brL), color.rgb, " + f4(g_shSat) + ");\n"
                "    color.rgb = (color.rgb - 0.5) * " + f4(g_shContrast) + " + 0.5;\n"
                "    color.rgb += max(color.rgb - 0.8, 0.0) * " + f4(g_shGlow) + ";\n"
                "    color.rgb = clamp(color.rgb, 0.0, 1.0);\n"
                "  }\n  ";
        size_t at = src.rfind("FRAGCOLOR(color);");
        src.insert(at, code);
        return true;
    }
    // ---------- game's own final scene pass (scene texture tex0 -> screen). UI is drawn after it.
    if (g_postShader && src.find("contrastMult") != std::string::npos &&
        src.find("FRAGCOLOR(rast);") != std::string::npos && src.find("sampler2D tex0") != std::string::npos &&
        src.find("v_tex0") != std::string::npos) {
        auto T = [](const char *ox, const char *oy) {
            return std::string("texture(tex0, v_tex0 + vec2(") + ox + ", " + oy + ")).rgb";
        };
        std::string code = "\n  { /*BRGFX_PATCHED*/\n"
            "    vec2 _px = 1.0 / vec2(textureSize(tex0, 0));\n"
            "    vec3 _c = mix(rast.rgb, texture(brPrev, v_tex0).rgb, brMix);\n"
            "    vec3 _n = " + T("0.0", "_px.y") + ", _s = " + T("0.0", "-_px.y") + ";\n"
            "    vec3 _e = " + T("_px.x", "0.0") + ", _w = " + T("-_px.x", "0.0") + ";\n"
            "    vec3 _avg = (_n + _s + _e + _w) * 0.25;\n"
            "    vec3 _mn = min(_c, min(min(_n, _s), min(_e, _w)));\n"
            "    vec3 _mx = max(_c, max(max(_n, _s), max(_e, _w)));\n"
            "    vec3 _sh = clamp(_c + (_c - _avg) * " + f4(g_sharp) + " * 2.0, _mn - 0.04, _mx + 0.04);\n"
            "    vec2 _r1 = _px * 5.0, _r2 = _px * 13.0;\n"
            "    vec3 _b1 = (" + T("_r1.x", "_r1.y") + " + " + T("-_r1.x", "_r1.y") + " + " + T("_r1.x", "-_r1.y") + " + " + T("-_r1.x", "-_r1.y") + ") * 0.25;\n"
            "    vec3 _b2 = (" + T("_r2.x", "_r2.y") + " + " + T("-_r2.x", "_r2.y") + " + " + T("_r2.x", "-_r2.y") + " + " + T("-_r2.x", "-_r2.y") + ") * 0.25;\n"
            "    vec2 _r3 = _px * 30.0;\n"
            "    vec3 _b3 = (" + T("_r3.x", "_r3.y") + " + " + T("-_r3.x", "_r3.y") + " + " + T("_r3.x", "-_r3.y") + " + " + T("-_r3.x", "-_r3.y") + ") * 0.25;\n"
            "    vec3 _blur = (_b1 + _b2 + _b3) * 0.3333;\n"
            "    vec3 _glow = max(_b1 - 0.6, 0.0) * 0.5 + max(_b2 - 0.6, 0.0) * 0.8 + max(_b3 - 0.6, 0.0) * 1.0;\n"
            "    _c = _sh + _glow * " + f4(g_bloomP) + " * 1.3;\n"
            "    _c += (_c - _blur) * " + f4(g_clarity) + ";\n" +
            (lvl < 1 && g_rays > 0.0f ? std::string(
            "    if (brRays > 0.001 && brSun.z * " + f4(g_headFwd) + " > 0.0) {\n"
            "      float _asp = float(textureSize(tex0, 0).x) / float(textureSize(tex0, 0).y);\n"
            "      float _th = tan(radians(" + f4(g_raysFov) + ") * 0.5);\n"
            "      vec3 _sd = normalize(brSun);\n"
            "      vec2 _sUV = 0.5 + 0.5 * vec2(_sd.x / (abs(_sd.z) * _th * _asp), _sd.y / (abs(_sd.z) * _th));\n"
            "      vec2 _dl = (_sUV - v_tex0) * (" + f4(g_raysDens) + " / " + std::to_string(g_raysTaps) + ".0);\n"
            "      vec2 _tc = v_tex0 + _dl * fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);\n"
            "      float _il = 1.0, _ra = 0.0;\n"
            "      for (int _ri = 0; _ri < " + std::to_string(g_raysTaps) + "; _ri++) {\n"
            "        _tc += _dl;\n"
            "        float _m = smoothstep(0.72, 0.95, dot(texture(tex0, _tc).rgb, vec3(0.299, 0.587, 0.114)));\n"
            "        _ra += _m * _il; _il *= 0.95;\n"
            "      }\n"
            "      float _fall = 1.0 - smoothstep(0.0, 1.3, length((_sUV - v_tex0) * vec2(_asp, 1.0)));\n"
            "      _c += vec3(1.0, 0.88, 0.65) * (_ra / " + std::to_string(g_raysTaps) + ".0) * _fall * brRays;\n"
            "    }\n") : std::string()) +

            "    _c = clamp(_c, 0.0, 1.0);\n" +
            (lvl < 1 && g_aces > 0.0f ? std::string("    { vec3 _ac = _c * 1.12; _ac = clamp((_ac * (2.51 * _ac + 0.03)) / (_ac * (2.43 * _ac + 0.59) + 0.14), 0.0, 1.0); _c = mix(_c, _ac, " + f4(g_aces) + "); }\n") : std::string()) +
            "    _c = mix(_c, _c * _c * (3.0 - 2.0 * _c), " + f4(g_filmic) + ");\n"
            "    float _g = fract(sin(dot(v_tex0 * vec2(textureSize(tex0, 0)), vec2(12.9898, 78.233))) * 43758.5453);\n"
            "    _c += (_g - 0.5) * " + f4(g_grainP) + ";\n"
            "    rast.rgb = clamp(_c, 0.0, 1.0);\n"
            "  }\n  ";
        size_t at = src.rfind("FRAGCOLOR(rast);");
        src.insert(at, code);
        size_t mp = src.find("void main");
        if (mp != std::string::npos)
            src.insert(mp, std::string("precision highp float;\nuniform mediump sampler2D brPrev;\nuniform mediump float brMix;\n") +
                       (lvl < 1 && g_rays > 0.0f ? "uniform highp vec3 brSun;\nuniform mediump float brRays;\n" : ""));
        t_lastFinal = true;
        return true;
    }
    // ---------- sky / clouds / sun
    if (src.find("u_skySunDir") != std::string::npos && src.find("FRAGCOLOR(vec4(color, 1.0));") != std::string::npos &&
        src.find("u_sunColor") != std::string::npos) {
        std::string code = "\n  { /*BRGFX_PATCHED*/\n"
            "    color += u_sunColor * pow(max(dot(u_skySunDir, eyeToVertex), 0.0), 48.0) * " + f4(g_sunGlow) + ";\n"
            "    float _brL = dot(color, vec3(0.299, 0.587, 0.114));\n"
            "    color = mix(vec3(_brL), color, " + f4(g_skyBoost) + ");\n"
            "  }\n  ";
        size_t at = src.rfind("FRAGCOLOR(vec4(color, 1.0));");
        src.insert(at, code);
        return true;
    }
    return false;
}
static std::map<GLuint, std::string> g_origSrc;
typedef void (*CompFn)(GLuint);
static CompFn origCompile = nullptr;

static std::string shDir() { return "/storage/emulated/0/Android/data/" + g_pkg + "/files/brshaders"; }
static void mk(const std::string &p) { mkdir(p.c_str(), 0777); }

static void mySource(GLuint sh, GLsizei count, const GLchar *const *str, const GLint *len) {
    std::string src;
    for (GLsizei i = 0; i < count; i++) {
        if (!str[i]) continue;
        if (len && len[i] >= 0) src.append(str[i], len[i]); else src.append(str[i]);
    }
    uint32_t h = 2166136261u;
    for (unsigned char ch : src) { h ^= ch; h *= 16777619u; }
    GLint t = 0; glGetShaderiv(sh, GL_SHADER_TYPE, &t);
    char nm[64]; snprintf(nm, sizeof nm, "%08x_%s.glsl", h, t == GL_VERTEX_SHADER ? "vert" : "frag");
    std::string base = shDir();
    mk("/storage/emulated/0/Android/data/" + g_pkg + "/files");
    mk(base); mk(base + "/dump"); mk(base + "/override");
    std::string ov = readFile((base + "/override/" + nm).c_str());
    if (g_dump) {
        std::string dp = base + "/dump/" + nm;
        if (access(dp.c_str(), F_OK) != 0) {
            FILE *f = fopen(dp.c_str(), "w");
            if (f) { fwrite(src.data(), 1, src.size(), f); fclose(f); }
        }
    }
    if (!ov.empty()) {
        LOGI("override shader %s", nm);
        const GLchar *p = ov.c_str();
        origSource(sh, 1, &p, nullptr);
        return;
    }
    std::string np = src;
    t_lastFinal = false;
    if (patchGame(np, t)) {
        {
            std::lock_guard<std::mutex> lk(g_mx);
            g_origSrc[sh] = src;
            if (t_lastFinal) { g_finalShaders.insert(sh); g_haveFinal = true; }
        }
        t_lastFinal = false;
        LOGI("patched fragment shader %s", nm);
        const GLchar *p = np.c_str();
        origSource(sh, 1, &p, nullptr);
        return;
    }
    const GLchar *p = src.c_str();
    origSource(sh, 1, &p, nullptr);
}

// if a patched shader fails to compile, fall back to the game's original source
static void myCompile(GLuint sh) {
    origCompile(sh);
    std::string orig;
    {
        std::lock_guard<std::mutex> lk(g_mx);
        auto it = g_origSrc.find(sh);
        if (it == g_origSrc.end()) return;
        orig = it->second;
        g_origSrc.erase(it);
    }
    GLint ok = 1; glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (ok) return;
    // tier 2: same patch without the heavy extras (headlights, rays, spiral shadows)
    GLint type = 0; glGetShaderiv(sh, GL_SHADER_TYPE, &type);
    std::string lite = orig;
    if (patchGame(lite, type, 1)) {
        LOGE("patched shader %u failed, trying lite patch", sh);
        const GLchar *p = lite.c_str();
        origSource(sh, 1, &p, nullptr);
        origCompile(sh);
        glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
        if (ok) return;
    }
    // tier 3: the game's original
    LOGE("patched shader %u failed, restoring original", sh);
    { std::lock_guard<std::mutex> lk(g_mx); g_finalShaders.erase(sh); }
    const GLchar *p = orig.c_str();
    origSource(sh, 1, &p, nullptr);
    origCompile(sh);
}


// ---------------------------------------------------------------- sun direction capture (for god rays)
typedef GLint (*GetLocFn)(GLuint, const GLchar *);
typedef void (*U3fvFn)(GLint, GLsizei, const GLfloat *);
typedef void (*U3fFn)(GLint, GLfloat, GLfloat, GLfloat);
static GetLocFn origGetLoc = nullptr;
static U3fvFn origU3fv = nullptr;
static U3fFn origU3f = nullptr;
static std::atomic<uint64_t> g_sunLocMask{0};
static std::set<GLuint> g_sunProgs;

static GLint myGetLoc(GLuint prog, const GLchar *name) {
    GLint l = origGetLoc(prog, name);
    if (l >= 0 && name && strcmp(name, "u_skySunDir") == 0) {
        if (l < 64) {
            g_sunLocMask.fetch_or(1ull << l);
            std::lock_guard<std::mutex> lk(g_mx);
            g_sunProgs.insert(prog);
        } else LOGE("u_skySunDir location %d >= 64, rays disabled", l);
    }
    return l;
}
static inline bool isSunLoc(GLint loc) {
    if (loc < 0 || loc >= 64) return false;
    if (!((g_sunLocMask.load(std::memory_order_relaxed) >> loc) & 1ull)) return false;
    GLint p = 0; glGetIntegerv(GL_CURRENT_PROGRAM, &p);
    std::lock_guard<std::mutex> lk(g_mx);
    return g_sunProgs.count((GLuint)p) > 0;
}
static void setSun(float x, float y, float z) {
    float l = sqrtf(x * x + y * y + z * z);
    if (l < 0.001f) return;
    bool first = !g_sunValid.load();
    g_sun[0] = x / l; g_sun[1] = y / l; g_sun[2] = z / l;
    g_sunValid.store(true);
    if (first) LOGI("sun dir captured %.3f %.3f %.3f", g_sun[0], g_sun[1], g_sun[2]);
}
static void myU3fv(GLint loc, GLsizei n, const GLfloat *v) {
    origU3fv(loc, n, v);
    if (v && isSunLoc(loc)) setSun(v[0], v[1], v[2]);
}
static void myU3f(GLint loc, GLfloat x, GLfloat y, GLfloat z) {
    origU3f(loc, x, y, z);
    if (isSunLoc(loc)) setSun(x, y, z);
}

#if defined(__LP64__)
typedef Elf64_Rela Rel; typedef Elf64_Sym Sym;
#define R_SYM(i) ELF64_R_SYM(i)
#else
typedef Elf32_Rel Rel; typedef Elf32_Sym Sym;
#define R_SYM(i) ELF32_R_SYM(i)
#endif

static std::vector<uintptr_t> patchedSlots;

static void patchSlot(uintptr_t addr, void *fn) {
    for (auto a : patchedSlots) if (a == addr) return;
    long pg = sysconf(_SC_PAGESIZE);
    uintptr_t page = addr & ~(uintptr_t)(pg - 1);
    if (mprotect((void *)page, pg, PROT_READ | PROT_WRITE) != 0) return;
    *(void **)addr = fn;
    patchedSlots.push_back(addr);
    LOGI("hooked eglSwapBuffers slot %p", (void *)addr);
}

static int phdrCb(struct dl_phdr_info *info, size_t, void *) {
    const char *name = info->dlpi_name ? info->dlpi_name : "";
    if (strstr(name, "libEGL") || strstr(name, "brgfx") || strstr(name, "libGLES") || strstr(name, "libc.so")) return 0;
    uintptr_t base = info->dlpi_addr;
    const ElfW(Dyn) *dyn = nullptr;
    for (int i = 0; i < info->dlpi_phnum; i++)
        if (info->dlpi_phdr[i].p_type == PT_DYNAMIC) dyn = (const ElfW(Dyn) *)(base + info->dlpi_phdr[i].p_vaddr);
    if (!dyn) return 0;
    auto fix = [&](uintptr_t p) { return p < base ? base + p : p; };
    uintptr_t symtab = 0, strtab = 0, jmprel = 0, rel = 0;
    size_t pltsz = 0, relsz = 0;
    for (; dyn->d_tag != DT_NULL; dyn++) {
        switch (dyn->d_tag) {
            case DT_SYMTAB: symtab = fix(dyn->d_un.d_ptr); break;
            case DT_STRTAB: strtab = fix(dyn->d_un.d_ptr); break;
            case DT_JMPREL: jmprel = fix(dyn->d_un.d_ptr); break;
            case DT_PLTRELSZ: pltsz = dyn->d_un.d_val; break;
#if defined(__LP64__)
            case DT_RELA: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELASZ: relsz = dyn->d_un.d_val; break;
#else
            case DT_REL: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELSZ: relsz = dyn->d_un.d_val; break;
#endif
        }
    }
    if (!symtab || !strtab) return 0;
    auto scan = [&](uintptr_t tbl, size_t sz) {
        if (!tbl) return;
        Rel *r = (Rel *)tbl;
        for (size_t i = 0; i < sz / sizeof(Rel); i++) {
            uint32_t si = R_SYM(r[i].r_info);
            if (!si) continue;
            const char *nm = (const char *)strtab + ((Sym *)symtab)[si].st_name;
            if ((g_post || g_motion > 0.0f) && strcmp(nm, "eglSwapBuffers") == 0) patchSlot(base + r[i].r_offset, (void *)mySwap);
            else if (origSource && strcmp(nm, "glShaderSource") == 0) patchSlot(base + r[i].r_offset, (void *)mySource);
            else if ((g_motion > 0.0f || g_rays > 0.0f) && origAttach && strcmp(nm, "glAttachShader") == 0) patchSlot(base + r[i].r_offset, (void *)myAttach);
            else if ((g_motion > 0.0f || g_rays > 0.0f) && origUse && strcmp(nm, "glUseProgram") == 0) patchSlot(base + r[i].r_offset, (void *)myUse);
            else if (g_rays > 0.0f && origGetLoc && strcmp(nm, "glGetUniformLocation") == 0) patchSlot(base + r[i].r_offset, (void *)myGetLoc);
            else if (g_rays > 0.0f && origU3fv && strcmp(nm, "glUniform3fv") == 0) patchSlot(base + r[i].r_offset, (void *)myU3fv);
            else if (g_rays > 0.0f && origU3f && strcmp(nm, "glUniform3f") == 0) patchSlot(base + r[i].r_offset, (void *)myU3f);
            else if (origCompile && strcmp(nm, "glCompileShader") == 0) patchSlot(base + r[i].r_offset, (void *)myCompile);
        }
    };
    scan(jmprel, pltsz);
    scan(rel, relsz);
    return 0;
}

static void *hookThread(void *) {
    void *egl = dlopen("libEGL.so", RTLD_NOW);
    origSwap = egl ? (SwapFn)dlsym(egl, "eglSwapBuffers") : nullptr;
    if (!origSwap) { LOGE("no eglSwapBuffers"); return nullptr; }
    void *gl = dlopen("libGLESv2.so", RTLD_NOW);
    origSource = gl ? (SrcFn)dlsym(gl, "glShaderSource") : nullptr;
    origCompile = gl ? (CompFn)dlsym(gl, "glCompileShader") : nullptr;
    origAttach = gl ? (AttachFn)dlsym(gl, "glAttachShader") : nullptr;
    origUse = gl ? (UseFn)dlsym(gl, "glUseProgram") : nullptr;
    origGetLoc = gl ? (GetLocFn)dlsym(gl, "glGetUniformLocation") : nullptr;
    origU3fv = gl ? (U3fvFn)dlsym(gl, "glUniform3fv") : nullptr;
    origU3f = gl ? (U3fFn)dlsym(gl, "glUniform3f") : nullptr;
    // game libs are loaded some time after process start -> keep scanning
    for (int i = 0; i < 600; i++) {
        dl_iterate_phdr(phdrCb, nullptr);
        usleep(i < 100 ? 200000 : 1000000);
    }
    return nullptr;
}

// ---------------------------------------------------------------- Zygisk module
class BRModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api *api, JNIEnv *env) override { this->api = api; this->env = env; }

    void preAppSpecialize(zygisk::AppSpecializeArgs *args) override {
        const char *nn = env->GetStringUTFChars(args->nice_name, nullptr);
        std::string name = nn ? nn : "";
        if (nn) env->ReleaseStringUTFChars(args->nice_name, nn);

        int fd = api->connectCompanion();
        if (fd >= 0) {
            uint32_t len = name.size();
            writeAll(fd, &len, 4);
            writeAll(fd, name.data(), len);
            uint8_t match = 0;
            if (readAll(fd, &match, 1) && match) {
                uint32_t cl = 0;
                if (readAll(fd, &cl, 4) && cl < 65536) {
                    std::string cfg(cl, 0);
                    if (readAll(fd, &cfg[0], cl)) {
                        auto kv = parseCfg(cfg, nullptr);
                        S.sharp = getf(kv, "sharpness", S.sharp);
                        S.bloom = getf(kv, "bloom", S.bloom);
                        S.contrast = getf(kv, "contrast", S.contrast);
                        S.saturation = getf(kv, "saturation", S.saturation);
                        S.vignette = getf(kv, "vignette", S.vignette);
                        S.grain = getf(kv, "grain", S.grain);
                        S.motionblur = getf(kv, "motion_blur", S.motionblur);
                        S.exposure = getf(kv, "exposure", S.exposure);
                        S.warmth = getf(kv, "warmth", S.warmth);
                        g_dump = getf(kv, "dump_shaders", 1) != 0;
                        g_post = getf(kv, "post_filter", 1) != 0;
                        g_patch = getf(kv, "shader_patch", 1) != 0;
                        g_shadowMul = getf(kv, "sh_shadow_strength", g_shadowMul);
                        g_shadowSoft = getf(kv, "sh_shadow_soft", g_shadowSoft);
                        g_fogMul = getf(kv, "sh_fog", g_fogMul);
                        g_envMul = getf(kv, "sh_reflection", g_envMul);
                        g_specMul = getf(kv, "sh_specular", g_specMul);
                        g_rim = getf(kv, "sh_rim", g_rim);
                        g_shContrast = getf(kv, "sh_contrast", g_shContrast);
                        g_shSat = getf(kv, "sh_saturation", g_shSat);
                        g_shGlow = getf(kv, "sh_glow", g_shGlow);
                        g_shWarm = getf(kv, "sh_warmth", g_shWarm);
                        g_skyBoost = getf(kv, "sh_sky_saturation", g_skyBoost);
                        g_sunGlow = getf(kv, "sh_sun_glow", g_sunGlow);
                        g_skyFill = getf(kv, "sh_sky_fill", g_skyFill);
                        g_postShader = getf(kv, "sh_post", 1) != 0;
                        g_motion = getf(kv, "sh_motion_blur", g_motion);
                        g_emissive = getf(kv, "sh_emissive", g_emissive);
                        g_shadowTaps = (int)getf(kv, "sh_shadow_taps", (float)g_shadowTaps);
                        g_form = getf(kv, "sh_form", g_form);
                        g_sunLight = getf(kv, "sh_sunlight", g_sunLight);
                        g_gloss = getf(kv, "sh_gloss", g_gloss);
                        g_aces = getf(kv, "sh_aces", g_aces);
                        g_ao = getf(kv, "sh_ao", g_ao);
                        g_aoSign = getf(kv, "sh_ao_sign", g_aoSign) < 0 ? -1.0f : 1.0f;
                        g_head = getf(kv, "sh_head", g_head);
                        g_headRange = getf(kv, "sh_head_range", g_headRange);
                        g_headCone = getf(kv, "sh_head_cone", g_headCone);
                        g_headY = getf(kv, "sh_head_y", g_headY);
                        g_headDist = getf(kv, "sh_head_dist", g_headDist);
                        g_headSep = getf(kv, "sh_head_sep", g_headSep);
                        g_headDark = getf(kv, "sh_head_dark", g_headDark);
                        g_headFwd = getf(kv, "sh_view_fwd", g_headFwd) < 0 ? -1.0f : 1.0f;
                        g_rays = getf(kv, "sh_rays", g_rays);
                        g_raysFov = getf(kv, "sh_rays_fov", g_raysFov);
                        g_raysDens = getf(kv, "sh_rays_density", g_raysDens);
                        g_raysTaps = (int)getf(kv, "sh_rays_taps", (float)g_raysTaps);
                        if (g_raysTaps < 4) g_raysTaps = 4;
                        if (g_raysTaps > 32) g_raysTaps = 32;
                        if (g_headCone > 0.97f) g_headCone = 0.97f;
                        if (g_shadowTaps > 24) g_shadowTaps = 24;
                        g_sharp = getf(kv, "sh_sharpness", g_sharp);
                        g_bloomP = getf(kv, "sh_bloom", g_bloomP);
                        g_clarity = getf(kv, "sh_clarity", g_clarity);
                        g_filmic = getf(kv, "sh_filmic", g_filmic);
                        g_grainP = getf(kv, "sh_grain", g_grainP);
                        g_pkg = name;
                        active = true;
                    }
                }
            }
            close(fd);
        }
        if (!active) api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!active) return;
        LOGI("attached to game process");
        pthread_t t;
        pthread_create(&t, nullptr, hookThread, nullptr);
        pthread_detach(t);
    }

private:
    zygisk::Api *api = nullptr;
    JNIEnv *env = nullptr;
    bool active = false;
};

REGISTER_ZYGISK_MODULE(BRModule)
REGISTER_ZYGISK_COMPANION(companion)
