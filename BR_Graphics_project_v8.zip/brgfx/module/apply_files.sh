#!/system/bin/sh
# Mirrors files from overlay/ into the game's data folder (Android/data/<pkg>/...).
# Originals are backed up once to /data/adb/br_graphics/backup. Run "sh apply_files.sh restore" to undo.
MODDIR=${0%/*}
CFG=/data/adb/br_graphics/config.ini
BK=/data/adb/br_graphics/backup
DATA=/data/media/0/Android/data
echo "== $(date) =="
for pat in $(grep '^package=' "$CFG" | cut -d= -f2); do
  for dir in "$DATA"/*"$pat"*; do
    [ -d "$dir" ] || continue
    pkg=${dir##*/}
    src="$MODDIR/overlay/$pkg"
    [ -d "$src" ] || src="$MODDIR/overlay/default"
    if [ "$1" = "restore" ]; then
      [ -d "$BK/$pkg" ] && cp -a "$BK/$pkg/." "$dir/" && echo "restored $pkg"
      continue
    fi
    [ -d "$src" ] || continue
    uid=$(stat -c %u "$dir"); gid=$(stat -c %g "$dir")
    (cd "$src" && find . -type f) | while read -r f; do
      f=${f#./}
      if [ -f "$dir/$f" ] && [ ! -f "$BK/$pkg/$f" ]; then
        mkdir -p "$BK/$pkg/$(dirname "$f")"; cp -a "$dir/$f" "$BK/$pkg/$f"
      fi
      mkdir -p "$dir/$(dirname "$f")"
      cp -f "$src/$f" "$dir/$f"
      chown "$uid:$gid" "$dir/$f"
      echo "applied $pkg/$f"
    done
    restorecon -R "$dir" 2>/dev/null
  done
done
