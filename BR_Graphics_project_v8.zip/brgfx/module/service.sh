#!/system/bin/sh
MODDIR=${0%/*}
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 5; done
sleep 30
sh "$MODDIR/apply_files.sh" >> /data/adb/br_graphics/apply.log 2>&1
