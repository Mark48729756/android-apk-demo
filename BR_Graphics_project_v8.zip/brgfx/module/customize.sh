#!/system/bin/sh
SKIPUNZIP=0
ui_print "- BR Graphics: installing"
if [ "$ZYGISK_ENABLED" = "false" ]; then
  ui_print "! Zygisk looks disabled. Enable it in Magisk settings, then reboot."
fi
mkdir -p /data/adb/br_graphics
if [ ! -f /data/adb/br_graphics/config.ini ]; then
  cp "$MODPATH/config.ini" /data/adb/br_graphics/config.ini
  ui_print "- Config created: /data/adb/br_graphics/config.ini"
else
  ui_print "- Existing config kept"
  # add any keys missing from an older config (so updates need no manual editing)
  grep -v '^#' "$MODPATH/config.ini" | grep '=' | grep -v '^package=' | while read -r line; do
    k=${line%%=*}
    grep -q "^$k=" /data/adb/br_graphics/config.ini || echo "$line" >> /data/adb/br_graphics/config.ini
  done
fi
chmod 0644 /data/adb/br_graphics/config.ini
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/apply_files.sh" 0 0 0755
ui_print "- Put replacement files in: $MODPATH/overlay/<game_package>/..."
ui_print "- Reboot to finish."
