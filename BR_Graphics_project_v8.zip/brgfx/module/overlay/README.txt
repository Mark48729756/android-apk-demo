Put replacement game files here (HD textures, timecyc.dat, etc.), mirroring the path inside
/sdcard/Android/data/<package>/ :

  overlay/<package>/files/<path>/file.txd
  overlay/default/...   (used when there is no folder for the exact package)

They are copied on every boot; originals are backed up first.
NOTE: if the launcher verifies file hashes it may re-download originals or flag changes.
This is the part that can get an account banned - the shader filter alone does not touch files.
