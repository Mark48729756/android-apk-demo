# BR Graphics (Magisk + Zygisk)

1. Create a GitHub repo, upload this whole folder, open Actions -> build -> download artifact `BR_Graphics.zip`.
2. Magisk: enable Zygisk (Settings), install the zip from Modules, reboot.
3. Check the real package name: `pm list packages | grep -i -E "black|russia"` and fix `package=` in
   /data/adb/br_graphics/config.ini if needed.
4. Start the game. Log: `logcat -s BRGFX`  (should show "hooked eglSwapBuffers").
5. Tune /data/adb/br_graphics/config.ini, fully restart the game.

Settings to try if it looks wrong: motion_blur=0 (HUD ghosting), bloom=0.1, grain=0.
If the screen is black/flickers: enabled=0 and send me the `logcat -s BRGFX` output.

Optional files: see module/overlay/README.txt.

## Game shaders (real in-scene shaders)
Start the game once with dump_shaders=1. Shaders appear in
/sdcard/Android/data/<package>/files/brshaders/dump/. Copy a file to ../override/ (same name),
edit it, restart the game. Send the dump folder to Claude to get ready-made replacements.

## v2: shaders verified against a real dump
The client uses GLSL ES 3.00 with real shadow maps. Patching works on those exact shaders
(shadows, fog, car reflections/specular, rim light, grading, sky). Tune everything via sh_* keys.
If something looks wrong: shader_patch=0 and restart the game. Failed patches fall back automatically.

## v3
- Game's own final scene pass is patched (sharpen, bloom, clarity, filmic curve, grain) - 3D only, UI untouched (sh_post=0 disables).
- Shadows get sky-colour fill (sh_sky_fill) instead of just darkening.

## v5
Shadow-map filter replaced with a rotated 10-tap spiral (sh_shadow_taps, sh_shadow_soft): smooth realistic shadow edges.

## v6
Emissive (lights/lamps/windows) boost + wide glow ring in the final pass (sh_emissive, sh_bloom).

## v7
Fixed: final-pass shader lacked default float precision (patched shaders now all validate with glslang: 35/35).

## v8
- Headlights: two real spot cones computed inside the game's own world shaders, so they light terrain, buildings, props and cars (night only, `sh_head*`).
  Lights are placed relative to the camera (third-person behind the car), not read from the car matrix.
- Sun god rays in the final pass (`sh_rays*`). The sun direction is captured from the game's sky shader (`u_skySunDir`).
  Check `logcat -s BRGFX` for "sun dir captured"; if the rays sit in the wrong place send me that line.
- NOTE: an existing /data/adb/br_graphics/config.ini is kept on update: copy the "v8" block from module/config.ini into it, or the built-in defaults are used.
- v8 safety: if the full patch fails to compile on your GPU, the module retries a lite patch (no headlights/rays/spiral shadows) before falling back to the original shader.
- v8: cavity AO (sh_ao) darkens creases between walls, ground and objects; shadows from the sun shadow map already land on every object.
- v8 verified on the real dump (60 shaders): 35 patched (world, sky, final pass), 25 Noesis UI shaders untouched, 0 glslang errors.
- Night detection uses the sun elevation (u_sunPos/u_eye) plus fog brightness.
- sh_form, sh_sunlight, sh_gloss, sh_aces: photoreal shading. sh_rays is OFF by default: the sky shader gives the sun in WORLD space, so rays need the camera matrix from the vertex shaders (send vert dump).
