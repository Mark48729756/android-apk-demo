plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "dev.mark.miuxhook"
    compileSdk = 34
    defaultConfig { applicationId = "dev.mark.miuxhook"; minSdk = 33; targetSdk = 34; versionCode = 2; versionName = "0.4" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(project(":miux"))
    compileOnly(project(":xposed-stub"))   // реальные классы Xposed даёт LSPosed в рантайме
}
