package dev.mark.miuxhook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import dev.mark.miux.MiuxConfig

/** Работает и под Vector (LSPosed), и под классическим Xposed: используется только legacy-API, оба фреймворка его держат. */
class HookEntry : IXposedHookLoadPackage {
    override fun handleLoadPackage(lp: XC_LoadPackage.LoadPackageParam) {
        if (lp.packageName == "dev.mark.miuxhook") {
            // приложение узнаёт, что модуль активен
            try {
                XposedHelpers.findAndHookMethod("dev.mark.miuxhook.Diag", lp.classLoader, "isHooked", object : XC_MethodHook() {
                    override fun beforeHookedMethod(p: XC_MethodHook.MethodHookParam) { p.result = true }
                })
            } catch (t: Throwable) { XposedBridge.log("MIUX self: $t") }
            return
        }
        if (Hooks.installed) return   // не ставить хуки дважды в одном процессе
        Hooks.installed = true
        var glassWin = true; var glassAll = false; var press = true; var anim = true
        try {
            val prefs = XSharedPreferences("dev.mark.miuxhook", "config")
            try { prefs.makeWorldReadable() } catch (_: Throwable) {}
            prefs.reload()
            Hooks.prefs = prefs
            MiuxConfig.loadFrom(prefs)
            glassWin = prefs.getBoolean("glass_blur_windows", true); glassAll = prefs.getBoolean("glass_all_dialogs", false)
            press = prefs.getBoolean("fluent_press", true); anim = prefs.getBoolean("fluent_anim", true)
        } catch (t: Throwable) { XposedBridge.log("MIUX prefs (беру значения по умолчанию): $t") }
        try { GlassHooks.install(glassWin, glassAll) } catch (t: Throwable) { XposedBridge.log("MIUX glass: $t") }
        try { FluentHooks.install(press, anim) } catch (t: Throwable) { XposedBridge.log("MIUX fluent: $t") }
    }
}

object Hooks { @Volatile var prefs: XSharedPreferences? = null; @Volatile var installed = false }
