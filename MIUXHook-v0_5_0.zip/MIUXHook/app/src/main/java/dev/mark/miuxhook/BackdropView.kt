package dev.mark.miuxhook

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class BackdropView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val colors = intArrayOf(0xFFFF3D71.toInt(), 0xFF29B6F6.toInt(), 0xFFFFC107.toInt(), 0xFF7C4DFF.toInt(), 0xFF00E676.toInt())
    override fun onDraw(c: Canvas) {
        val t = System.nanoTime() / 1e9f
        c.drawColor(0xFF10121A.toInt())
        p.style = Paint.Style.FILL
        for (i in colors.indices) {
            p.color = colors[i]
            c.drawCircle(width * (0.5f + 0.38f * sin(t * 0.5f + i * 1.3f)), height * (0.5f + 0.38f * cos(t * 0.4f + i * 2.1f)), 90f + 20f * i, p)
        }
        postInvalidateOnAnimation()
    }
}
