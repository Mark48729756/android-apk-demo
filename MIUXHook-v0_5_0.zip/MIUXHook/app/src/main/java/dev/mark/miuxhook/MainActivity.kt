package dev.mark.miuxhook

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import dev.mark.miux.*

class MainActivity : Activity() {
    @Suppress("DEPRECATION")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val prefs: SharedPreferences = try { getSharedPreferences("config", MODE_WORLD_READABLE) }
        catch (e: SecurityException) { getSharedPreferences("config", MODE_PRIVATE) }
        MiuxConfig.init(this, prefs)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = MiuxLayout(this)
        root.backdrop = BackdropView(this)
        root.addView(MiuxToolbar(this, "MIUX Hook"),
            FrameLayout.LayoutParams(-1, dp(56), Gravity.TOP).apply { setMargins(dp(16), dp(44), dp(16), 0) })

        val card = LiquidGlassView(this).apply { cornerDp = 28f }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(16)) }
        fun toggle(key: String, title: String, def: Boolean) {
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            r.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 14f }, LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(MiuxSwitch(this, prefs.getBoolean(key, def)) { prefs.edit().putBoolean(key, it).apply() })
            col.addView(r)
        }
        toggle("glass_blur_windows", "Стекло для окон с блюром (диалоги, шторки, попапы)", true)
        toggle("glass_all_dialogs", "Стекло для ВСЕХ диалогов", false)
        toggle("fluent_press", "Fluent: пружинное нажатие кнопок", true)
        toggle("fluent_anim", "Fluent: пружинные анимации", true)
        col.addView(TextView(this).apply {
            text = "Включи модуль в LSPosed, отметь приложения в области действия и перезапусти их."
            setTextColor(0xCCFFFFFF.toInt()); textSize = 12f; setPadding(0, dp(10), 0, 0)
        })
        card.addView(col, FrameLayout.LayoutParams(-1, -2))
        root.addView(card, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { setMargins(dp(20), dp(120), dp(20), 0) })

        val sheet = MiuxSettingsSheet(this).apply { visibility = View.GONE }
        root.addView(sheet, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply { setMargins(dp(20), 0, dp(20), dp(60)) })

        val diag = LiquidGlassView(this).apply { cornerDp = 28f; visibility = View.GONE }
        val diagText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; setPadding(dp(20), dp(18), dp(20), dp(18)) }
        diag.addView(diagText, FrameLayout.LayoutParams(-1, -2))
        root.addView(diag, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply { setMargins(dp(20), 0, dp(20), dp(60)) })
        fun refreshDiag() {
            val sb = StringBuilder("Диагностика\n")
            for ((ok, line) in Diag.report(this)) sb.append('\n').append(when (ok) { true -> "✅ "; false -> "❌ "; null -> "• " }).append(line)
            diagText.text = sb
        }

        val dock = MiuxDock(this, listOf("🧩" to "Модуль", "🫧" to "Стекло", "🩺" to "Диагноз")) { i ->
            sheet.visibility = if (i == 1) View.VISIBLE else View.GONE
            card.visibility = if (i == 0) View.VISIBLE else View.GONE
            diag.visibility = if (i == 2) View.VISIBLE else View.GONE
            if (i == 2) refreshDiag()
        }
        root.addView(dock, FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM).apply { setMargins(dp(40), 0, dp(40), dp(28)) })
        setContentView(root)
    }
}
