package dev.mark.miuxhook

import android.app.Activity
import android.content.Context
import android.graphics.RuntimeShader
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import dev.mark.miux.GLASS_AGSL

/** Самопроверка: что работает на ЭТОМ устройстве. Показывается на вкладке «Диагностика». */
object Diag {
    /** В хуке для собственного пакета подменяется на true — так приложение узнаёт, что модуль активен. */
    @JvmStatic fun isHooked(): Boolean = false

    private fun prop(k: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("getprop", k))
        val r = p.inputStream.bufferedReader().readText().trim(); p.destroy(); r
    } catch (_: Throwable) { "" }

    fun rom(): String {
        val os = prop("ro.mi.os.version.name"); val code = prop("ro.mi.os.version.code")
        val miui = prop("ro.miui.ui.version.name")
        return when {
            os.isNotEmpty() -> "HyperOS $os${if (code.isNotEmpty()) " ($code)" else ""}"
            miui.isNotEmpty() -> "MIUI $miui"
            else -> "${Build.MANUFACTURER} ${Build.DISPLAY}"
        }
    }

    fun report(a: Activity): List<Pair<Boolean?, String>> {
        val out = ArrayList<Pair<Boolean?, String>>()
        out += null to "Устройство: ${Build.MANUFACTURER} ${Build.MODEL}"
        out += (Build.VERSION.SDK_INT >= 33) to "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), нужен 13+"
        out += null to "Прошивка: ${rom()}"
        out += isHooked() to "Модуль активен в фреймворке (Vector/LSPosed)"
        out += try { RuntimeShader(GLASS_AGSL); true } catch (t: Throwable) { false } to "Шейдер стекла (AGSL) компилируется"
        val sm = a.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val gyro = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) != null || sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
        out += gyro to "Датчик наклона для света"
        out += try { a.windowManager.isCrossWindowBlurEnabled } catch (t: Throwable) { false } to
            "Системный блюр окон включён (экономия энергии может его выключать)"
        return out
    }
}
