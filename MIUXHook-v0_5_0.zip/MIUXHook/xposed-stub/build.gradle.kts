plugins { id("com.android.library") }
android {
    namespace = "de.robv.android.xposed.stub"
    compileSdk = 34
    defaultConfig { minSdk = 33 }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
