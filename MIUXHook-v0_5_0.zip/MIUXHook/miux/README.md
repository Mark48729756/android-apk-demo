# miux — Liquid Glass + пружины + свет от гироскопа

Подключение: скопируй папку `miux` в проект, в `settings.gradle.kts` добавь `include(":miux")`,
в модуле приложения: `implementation(project(":miux"))`. minSdk 33.

Ядро: `Glass.kt` (шейдер), `Spring.kt` (пружины + часы), `GyroLight.kt` (свет),
`LiquidGlassView.kt` / `GlassDrawable.kt` (вью и drawable), `MiuxConfig.kt` (настройки).

Отражения на гранях цветные: берут цвет того, что лежит под краем стекла (см. `refl` в `Glass.kt`).
