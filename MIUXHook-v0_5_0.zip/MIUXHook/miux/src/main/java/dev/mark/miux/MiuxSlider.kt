package dev.mark.miux

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout

/** Слайдер со стеклянным ползунком. */
class MiuxSlider(ctx: Context, private val min: Float, private val max: Float, start: Float,
                 private val onChange: (Float) -> Unit) : FrameLayout(ctx) {
    private val den = resources.displayMetrics.density
    private val thumbW = (40 * den).toInt()
    private val track = View(ctx).apply { background = GradientDrawable().apply { cornerRadius = 3 * den; setColor(0x55FFFFFF) } }
    private val fill = View(ctx).apply {
        background = GradientDrawable().apply { cornerRadius = 3 * den; setColor(0xFF7C9CFF.toInt()) }
        pivotX = 0f
    }
    private val thumb = LiquidGlassView(ctx).apply { cornerDp = -1f }
    var value = start.coerceIn(min, max); private set

    init {
        addView(track, LayoutParams(-1, (6 * den).toInt(), Gravity.CENTER_VERTICAL))
        addView(fill, LayoutParams(-1, (6 * den).toInt(), Gravity.CENTER_VERTICAL))
        addView(thumb, LayoutParams(thumbW, (28 * den).toInt(), Gravity.CENTER_VERTICAL))
        minimumHeight = (36 * den).toInt()
    }

    override fun onLayout(c: Boolean, l: Int, t: Int, r: Int, b: Int) { super.onLayout(c, l, t, r, b); place() }

    private fun place() {
        if (width <= 0) return
        val frac = (value - min) / (max - min)
        val x = (width - thumbW) * frac
        thumb.translationX = x
        fill.scaleX = ((x + thumbW / 2f) / width).coerceIn(0f, 1f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent.requestDisallowInterceptTouchEvent(true)
                val frac = ((e.x - thumbW / 2f) / (width - thumbW)).coerceIn(0f, 1f)
                value = min + frac * (max - min); place(); onChange(value)
            }
        }
        return true
    }
}
