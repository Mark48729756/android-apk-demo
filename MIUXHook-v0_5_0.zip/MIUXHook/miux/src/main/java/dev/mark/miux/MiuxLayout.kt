package dev.mark.miux

import android.content.Context
import android.view.View
import android.widget.FrameLayout

/** Корневой контейнер: [backdrop] лежит снизу, все стеклянные компоненты внутри сами берут с него картинку. */
class MiuxLayout(ctx: Context) : FrameLayout(ctx) {
    var backdrop: View? = null
        set(v) {
            field?.let { removeView(it) }
            field = v
            if (v != null) addView(v, 0, LayoutParams(-1, -1))
        }
}
