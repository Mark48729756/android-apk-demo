package dev.mark.miux

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout

/** Переключатель: цветная дорожка + стеклянный ползунок. */
class MiuxSwitch(ctx: Context, on: Boolean = false, private val onToggle: (Boolean) -> Unit = {}) : FrameLayout(ctx) {
    private val den = resources.displayMetrics.density
    private val tw = (60 * den).toInt(); private val th = (36 * den).toInt()
    private val thW = (44 * den).toInt(); private val thH = (30 * den).toInt(); private val m = 3 * den
    private val bg = GradientDrawable().apply { cornerRadius = th / 2f }
    private val thumb = LiquidGlassView(ctx).apply { cornerDp = -1f }
    var checked = on; private set
    private val offColor = 0x66FFFFFF; private val onColor = 0xFF34C759.toInt()

    init {
        background = bg
        bg.setColor(if (on) onColor else offColor)
        addView(thumb, LayoutParams(thW, thH, Gravity.CENTER_VERTICAL))
        thumb.translationX = pos(on)
        isClickable = true
        setOnClickListener { set(!checked); onToggle(checked) }
    }
    private fun pos(on: Boolean) = if (on) tw - thW - m else m

    fun set(on: Boolean) {
        checked = on
        thumb.animate().translationX(pos(on)).setDuration(320).setInterpolator(OvershootInterpolator(1.6f)).start()
        ValueAnimator.ofArgb(if (on) offColor else onColor, if (on) onColor else offColor).apply {
            duration = 220; addUpdateListener { bg.setColor(it.animatedValue as Int) }; start()
        }
    }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(tw, th); measureChildren(w, h) }
}
