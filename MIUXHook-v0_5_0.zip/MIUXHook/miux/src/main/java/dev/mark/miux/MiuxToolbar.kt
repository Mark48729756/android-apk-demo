package dev.mark.miux

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.TextView

/** Верхняя стеклянная панель с заголовком. */
class MiuxToolbar(ctx: Context, title: String) : LiquidGlassView(ctx) {
    private val label = TextView(ctx).apply {
        text = title; setTextColor(Color.WHITE); textSize = 18f
        typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
    }
    init { cornerDp = 28f; addView(label, LayoutParams(-1, -1)) }
    fun setTitle(t: String) { label.text = t }
}
