package dev.mark.miux

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import kotlin.math.max

/**
 * Модель Liquid Glass: плита стекла с выпуклой фаской (профиль «сквиркл»).
 *  1. Высота фаски h(t) → поверхностная нормаль N (по градиенту SDF и наклону профиля).
 *  2. Луч взгляда (0,0,-1) преломляется по закону Снеллиуса (ior) и проходит толщину стекла.
 *  3. Смещение выборки = T.xy / |T.z| * (толщина + высота). В центре стекло плоское → без искажений.
 *  4. Блик по Блинну-Фонгу от света гироскопа (+ слабый встречный), Френель по краю, лёгкая насыщенность.
 */
const val GLASS_AGSL = """
uniform shader content;
uniform float2 size;
uniform float radius;
uniform float bevel;
uniform float thickness;
uniform float ior;
uniform float aberr;
uniform float tint;
uniform float sat;
uniform float specAmt;
uniform float3 light;
uniform float press;

const float HEIGHT = 0.8;

float sdf(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + r;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}

float2 sdfNormal(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + r;
    float2 s = float2(p.x < 0.0 ? -1.0 : 1.0, p.y < 0.0 ? -1.0 : 1.0);
    if (q.x > 0.0 && q.y > 0.0) return s * normalize(q);
    return q.x > q.y ? float2(s.x, 0.0) : float2(0.0, s.y);
}

float2 clampP(float2 c) { return clamp(c, float2(0.5), size - 0.5); }
float3 tapC(float2 c) { return float3(content.eval(clampP(c)).rgb); }

half4 main(float2 frag) {
    float2 hs = size * 0.5;
    float2 p = frag - hs;
    float d = sdf(p, hs, radius);
    float aa = clamp(0.5 - d, 0.0, 1.0);
    if (aa <= 0.0) return half4(0.0);

    float depth = max(-d, 0.0);
    float t = clamp(depth / bevel, 0.0, 1.0);
    float2 n = sdfNormal(p, hs, radius);

    // профиль фаски H(t) = (1-(1-t)^4)^(1/4) и его производная
    float u = 1.0 - t;
    float u2 = u * u;
    float u4 = u2 * u2;
    float base = max(1.0 - u4, 1e-4);
    float h = pow(base, 0.25);
    float slope = min(u2 * u / pow(base, 0.75) * HEIGHT, 4.0);

    float len = sqrt(1.0 + slope * slope);
    float3 N = float3(n * slope / len, 1.0 / len);

    // преломление (воздух → стекло)
    float eta = 1.0 / ior;
    float cosi = N.z;
    float k = 1.0 - eta * eta * (1.0 - cosi * cosi);
    float3 T = eta * float3(0.0, 0.0, -1.0) + (eta * cosi - sqrt(max(k, 0.0))) * N;
    float travel = thickness + h * bevel * HEIGHT;
    float2 off = T.xy / max(-T.z, 0.05) * travel;

    float3 col = float3(
        content.eval(clampP(frag + off * (1.0 + aberr))).r,
        content.eval(clampP(frag + off)).g,
        content.eval(clampP(frag + off * (1.0 - aberr))).b);

    float luma = dot(col, float3(0.2126, 0.7152, 0.0722));
    col = mix(float3(luma), col, sat);
    col = mix(col, float3(1.0), tint + press * 0.06);

    // свет
    float3 L = normalize(light);
    float3 V = float3(0.0, 0.0, 1.0);
    float3 H1 = normalize(L + V);
    float3 H2 = normalize(float3(-L.x, -L.y, L.z) + V);
    float tilt = 1.0 - N.z;
    float rim = exp(-depth / max(bevel * 0.16, 2.0));
    float s1 = pow(max(dot(N, H1), 0.0), 40.0) * 0.35;
    float s2 = pow(max(dot(N, H2), 0.0), 40.0) * 0.2;
    float fres = tilt * tilt * 0.3;
    float2 ln = normalize(L.xy + float2(1e-4));
    float lit = dot(n, ln);
    float line = smoothstep(2.0, 0.0, depth) * (0.12 + 0.18 * max(lit, 0.0));

    float r1 = pow(max(lit, 0.0), 3.0);
    float r2 = pow(max(-lit, 0.0), 3.0) * 0.5;
    float spec = ((r1 + r2) * rim * 0.9 + s1 + s2) * specAmt * (1.0 + press * 0.6);
    // цветное окружение: берём цвет того, что лежит рядом под краем, и насыщаем его (а не белый блик)
    float3 rc = (tapC(frag - n * bevel * 0.9) + tapC(frag - n * bevel * 1.6)) * 0.5;
    float rmax = max(max(rc.r, rc.g), max(rc.b, 0.2));
    float3 refl = mix(float3(1.0), clamp(rc / rmax, 0.0, 1.0), 0.85);
    col += refl * (spec * 0.9 + fres + line);
    return half4(half3(col * aa), half(aa));
}
"""

/** Общая настройка шейдера для LiquidGlassView и GlassDrawable. */
internal object GlassPainter {
    fun apply(sh: RuntimeShader, w: Int, h: Int, radiusPx: Float, den: Float, press: Float) {
        sh.setFloatUniform("size", w.toFloat(), h.toFloat())
        sh.setFloatUniform("radius", radiusPx)
        sh.setFloatUniform("bevel", max(MiuxConfig.bevel * den, 1f))
        sh.setFloatUniform("thickness", MiuxConfig.strength * den)
        sh.setFloatUniform("ior", MiuxConfig.ior.coerceAtLeast(1.01f))
        sh.setFloatUniform("aberr", MiuxConfig.aberration)
        sh.setFloatUniform("tint", MiuxConfig.tint)
        sh.setFloatUniform("sat", MiuxConfig.saturation)
        sh.setFloatUniform("specAmt", MiuxConfig.specular)
        val l = GyroLight.light
        sh.setFloatUniform("light", l[0], l[1], l[2])
        sh.setFloatUniform("press", press.coerceIn(0f, 1f))
    }

    /** Сначала блюр содержимого, затем шейдер (inner применяется первым). */
    fun effect(sh: RuntimeShader, den: Float): RenderEffect {
        val sigma = (MiuxConfig.blur * den).coerceAtLeast(0.01f)
        return RenderEffect.createChainEffect(
            RenderEffect.createRuntimeShaderEffect(sh, "content"),
            RenderEffect.createBlurEffect(sigma, sigma, Shader.TileMode.CLAMP))
    }
}
