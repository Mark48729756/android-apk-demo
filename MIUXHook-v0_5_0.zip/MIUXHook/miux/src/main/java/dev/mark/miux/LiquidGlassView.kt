package dev.mark.miux

import android.content.Context
import android.graphics.Canvas
import android.graphics.RenderNode
import android.graphics.RuntimeShader
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.min

/**
 * Базовый стеклянный компонент (FrameLayout: внутрь можно класть что угодно). Настройки берёт из [MiuxConfig].
 * Перетаскиваемый ([draggable]) вид ездит на настоящих пружинах: догоняет палец с запаздыванием,
 * после отпускания качается с перелётом, сплющивается/вытягивается по скорости, а нажатие «вдавливается» пружиной.
 */
open class LiquidGlassView @JvmOverloads constructor(ctx: Context, var source: View? = null) : FrameLayout(ctx), LightSink {
    protected val den = resources.displayMetrics.density
    private val shader = RuntimeShader(GLASS_AGSL)
    private val node = RenderNode("miux")
    var cornerDp = -1f          // -1 = полностью круглый
    var draggable = false

    // позиция — по жёсткости/затуханию из MiuxConfig; нажатие — своя, чуть более упругая
    private val springX = Spring(0f, restDelta = 0.05f, restSpeed = 1f)
    private val springY = Spring(0f, restDelta = 0.05f, restSpeed = 1f)
    private val pressSpring = Spring(0f, 600f, 26f, restDelta = 0.002f, restSpeed = 0.02f)
    private var downX = 0f; private var downY = 0f; private var startX = 0f; private var startY = 0f

    override val alive: Boolean get() = isAttachedToWindow
    override val rotation: Int get() = display?.rotation ?: 0
    override fun onLightChanged() { invalidate() }

    init {
        setWillNotDraw(false); clipChildren = false; clipToPadding = false
        springX.onUpdate = { applyPhysics() }; springY.onUpdate = { applyPhysics() }
        pressSpring.onUpdate = { applyPhysics() }
    }

    private fun applyPhysics() {
        val vx = springX.velocity; val vy = springY.velocity
        translationX = springX.value; translationY = springY.value
        val p = pressSpring.value
        scaleX = 1f + min(abs(vx) / 4500f, 0.22f) - min(abs(vy) / 9000f, 0.1f) + 0.06f * p
        scaleY = 1f + min(abs(vy) / 4500f, 0.22f) - min(abs(vx) / 9000f, 0.1f) + 0.06f * p
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); GyroLight.attach(context, this) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!draggable) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!springX.isRunning) springX.snapTo(translationX)
                if (!springY.isRunning) springY.snapTo(translationY)
                downX = e.rawX; downY = e.rawY; startX = springX.target; startY = springY.target
                parent.requestDisallowInterceptTouchEvent(true)
                pressSpring.animateTo(1f)
            }
            // цель двигается за пальцем, скорость пружины сохраняется → вид «догоняет» с инерцией
            MotionEvent.ACTION_MOVE -> {
                springX.animateTo(startX + e.rawX - downX)
                springY.animateTo(startY + e.rawY - downY)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> pressSpring.animateTo(0f)
        }
        return true
    }

    private fun findSource(): View? {
        source?.let { return it }
        var p = parent
        while (p != null) { if (p is MiuxLayout) return p.backdrop; p = p.parent }
        return null
    }

    override fun onDraw(canvas: Canvas) {
        val src = findSource()
        if (src == null || !canvas.isHardwareAccelerated || width <= 0 || height <= 0) return
        val w = width; val h = height
        val loc = IntArray(2); val sl = IntArray(2)
        getLocationInWindow(loc); src.getLocationInWindow(sl)
        val cx = loc[0] - sl[0] + w * scaleX / 2f
        val cy = loc[1] - sl[1] + h * scaleY / 2f
        node.setPosition(0, 0, w, h)
        val rec = node.beginRecording(w, h)
        rec.translate(w / 2f, h / 2f); rec.scale(1f / scaleX, 1f / scaleY); rec.translate(-w / 2f, -h / 2f)
        rec.translate(-(cx - w / 2f), -(cy - h / 2f))
        src.draw(rec)
        node.endRecording()

        val r = if (cornerDp < 0) min(w, h) / 2f else min(cornerDp * den, min(w, h) / 2f)
        GlassPainter.apply(shader, w, h, r, den, pressSpring.value)
        node.setRenderEffect(GlassPainter.effect(shader, den))
        canvas.drawRenderNode(node)
        postInvalidateOnAnimation()
    }
}
