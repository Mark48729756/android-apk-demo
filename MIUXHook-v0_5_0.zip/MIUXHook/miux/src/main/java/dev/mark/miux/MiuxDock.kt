package dev.mark.miux

import android.content.Context
import android.graphics.Color
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView

/** Нижний док/таб-бар: стеклянная панель, выбранный пункт подсвечен «каплей» стекла, которая переливается на пружине. */
class MiuxDock(
    ctx: Context,
    private val items: List<Pair<String, String>>, // иконка (эмодзи) → подпись
    private val onSelect: (Int) -> Unit
) : LiquidGlassView(ctx) {
    private val pad = 6 * den
    private val indicator = LiquidGlassView(ctx)
    private val row = LinearLayout(ctx)
    private val tabs = ArrayList<TextView>()
    var selected = 0; private set
    private var itemW = 0f

    init {
        cornerDp = -1f
        indicator.cornerDp = -1f
        addView(indicator, LayoutParams(10, 10, Gravity.CENTER_VERTICAL))
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(pad.toInt(), 0, pad.toInt(), 0)
        addView(row, LayoutParams(-1, -1))
        items.forEachIndexed { i, (icon, label) ->
            val tv = TextView(ctx).apply {
                val s = SpannableString("$icon\n$label")
                s.setSpan(RelativeSizeSpan(1.9f), 0, icon.length, 0)
                text = s; textSize = 10f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                setOnClickListener { select(i) }
            }
            tabs.add(tv)
            row.addView(tv, LinearLayout.LayoutParams(0, -1, 1f))
        }
        refresh()
    }

    private fun refresh() { tabs.forEachIndexed { i, t -> t.alpha = if (i == selected) 1f else 0.7f } }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        itemW = (w - 2 * pad) / items.size
        indicator.layoutParams = LayoutParams(itemW.toInt(), (h - 2 * pad).toInt(), Gravity.CENTER_VERTICAL)
        indicator.translationX = pad + selected * itemW
    }

    fun select(i: Int) {
        if (i == selected) return
        selected = i; refresh()
        indicator.animate().cancel()
        indicator.animate().translationX(pad + i * itemW).scaleX(1.18f).setDuration(200)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                indicator.animate().scaleX(1f).setDuration(280).setInterpolator(OvershootInterpolator(2.2f)).start()
            }.start()
        onSelect(i)
    }
}
