package dev.mark.miux

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/** Готовая панель настроек стекла: блюр, преломление, аберрация, пружина и т.д. Меняет [MiuxConfig] на лету. */
class MiuxSettingsSheet(ctx: Context) : LiquidGlassView(ctx) {
    private val col = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        val p = (20 * den).toInt(); setPadding(p, p, p, p)
    }
    init { cornerDp = 32f; addView(col, LayoutParams(-1, -2)); build() }

    private fun text(s: String, size: Float, bold: Boolean = false) = TextView(context).apply {
        text = s; textSize = size; setTextColor(Color.WHITE); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun build() {
        col.removeAllViews()
        col.addView(text("Настройки MIUX", 18f, true))
        row("Преломление (dp)", 0f, 60f, MiuxConfig.strength) { MiuxConfig.strength = it }
        row("Ширина линзы (dp)", 6f, 70f, MiuxConfig.bevel) { MiuxConfig.bevel = it }
        row("Блюр (dp)", 0f, 16f, MiuxConfig.blur) { MiuxConfig.blur = it }
        row("Аберрация (%)", 0f, 30f, MiuxConfig.aberration * 100) { MiuxConfig.aberration = it / 100 }
        row("Светлость (%)", 0f, 30f, MiuxConfig.tint * 100) { MiuxConfig.tint = it / 100 }
        row("Показатель преломления", 1.1f, 2.2f, MiuxConfig.ior) { MiuxConfig.ior = it }
        row("Насыщенность (%)", 50f, 200f, MiuxConfig.saturation * 100) { MiuxConfig.saturation = it / 100 }
        row("Блики (%)", 0f, 200f, MiuxConfig.specular * 100) { MiuxConfig.specular = it / 100 }
        row("Свет от гироскопа (%)", 0f, 200f, MiuxConfig.gyro * 100) { MiuxConfig.gyro = it / 100 }
        row("Жёсткость пружины", 100f, 800f, MiuxConfig.stiffness) { MiuxConfig.stiffness = it }
        row("Затухание пружины", 8f, 50f, MiuxConfig.damping) { MiuxConfig.damping = it }
        col.addView(text("Сбросить", 15f, true).apply {
            gravity = Gravity.CENTER; setPadding(0, (14 * den).toInt(), 0, 0)
            setOnClickListener { MiuxConfig.reset(); build() }
        })
    }

    private fun row(name: String, min: Float, max: Float, v: Float, set: (Float) -> Unit) {
        val t = text("$name: ${"%.1f".format(v)}", 13f)
        col.addView(t, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (8 * den).toInt() })
        col.addView(MiuxSlider(context, min, max, v) { x ->
            set(x); MiuxConfig.save(); t.text = "$name: ${"%.1f".format(x)}"
        }, LinearLayout.LayoutParams(-1, -2))
    }
}
