package com.rageroleplay.launcher

import android.content.SharedPreferences
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

val Accent = Color(0xFFE5360F)
val Panel = Color(0xFF1C1C22)
val FieldBg = Color(0xFF26262C)

/** Всё состояние лаунчера + сохранение настроек. */
class UiState(private val sp: SharedPreferences) {
    var online by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var status by mutableStateOf("")
    var progress by mutableStateOf(0f)
    var settings by mutableStateOf(false)
    var hud by mutableStateOf(false)
    var confirm by mutableStateOf(false)
    var name by mutableStateOf(sp.getString("name", "") ?: "")
    var surname by mutableStateOf(sp.getString("surname", "") ?: "")
    var fx by mutableStateOf(sp.getFloat("fx", 100f))
    var voice by mutableStateOf(sp.getBoolean("voice", true))
    var quality by mutableStateOf(sp.getInt("quality", 1))
    var draw by mutableStateOf(sp.getFloat("draw", 150f))
    var autoLogin by mutableStateOf(sp.getBoolean("auto", false))
    val nick get() = "${name}_${surname}"
    fun save() = sp.edit().putString("name", name).putString("surname", surname)
        .putFloat("fx", fx).putBoolean("voice", voice).putInt("quality", quality)
        .putFloat("draw", draw).putBoolean("auto", autoLogin).apply()
}

@Composable
fun AnimatedBg() {
    val t by rememberInfiniteTransition(label = "bg").animateFloat(
        0f, 6.2832f, infiniteRepeatable(tween(22000, easing = LinearEasing)), label = "t")
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        drawRect(Brush.linearGradient(listOf(Color(0xFF0A0A10), Color(0xFF1A0508)), Offset.Zero, Offset(w, h)))
        fun blob(x: Float, y: Float, r: Float, c: Color) =
            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), Offset(x, y), r), r, Offset(x, y))
        blob(w * (0.75f + 0.08f * cos(t)), h * (0.35f + 0.1f * sin(t)), h * 0.9f, Color(0x66E5260F))
        blob(w * (0.2f + 0.07f * sin(t)), h * (0.85f + 0.06f * cos(t)), h * 0.7f, Color(0x44B3001B))
        blob(w * (0.5f + 0.1f * cos(t + 2)), h * (0.1f + 0.05f * sin(t + 1)), h * 0.6f, Color(0x2AFF5A36))
        drawRect(Brush.radialGradient(listOf(Color.Transparent, Color(0xCC000000)), center, w * 0.75f))
    }
}

@Composable
fun PlayButton(label: String, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier.height(76.dp)
            .shadow(if (enabled) 18.dp else 0.dp, shape, ambientColor = Accent, spotColor = Accent)
            .clip(shape)
            .background(Brush.verticalGradient(
                if (enabled) listOf(Color(0xFFFF4A24), Color(0xFFC81A08)) else listOf(Color(0xFF55555C), Color(0xFF3A3A40))))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp) }
}

@Composable
fun NickField(value: String, hint: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier.height(54.dp).clip(shape).background(FieldBg)
            .border(1.dp, Color(0x33FFFFFF), shape).padding(horizontal = 18.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        if (value.isEmpty()) Text(hint, color = Color(0x88FFFFFF), fontSize = 18.sp)
        BasicTextField(
            value = value, onValueChange = { onChange(it.filter { c -> c.isLetter() }.take(20)) },
            singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
            cursorBrush = SolidColor(Accent), modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun RoundIcon(text: String, onClick: () -> Unit) {
    Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0x55000000)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) { Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun LauncherUi(st: UiState, onPlay: () -> Unit, onAnswer: (Boolean) -> Unit, onOpen: (String) -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AnimatedBg()
        when {
            st.hud -> HudScreen { st.hud = false }
            st.settings -> SettingsScreen(st)
            st.busy -> LoadingScreen(st)
            else -> MainScreen(st, onPlay, onOpen)
        }
        if (st.confirm) AlertDialog(
            onDismissRequest = {}, containerColor = Panel,
            title = { Text("Игра не установлена", color = Color.White, fontWeight = FontWeight.Bold) },
            text = { Text("Чтобы скачать, нажмите «Продолжить».", color = Color(0xCCFFFFFF)) },
            confirmButton = { TextButton({ onAnswer(true) }) { Text("Продолжить", color = Accent, fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton({ onAnswer(false) }) { Text("Отмена", color = Color(0xAAFFFFFF)) } }
        )
    }
}

@Composable
fun MainScreen(st: UiState, onPlay: () -> Unit, onOpen: (String) -> Unit) {
    Box(Modifier.fillMaxSize().padding(horizontal = 56.dp, vertical = 32.dp)) {
        Row(Modifier.align(Alignment.TopStart), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            RoundIcon("TG") { onOpen(Config.TELEGRAM_URL) }
            RoundIcon("VK") { onOpen(Config.VK_URL) }
            RoundIcon("HUD") { st.hud = true }
        }
        Box(Modifier.align(Alignment.TopEnd)) { RoundIcon("⚙") { st.settings = true } }
        Column(Modifier.align(Alignment.TopCenter), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("RAGE", color = Accent, fontSize = 56.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("ROLEPLAY", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp)
        }
        Column(Modifier.align(Alignment.BottomStart).width(300.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            NickField(st.name, "Имя", Modifier.fillMaxWidth()) { st.name = it; st.save() }
            NickField(st.surname, "Фамилия", Modifier.fillMaxWidth()) { st.surname = it; st.save() }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(if (st.online) Color(0xFF33D17A) else Accent))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Сервер", color = Color(0x99FFFFFF), fontSize = 12.sp)
                    Text(Config.SERVER_NAME, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (!st.online) Text("Сервер временно не работает", color = Color(0xFFFF6A5A), fontSize = 12.sp)
                }
            }
        }
        PlayButton("ИГРАТЬ", st.online, Modifier.align(Alignment.BottomEnd).width(260.dp), onPlay)
    }
}

@Composable
fun LoadingScreen(st: UiState) {
    Box(Modifier.fillMaxSize().padding(horizontal = 56.dp, vertical = 36.dp)) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("RAGE", color = Accent, fontSize = 64.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
            Text("ROLEPLAY", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black, letterSpacing = 8.sp)
        }
        Column(Modifier.align(Alignment.BottomCenter)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(st.status, color = Color(0xCCFFFFFF), fontSize = 14.sp)
                Text("${(st.progress * 100).toInt()}%", color = Color(0xCCFFFFFF), fontSize = 14.sp)
            }
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x33FFFFFF))) {
                Box(Modifier.fillMaxWidth(st.progress.coerceIn(0.01f, 1f)).fillMaxHeight().background(Accent))
            }
        }
    }
}

@Composable
fun SettingsScreen(st: UiState) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val tabs = listOf("Звук", "Графика", "Безопасность")
    Box(Modifier.fillMaxSize().background(Color(0xE6000000)).padding(horizontal = 56.dp, vertical = 28.dp)) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            Column(Modifier.width(240.dp).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Настройки", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                tabs.forEachIndexed { i, t ->
                    val sel = i == tab
                    Box(Modifier.fillMaxWidth().height(48.dp).background(if (sel) Color.White else Color(0xFF14172A))
                        .clickable { tab = i }, contentAlignment = Alignment.Center) {
                        Text(t, color = if (sel) Color.Black else Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(Panel)
                .padding(24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                when (tab) {
                    0 -> {
                        SliderRow("Громкость эффектов", st.fx, 0f, 100f) { st.fx = it }
                        SwitchRow("Включить войс-чат", st.voice) { st.voice = it; st.save() }
                    }
                    1 -> {
                        Text("Качество графики", color = Color.White, fontSize = 16.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf("Низкая", "Средняя", "Высокая").forEachIndexed { i, n ->
                                val sel = st.quality == i
                                Box(Modifier.clip(RoundedCornerShape(10.dp)).background(if (sel) Accent else FieldBg)
                                    .clickable { st.quality = i; st.save() }.padding(horizontal = 20.dp, vertical = 12.dp)) {
                                    Text(n, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        SliderRow("Дальность прорисовки", st.draw, 50f, 300f) { st.draw = it }
                    }
                    else -> SwitchRow("Авто-вход", st.autoLogin) { st.autoLogin = it; st.save() }
                }
            }
        }
        Box(Modifier.align(Alignment.TopEnd)) { RoundIcon("✕") { st.save(); st.settings = false } }
    }
}

@Composable
fun SliderRow(title: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Color.White, fontSize = 16.sp)
            Text("%.0f".format(value), color = Color.White, fontSize = 16.sp)
        }
        Slider(value, onChange, valueRange = min..max, colors = SliderDefaults.colors(
            thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color(0xFF4A5060)))
    }
}

@Composable
fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 16.sp)
        Switch(checked, onChange, colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White, checkedTrackColor = Accent, uncheckedTrackColor = Color(0xFF3A3F55)))
    }
}
