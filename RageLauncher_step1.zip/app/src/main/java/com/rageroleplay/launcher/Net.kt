package com.rageroleplay.launcher

import java.io.File
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipFile

object Net {

    /** SA-MP/open.mp query 'i' — если сервер ответил, значит он работает. */
    fun isServerOnline(host: String, port: Int, timeoutMs: Int = 2500): Boolean {
        return try {
            val addr = InetAddress.getByName(host)
            val ip = addr.address
            val pkt = ByteArray(11)
            "SAMP".toByteArray().copyInto(pkt, 0)
            ip.copyInto(pkt, 4)
            pkt[8] = (port and 0xFF).toByte()
            pkt[9] = ((port shr 8) and 0xFF).toByte()
            pkt[10] = 'i'.code.toByte()
            DatagramSocket().use { s ->
                s.soTimeout = timeoutMs
                s.send(DatagramPacket(pkt, pkt.size, addr, port))
                val buf = ByteArray(512)
                val resp = DatagramPacket(buf, buf.size)
                s.receive(resp)
                resp.length >= 11
            }
        } catch (e: Exception) {
            false
        }
    }

    /** Читает маленький текст (манифест). Большие файлы отклоняет, чтобы не словить OutOfMemory. */
    fun fetchText(url: String, maxBytes: Int = 256 * 1024): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10000; c.readTimeout = 15000
            c.instanceFollowRedirects = true
            if (c.responseCode !in 200..299) throw RuntimeException("Манифест: HTTP ${c.responseCode}")
            if (c.contentLengthLong > maxBytes)
                throw RuntimeException("MANIFEST_URL ведёт на большой файл, а не на JSON-манифест")
            val out = java.io.ByteArrayOutputStream()
            c.inputStream.use { inp ->
                val buf = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > maxBytes) throw RuntimeException("MANIFEST_URL ведёт на большой файл, а не на JSON-манифест")
                    out.write(buf, 0, n)
                }
            }
            return out.toString("UTF-8")
        } finally { c.disconnect() }
    }

    /** Скачивание с докачкой. onProgress(скачано, всего). */
    fun download(url: String, dest: File, onProgress: (Long, Long) -> Unit) {
        dest.parentFile?.mkdirs()
        var have = if (dest.exists()) dest.length() else 0L
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
        c.connect()
        val code = c.responseCode
        if (code == 416) { c.disconnect(); dest.delete(); return download(url, dest, onProgress) } // битая докачка — начинаем заново
        val append = code == 206
        if (!append) have = 0
        if (code !in 200..299) throw RuntimeException("HTTP $code")
        val total = have + c.contentLengthLong.coerceAtLeast(0)
        FileOutputStream(dest, append).use { out ->
            c.inputStream.use { inp ->
                val buf = ByteArray(64 * 1024)
                var done = have
                var last = 0L
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    val now = System.currentTimeMillis()
                    if (now - last > 80) { onProgress(done, total); last = now }
                }
                onProgress(done, total)
            }
        }
    }

    fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { i ->
            val b = ByteArray(1 shl 16)
            while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun unzip(zip: File, outDir: File, onProgress: (Int, Int) -> Unit) {
        outDir.mkdirs()
        val canon = outDir.canonicalPath
        ZipFile(zip).use { z ->
            val entries = z.entries().toList()
            entries.forEachIndexed { i, e ->
                val f = File(outDir, e.name)
                if (!f.canonicalPath.startsWith(canon)) return@forEachIndexed // защита от zip-slip
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    z.getInputStream(e).use { inp -> FileOutputStream(f).use { inp.copyTo(it) } }
                }
                if (i % 20 == 0) onProgress(i, entries.size)
            }
            onProgress(entries.size, entries.size)
        }
    }
}
