package com.rageroleplay.launcher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Макет игрового HUD (деньги, здоровье/броня, оружие, радар, меню, микрофон, кнопки действий).
 * Это Compose-компонент: его можно показать поверх клиента, когда клиент будет готов принимать оверлей.
 * Сейчас открывается кнопкой «HUD» на главном экране — для предпросмотра внешнего вида.
 */
@Composable
fun HudScreen(money: Int = 205950, health: Float = 0.8f, armor: Float = 0.35f, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF5B7FA6), Color(0xFFE9A77B))))) {
        Column(Modifier.align(Alignment.TopStart).padding(start = 48.dp, top = 20.dp).width(330.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    HudPanel(Modifier.fillMaxWidth().height(40.dp)) {
                        Text("₽  " + "%,d".format(money).replace(',', ' '), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                    HudPanel(Modifier.fillMaxWidth().height(56.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            HudBar(health, Color(0xFFE5260F)); HudBar(armor, Color(0xFF33D17A))
                        }
                    }
                    HudPanel(Modifier.fillMaxWidth().height(72.dp)) {
                        Text("КУЛАК", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    }
                }
                Minimap(Modifier.size(150.dp))
            }
            HudPanel(Modifier.width(150.dp).height(44.dp).clickable { }) {
                Text("≡  Меню", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text("Добро пожаловать на Rage Roleplay", color = Color(0xFFFFD84A), fontSize = 14.sp,
            modifier = Modifier.align(Alignment.TopStart).padding(start = 400.dp, top = 24.dp))
        Box(Modifier.align(Alignment.BottomStart).padding(start = 48.dp, bottom = 28.dp).size(72.dp).clip(CircleShape)
            .background(Color(0x99000000)), contentAlignment = Alignment.Center) {
            Text("MIC", color = Color.White, fontWeight = FontWeight.Black)
        }
        Column(Modifier.align(Alignment.BottomEnd).padding(end = 40.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            ActionButton("УДАР"); ActionButton("БЕГ")
        }
        Text("RED", color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp))
        Box(Modifier.align(Alignment.TopEnd).padding(24.dp)) { RoundIcon("✕", onClose) }
    }
}

@Composable
private fun HudPanel(modifier: Modifier, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(modifier.clip(shape).background(Brush.horizontalGradient(listOf(Color(0xDD2A2A30), Color(0xDD7A3A22))))
        .padding(horizontal = 14.dp), contentAlignment = Alignment.CenterStart) { content() }
}

@Composable
private fun HudBar(value: Float, color: Color) {
    Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0x66000000))) {
        Box(Modifier.fillMaxWidth(value.coerceIn(0.02f, 1f)).fillMaxHeight().background(color))
    }
}

@Composable
private fun Minimap(modifier: Modifier) {
    Box(modifier.clip(CircleShape).background(Color(0xFF2F4A3A)).border(3.dp, Color(0xCC20202A), CircleShape),
        contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val step = size.width / 6
            for (i in 1..5) {
                drawLine(Color(0x33FFFFFF), Offset(i * step, 0f), Offset(i * step, size.height), 2f)
                drawLine(Color(0x33FFFFFF), Offset(0f, i * step), Offset(size.width, i * step), 2f)
            }
            drawCircle(Color.White, size.width * 0.07f, center)
            drawCircle(Accent, size.width * 0.04f, center)
        }
    }
}

@Composable
private fun ActionButton(label: String) {
    Box(Modifier.size(84.dp).clip(CircleShape).background(Color(0x66000000)).border(3.dp, Color.Black, CircleShape)
        .clickable { }, contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
    }
}
