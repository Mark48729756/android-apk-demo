package com.rageroleplay.launcher

/**
 * НАСТРОЙКИ ЛАУНЧЕРА. Всё, что нужно поменять, — здесь.
 */
object Config {
    const val GAME_NAME = "RAGE ROLEPLAY"
    const val SERVER_NAME = "Red"

    // Адрес сервера хранится не открытым текстом (чтобы не светился в списке строк).
    // Сгенерировано: xor(ключ 0x5A) -> base64 строки "188.127.241.74:4874"
    private const val KEY = 0x5A
    private const val HOST_ENC = "a2trZGtoK2d1Z2dnZw==" // заглушка, см. Secret.encode ниже
    private val ENC_BYTES = intArrayOf(
        107, 98, 98, 116, 107, 104, 45, 116, 110, 110, 107, 116, 45, 108, 107, 116, 45, 105, 108 // не используется
    )

    // Реальный адрес — собирается из кусочков и маскируется XOR'ом в рантайме.
    private val HOST_PARTS = intArrayOf(188 xor 0x33, 127 xor 0x33, 241 xor 0x33, 74 xor 0x33)
    private val PORT_ENC = 4874 xor 0x1337

    val host: String get() = HOST_PARTS.joinToString(".") { (it xor 0x33).toString() }
    val port: Int get() = PORT_ENC xor 0x1337

    /**
     * URL JSON-манифеста, который лежит У ВАС (GitHub Releases / ваш хостинг / S3).
     * Формат — в README.md. Пока пусто — лаунчер покажет подсказку.
     */
    const val MANIFEST_URL = "https://github.com/Mark48729756/Samp/releases/download/v1/cache.zip"

    /** Пакет клиента мультиплеера, который устанавливает лаунчер. */
    const val CLIENT_PACKAGE = "com.alyn.resamp"

    /** Ссылки на соцсети (пусто — иконка ничего не открывает). */
    const val TELEGRAM_URL = ""
    const val VK_URL = ""
}
