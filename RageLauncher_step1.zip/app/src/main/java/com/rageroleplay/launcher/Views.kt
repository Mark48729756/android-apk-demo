package com.rageroleplay.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

/** Анимированный тёмно-красный фон с плывущими световыми пятнами. */
class BgView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, (Math.PI * 2).toFloat()).apply {
        duration = 22000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, w, h, 0xFF0A0A10.toInt(), 0xFF1A0508.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        blob(c, w * (0.75f + 0.08f * cos(t)), h * (0.35f + 0.1f * sin(t)), h * 0.9f, 0x66E5260F)
        blob(c, w * (0.2f + 0.07f * sin(t * 1f)), h * (0.85f + 0.06f * cos(t)), h * 0.7f, 0x44B3001B)
        blob(c, w * (0.5f + 0.1f * cos(t + 2)), h * (0.1f + 0.05f * sin(t + 1)), h * 0.6f, 0x2AFF5A36)
        // виньетка
        p.shader = RadialGradient(w / 2, h / 2, w * 0.75f, 0x00000000, 0xCC000000.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null
    }

    private fun blob(c: Canvas, x: Float, y: Float, r: Float, col: Int) {
        p.shader = RadialGradient(x, y, r, col, col and 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
    }
}

/** Красивый скруглённый прогресс-бар со свечением. */
class RageProgress(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    var progress = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = h / 2
        p.shader = null; p.color = 0x33FFFFFF
        c.drawRoundRect(0f, 0f, w, h, r, r, p)
        val fw = (w * progress).coerceAtLeast(if (progress > 0f) h else 0f)
        if (fw > 0) {
            p.shader = LinearGradient(0f, 0f, fw, 0f, 0xFFFF6A3D.toInt(), 0xFFE5260F.toInt(), Shader.TileMode.CLAMP)
            c.drawRoundRect(0f, 0f, fw, h, r, r, p)
            p.shader = null
        }
    }
}

/** Кнопка «ИГРАТЬ» с градиентом. */
class PlayButton(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        textAlign = Paint.Align.CENTER; letterSpacing = 0.08f
    }
    var label = "ИГРАТЬ"; set(v) { field = v; invalidate() }
    var enabledLook = true; set(v) { field = v; invalidate() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = h * 0.28f
        p.setShadowLayer(h * 0.25f, 0f, h * 0.06f, 0xAAE5260F.toInt())
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        p.shader = if (enabledLook)
            LinearGradient(0f, 0f, 0f, h, 0xFFFF4A24.toInt(), 0xFFC81A08.toInt(), Shader.TileMode.CLAMP)
        else LinearGradient(0f, 0f, 0f, h, 0xFF55555C.toInt(), 0xFF3A3A40.toInt(), Shader.TileMode.CLAMP)
        val pad = h * 0.12f
        c.drawRoundRect(pad, pad, w - pad, h - pad, r, r, p)
        p.shader = null; p.clearShadowLayer()
        tp.textSize = h * 0.34f
        c.drawText(label, w / 2, h / 2 + tp.textSize * 0.35f, tp)
    }
}
