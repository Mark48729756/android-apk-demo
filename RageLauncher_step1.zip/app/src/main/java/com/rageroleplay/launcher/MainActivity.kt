package com.rageroleplay.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var st: UiState
    @Volatile private var alive = true
    @Volatile private var answer: CountDownLatch? = null
    @Volatile private var answerOk = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = UiState(getSharedPreferences("launcher", Context.MODE_PRIVATE))
        immersive()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent)) {
                LauncherUi(st, ::onPlay, ::onAnswer, ::openUrl)
            }
        }
        startStatusLoop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) immersive() }
    override fun onDestroy() { alive = false; answer?.countDown(); super.onDestroy() }

    private fun immersive() {
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.also {
                it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun openUrl(url: String) {
        if (url.isBlank()) return
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
    }

    private fun toast(t: String) = ui.post { Toast.makeText(this, t, Toast.LENGTH_LONG).show() }

    private fun startStatusLoop() {
        thread(isDaemon = true) {
            while (alive) {
                st.online = Net.isServerOnline(Config.host, Config.port)
                Thread.sleep(8000)
            }
        }
    }

    private fun setStatus(text: String, p: Float) { st.status = text; st.progress = p }

    private fun onPlay() {
        if (st.busy) return
        if (!st.online) { toast("Сервер временно не работает"); return }
        if (st.name.length < 3 || st.surname.length < 3) { toast("Введите имя и фамилию (минимум 3 буквы)"); return }
        if (Config.MANIFEST_URL.isBlank()) { toast("Укажите MANIFEST_URL в Config.kt (см. README)"); return }
        st.busy = true
        thread {
            try { pipeline() } catch (e: Throwable) {
                toast("Ошибка: " + (if (e is OutOfMemoryError) "не хватило памяти" else e.message ?: e.javaClass.simpleName))
            } finally { st.busy = false }
        }
    }

    private fun onAnswer(ok: Boolean) { answerOk = ok; st.confirm = false; answer?.countDown() }

    /** Окно «Игра не установлена». Вызывается из фонового потока, ждёт ответа игрока. */
    private fun confirmDownload(): Boolean {
        val l = CountDownLatch(1)
        answer = l; answerOk = false; st.confirm = true
        l.await()
        return answerOk && alive
    }

    private fun pipeline() {
        setStatus("Проверка обновлений…", 0f)
        val url = Config.MANIFEST_URL
        // Если в MANIFEST_URL лежит прямая ссылка на .zip с кэшем — считаем её кэшем, а не манифестом
        val m = if (url.substringBefore('?').endsWith(".zip", ignoreCase = true))
            JSONObject().put("version", "1").put("cache", JSONObject().put("url", url))
        else JSONObject(Net.fetchText(url))
        val version = m.optString("version", "1")
        val base = getExternalFilesDir(null) ?: filesDir
        val dataDir = File(base, "gamedata")
        val stamp = File(base, "cache.version")

        val cache = m.optJSONObject("cache")
        val needCache = cache != null && (!stamp.exists() || stamp.readText() != version || !dataDir.exists())
        val client = m.optJSONObject("client")
        val pkg = client?.optString("package", Config.CLIENT_PACKAGE) ?: Config.CLIENT_PACKAGE
        val wantCode = client?.optLong("versionCode", 0) ?: 0
        val haveCode = installedVersionCode(pkg)
        val needClient = client != null && (haveCode < 0 || haveCode < wantCode)

        if (needCache || needClient) {
            if (!confirmDownload()) return
        }

        // 1) КЭШ GTA
        if (cache != null && needCache) {
            val zip = File(base, "cache.zip")
            setStatus("Загрузка кэша игры…", 0f)
            Net.download(cache.getString("url"), zip) { d, t ->
                val pr = if (t > 0) d.toFloat() / t else 0f
                setStatus("Загрузка кэша игры… ${(pr * 100).toInt()}%  (${d shr 20} / ${t shr 20} МБ)", pr)
            }
            val sha = cache.optString("sha256", "")
            if (sha.isNotEmpty() && !Net.sha256(zip).equals(sha, true)) { zip.delete(); throw RuntimeException("Кэш повреждён, попробуйте ещё раз") }
            setStatus("Распаковка…", 0f)
            Net.unzip(zip, dataDir) { i, n -> setStatus("Распаковка… ${i * 100 / n.coerceAtLeast(1)}%", i.toFloat() / n.coerceAtLeast(1)) }
            zip.delete(); stamp.writeText(version)
        }

        // 2) КЛИЕНТ МУЛЬТИПЛЕЕРА
        if (client != null && needClient) {
            val apk = File(base, "client.apk")
            apk.delete()
            setStatus("Загрузка клиента…", 0f)
            Net.download(client.getString("url"), apk) { d, t ->
                val pr = if (t > 0) d.toFloat() / t else 0f
                setStatus("Загрузка клиента… ${(pr * 100).toInt()}%", pr)
            }
            setStatus("Установка клиента…", 1f)
            installApk(apk)
            return // после установки игрок возвращается и жмёт «Играть» ещё раз
        }

        // 3) ЗАПУСК
        setStatus("Запуск…", 1f)
        val launch = packageManager.getLaunchIntentForPackage(pkg)
            ?: throw RuntimeException("Клиент не установлен")
        launch.putExtra("host", Config.host).putExtra("port", Config.port)
            .putExtra("server", Config.SERVER_NAME).putExtra("datadir", dataDir.absolutePath)
            .putExtra("nick", st.nick).putExtra("fx", st.fx / 100f).putExtra("voice", st.voice)
            .putExtra("quality", st.quality).putExtra("draw", st.draw).putExtra("autologin", st.autoLogin)
        ui.post { startActivity(launch) }
    }

    @Suppress("DEPRECATION")
    private fun installedVersionCode(pkg: String): Long = try {
        val i = packageManager.getPackageInfo(pkg, 0)
        if (Build.VERSION.SDK_INT >= 28) i.longVersionCode else i.versionCode.toLong()
    } catch (e: PackageManager.NameNotFoundException) { -1 }

    private fun installApk(apk: File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            ui.post {
                Toast.makeText(this, "Разрешите установку из этого источника и нажмите «Играть» снова", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            }
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.files", apk)
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ui.post { startActivity(i) }
    }
}
