package com.rageroleplay.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var play: PlayButton
    private lateinit var progress: RageProgress
    private lateinit var status: TextView
    private lateinit var serverName: TextView
    private lateinit var serverNote: TextView
    private lateinit var dot: View

    @Volatile private var serverOnline = false
    @Volatile private var busy = false
    @Volatile private var alive = true

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        goImmersive()
        buildUi()
        startStatusLoop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus); if (hasFocus) goImmersive()
    }

    override fun onDestroy() { alive = false; super.onDestroy() }

    @Suppress("DEPRECATION")
    private fun goImmersive() {
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.also {
                it.layoutInDisplayCutoutMode =
                    android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.addView(BgView(this), ViewGroup.LayoutParams(-1, -1))

        // ЗАГОЛОВОК
        val title = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        title.addView(TextView(this).apply {
            text = "RAGE"; setTextColor(0xFFFF4A24.toInt()); textSize = 54f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL); letterSpacing = 0.06f
            setShadowLayer(30f, 0f, 0f, 0xAAE5260F.toInt())
        })
        title.addView(TextView(this).apply {
            text = "ROLEPLAY"; setTextColor(Color.WHITE); textSize = 34f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL); letterSpacing = 0.18f
        })
        root.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
            leftMargin = dp(56); topMargin = dp(36)
        })

        // КАРТОЧКА СЕРВЕРА
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(24), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat(); setColor(0xCC1C1C22.toInt()); setStroke(dp(1), 0x33FFFFFF)
            }
        }
        dot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF777777.toInt()) }
        }
        card.addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)).apply { rightMargin = dp(14) })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        serverName = TextView(this).apply {
            text = Config.SERVER_NAME; setTextColor(Color.WHITE); textSize = 22f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        serverNote = TextView(this).apply {
            text = ""; setTextColor(0xFFFF6A5A.toInt()); textSize = 12f; visibility = View.GONE
        }
        col.addView(serverName); col.addView(serverNote)
        card.addView(col)
        root.addView(card, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply {
            leftMargin = dp(56); bottomMargin = dp(48)
        })

        // КНОПКА ИГРАТЬ
        play = PlayButton(this)
        play.setOnClickListener { onPlay() }
        root.addView(play, FrameLayout.LayoutParams(dp(260), dp(84), Gravity.BOTTOM or Gravity.END).apply {
            rightMargin = dp(48); bottomMargin = dp(36)
        })

        // СТАТУС + ПРОГРЕСС (по центру снизу)
        val pb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        status = TextView(this).apply { text = ""; setTextColor(0xCCFFFFFF.toInt()); textSize = 13f }
        progress = RageProgress(this)
        pb.addView(status); pb.addView(progress, LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(8) })
        pb.visibility = View.INVISIBLE; pb.tag = "pb"
        root.addView(pb, FrameLayout.LayoutParams(dp(300), -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(56)
        })
        setContentView(root)
    }

    private fun showProgress(show: Boolean) {
        (window.decorView.findViewWithTag<View>("pb"))?.visibility = if (show) View.VISIBLE else View.INVISIBLE
    }

    private fun startStatusLoop() {
        thread(isDaemon = true) {
            while (alive) {
                val ok = Net.isServerOnline(Config.host, Config.port)
                serverOnline = ok
                ui.post { renderServer(ok) }
                Thread.sleep(8000)
            }
        }
    }

    private fun renderServer(ok: Boolean) {
        (dot.background as GradientDrawable).setColor(if (ok) 0xFF33D17A.toInt() else 0xFFE5260F.toInt())
        if (ok) { serverNote.visibility = View.GONE }
        else { serverNote.text = "Сервер временно не работает"; serverNote.visibility = View.VISIBLE }
        if (!busy) { play.enabledLook = ok; play.label = "ИГРАТЬ" }
    }

    private fun setStatus(text: String, p: Float? = null) = ui.post {
        showProgress(true); status.text = text
        if (p != null) progress.progress = p
    }

    private fun done() = ui.post {
        busy = false; showProgress(false); renderServer(serverOnline)
    }

    private fun onPlay() {
        if (busy) return
        if (!serverOnline) { Toast.makeText(this, "Сервер временно не работает", Toast.LENGTH_SHORT).show(); return }
        if (Config.MANIFEST_URL.isBlank()) {
            Toast.makeText(this, "Укажите MANIFEST_URL в Config.kt (см. README)", Toast.LENGTH_LONG).show(); return
        }
        busy = true; play.enabledLook = false; play.label = "ЗАГРУЗКА"
        thread { try { pipeline() } catch (e: Exception) {
            ui.post { Toast.makeText(this, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show() }
        } finally { done() } }
    }

    private fun pipeline() {
        setStatus("Проверка обновлений…", 0f)
        val m = JSONObject(Net.fetchText(Config.MANIFEST_URL))
        val version = m.optString("version", "1")
        val base = getExternalFilesDir(null) ?: filesDir
        val dataDir = File(base, "gamedata")
        val stamp = File(base, "cache.version")

        // 1) КЭШ GTA
        val cache = m.optJSONObject("cache")
        if (cache != null && (!stamp.exists() || stamp.readText() != version || !dataDir.exists())) {
            val zip = File(base, "cache.zip")
            setStatus("Загрузка кэша игры…", 0f)
            Net.download(cache.getString("url"), zip) { d, t ->
                val pr = if (t > 0) d.toFloat() / t else 0f
                setStatus("Загрузка кэша игры… ${(pr * 100).toInt()}%  (${d shr 20} / ${t shr 20} МБ)", pr)
            }
            val sha = cache.optString("sha256", "")
            if (sha.isNotEmpty() && !Net.sha256(zip).equals(sha, true)) { zip.delete(); throw RuntimeException("Кэш повреждён, попробуйте ещё раз") }
            setStatus("Распаковка…", 0f)
            Net.unzip(zip, dataDir) { i, n -> setStatus("Распаковка… ${i * 100 / n.coerceAtLeast(1)}%", i.toFloat() / n.coerceAtLeast(1)) }
            zip.delete(); stamp.writeText(version)
        }

        // 2) КЛИЕНТ МУЛЬТИПЛЕЕРА
        val client = m.optJSONObject("client")
        val pkg = client?.optString("package", Config.CLIENT_PACKAGE) ?: Config.CLIENT_PACKAGE
        val wantCode = client?.optLong("versionCode", 0) ?: 0
        val haveCode = installedVersionCode(pkg)
        if (client != null && (haveCode < 0 || haveCode < wantCode)) {
            val apk = File(base, "client.apk")
            apk.delete()
            setStatus("Загрузка клиента…", 0f)
            Net.download(client.getString("url"), apk) { d, t ->
                val pr = if (t > 0) d.toFloat() / t else 0f
                setStatus("Загрузка клиента… ${(pr * 100).toInt()}%", pr)
            }
            setStatus("Установка клиента…", 1f)
            installApk(apk)
            return // после установки игрок возвращается и жмёт «Играть» ещё раз
        }

        // 3) ЗАПУСК
        setStatus("Запуск…", 1f)
        val launch = packageManager.getLaunchIntentForPackage(pkg)
            ?: throw RuntimeException("Клиент не установлен")
        launch.putExtra("host", Config.host).putExtra("port", Config.port)
            .putExtra("server", Config.SERVER_NAME).putExtra("datadir", dataDir.absolutePath)
        ui.post { startActivity(launch) }
    }

    @Suppress("DEPRECATION")
    private fun installedVersionCode(pkg: String): Long = try {
        val i = packageManager.getPackageInfo(pkg, 0)
        if (Build.VERSION.SDK_INT >= 28) i.longVersionCode else i.versionCode.toLong()
    } catch (e: PackageManager.NameNotFoundException) { -1 }

    private fun installApk(apk: File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            ui.post {
                Toast.makeText(this, "Разрешите установку из этого источника и нажмите «Играть» снова", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            }
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.files", apk)
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ui.post { startActivity(i) }
    }
}
