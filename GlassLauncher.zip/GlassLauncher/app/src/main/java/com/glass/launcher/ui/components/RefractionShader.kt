package com.glass.launcher.ui.components

import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer

/**
 * AGSL-шейдер, имитирующий преломление света выпуклой стеклянной линзой:
 * пиксели фона сдвигаются от центра к краям пропорционально расстоянию до центра
 * элемента (сильнее у краёв — как в реальном liquid glass на iOS/новых Android UI),
 * а не просто размываются. Работает только на Android 13+ (API 33, RuntimeShader).
 */
private const val REFRACTION_AGSL = """
    uniform shader content;
    uniform float2 size;
    uniform float strength;

    half4 main(float2 coord) {
        float2 center = size * 0.5;
        float2 toCenter = coord - center;
        float2 normalized = toCenter / (size * 0.5);
        float dist = length(normalized);

        // Линза: у центра почти без искажения, к краю — сильнее сдвиг наружу.
        // clamp предотвращает сэмплинг за пределами панели.
        float lensAmount = smoothstep(0.0, 1.0, dist) * strength;
        float2 offset = normalized * lensAmount * 14.0;

        float2 sampleCoord = clamp(coord + offset, float2(0.0, 0.0), size);
        return content.eval(sampleCoord);
    }
"""

/**
 * Применяет эффект преломления (refraction) к содержимому под модификатором.
 * На устройствах < Android 13 возвращает modifier без изменений (шейдеров нет) —
 * визуал остаётся плоским, без искажения, но без падения приложения.
 *
 * @param strength 0f..1f — сила искривления линзы. 0.3-0.5 достаточно для читаемого liquid-glass.
 */
fun Modifier.liquidGlassRefraction(strength: Float = 0.4f): Modifier {
    if (Build.VERSION.SDK_INT < 33) return this

    return this.graphicsLayer {
        val shader = RuntimeShader(REFRACTION_AGSL)
        shader.setFloatUniform("size", size.width, size.height)
        shader.setFloatUniform("strength", strength)
        renderEffect = RenderEffect
            .createRuntimeShaderEffect(shader, "content")
            .asComposeRenderEffect()
        clip = true
    }
}
