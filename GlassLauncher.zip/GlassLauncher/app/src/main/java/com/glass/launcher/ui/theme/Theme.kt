package com.glass.launcher.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

enum class GlassStyle { SOFT, FROSTED }

/** Настройки анимаций лаунчера — отдельные скорости для разных зон UI. */
data class AnimSpeeds(
    val iconsMs: Int = 220,
    val contextMenuMs: Int = 180,
    val notificationShadeMs: Int = 260
)

data class LauncherAppearance(
    val darkTheme: Boolean,
    val glassStyle: GlassStyle,
    val animSpeeds: AnimSpeeds
)

val LocalLauncherAppearance = compositionLocalOf {
    LauncherAppearance(
        darkTheme = true,
        glassStyle = GlassStyle.FROSTED,
        animSpeeds = AnimSpeeds()
    )
}

@Composable
fun GlassLauncherTheme(
    appearance: LauncherAppearance,
    content: @Composable () -> Unit
) {
    val colorScheme = if (appearance.darkTheme) {
        darkColorScheme(
            background = CanvasDark,
            surface = CanvasDark,
            primary = AccentBlue,
            onBackground = TextPrimaryDark,
            onSurface = TextPrimaryDark
        )
    } else {
        lightColorScheme(
            background = CanvasLight,
            surface = CanvasLight,
            primary = AccentBlue,
            onBackground = TextPrimaryLight,
            onSurface = TextPrimaryLight
        )
    }

    CompositionLocalProvider(LocalLauncherAppearance provides appearance) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}

/** true если системная тёмная тема — используется только как дефолт при первом запуске. */
@Composable
fun systemPrefersDark(): Boolean = isSystemInDarkTheme()
