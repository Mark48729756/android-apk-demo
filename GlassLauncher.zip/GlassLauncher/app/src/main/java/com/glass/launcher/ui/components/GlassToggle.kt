package com.glass.launcher.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import com.glass.launcher.ui.theme.AccentBlue
import com.glass.launcher.ui.theme.AccentBlueDim

/**
 * Стеклянный тумблер: трек — полупрозрачное стекло с бликом,
 * при включении заливается акцентным градиентом; ручка — выпуклый "капля стекла" с тенью.
 */
@Composable
fun GlassToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val trackWidth = 52.dp
    val trackHeight = 30.dp
    val thumbSize = 24.dp

    val thumbOffset by animateDpAsState(
        targetValue = if (checked) trackWidth - thumbSize - 3.dp else 3.dp,
        animationSpec = tween(220),
        label = "thumbOffset"
    )
    val trackColorMix by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = tween(220),
        label = "trackColorMix"
    )

    val trackColor = lerp(Color(0x40FFFFFF), AccentBlue, trackColorMix)
    val trackColorDim = lerp(Color(0x24FFFFFF), AccentBlueDim, trackColorMix)

    Box(
        modifier = modifier
            .width(trackWidth)
            .height(trackHeight)
            .clickable(
                interactionSource = remember(),
                indication = null
            ) { onCheckedChange(!checked) }
            .background(
                Brush.horizontalGradient(listOf(trackColorDim, trackColor)),
                RoundedCornerShape(50)
            )
            .padding(0.dp)
    ) {
        Box(
            modifier = Modifier
                .padding(start = thumbOffset)
                .size(thumbSize)
                .align(Alignment.CenterStart)
                .shadow(4.dp, CircleShape, clip = false)
                .background(
                    Brush.radialGradient(
                        listOf(Color.White, Color(0xFFE4ECF7)),
                        radius = 40f
                    ),
                    CircleShape
                )
        )
    }
}

@Composable
private fun remember(): MutableInteractionSource =
    androidx.compose.runtime.remember { MutableInteractionSource() }
