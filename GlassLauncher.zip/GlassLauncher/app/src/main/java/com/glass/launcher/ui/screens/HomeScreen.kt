package com.glass.launcher.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glass.launcher.data.AppInfo
import com.glass.launcher.ui.components.GlassSurface
import com.glass.launcher.ui.theme.GlassStyle
import com.glass.launcher.ui.theme.LocalLauncherAppearance

@Composable
fun HomeScreen(
    dockApps: List<AppInfo>,
    onOpenApp: (String) -> Unit,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val appearance = LocalLauncherAppearance.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dragAmount ->
                    // Свайп вверх по пустому месту — открыть app drawer.
                    if (dragAmount < -20f) onOpenDrawer()
                }
            }
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Верхняя панель: часы-заглушка + настройки
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Glass",
                    fontSize = 28.sp,
                    color = if (appearance.darkTheme) Color.White else Color.Black
                )
                IconButton(onClick = onOpenSettings) {
                    Icon(
                        Icons.Filled.Settings,
                        contentDescription = "Настройки рабочего стола",
                        tint = if (appearance.darkTheme) Color.White else Color.Black
                    )
                }
            }

            Box(modifier = Modifier.weight(1f))

            // Dock — стеклянная панель снизу с избранными приложениями
            GlassSurface(
                style = appearance.glassStyle,
                cornerRadius = 32.dp,
                modifier = Modifier
                    .padding(horizontal = 20.dp, vertical = 20.dp)
                    .fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 14.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    dockApps.take(5).forEach { app ->
                        DockIcon(app = app, onClick = { onOpenApp(app.packageName) })
                    }
                }
            }
        }
    }
}

@Composable
private fun DockIcon(app: AppInfo, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .size(52.dp)
                .aspectRatio(1f)
                .clickable(onClick = onClick)
        )
    }
}
