package com.glass.launcher.ui.theme

import androidx.compose.ui.graphics.Color

// Liquid glass — soft glass (светлое стекло, тёплый блик)
val SoftGlassTint = Color(0x59FFFFFF)      // 35% white
val SoftGlassEdge = Color(0x99FFFFFF)      // 60% white — кромка/блик
val SoftGlassShadow = Color(0x33000000)

// Liquid glass — frosted glass (матовое, холоднее, менее прозрачное)
val FrostedGlassTint = Color(0x8FE9EEF5)   // ~56% почти-белый с холодным оттенком
val FrostedGlassEdge = Color(0x66FFFFFF)
val FrostedGlassShadow = Color(0x40000000)

// Акцент — используется на тумблерах/активных элементах
val AccentBlue = Color(0xFF5B8DEF)
val AccentBlueDim = Color(0xFF3B5F9E)

// Фон/подложка
val CanvasDark = Color(0xFF0B0E14)
val CanvasLight = Color(0xFFEFF2F7)

val TextPrimaryDark = Color(0xFFF5F7FA)
val TextSecondaryDark = Color(0xB3F5F7FA)
val TextPrimaryLight = Color(0xFF161A22)
val TextSecondaryLight = Color(0xB3161A22)
