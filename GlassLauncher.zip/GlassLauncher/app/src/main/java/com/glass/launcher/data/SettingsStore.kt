package com.glass.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.glass.launcher.ui.theme.AnimSpeeds
import com.glass.launcher.ui.theme.GlassStyle
import com.glass.launcher.ui.theme.LauncherAppearance
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "launcher_settings")

private object Keys {
    val DARK_THEME = booleanPreferencesKey("dark_theme")
    val GLASS_STYLE = stringPreferencesKey("glass_style") // "SOFT" | "FROSTED"
    val ICONS_MS = intPreferencesKey("anim_icons_ms")
    val CONTEXT_MENU_MS = intPreferencesKey("anim_context_menu_ms")
    val SHADE_MS = intPreferencesKey("anim_shade_ms")
}

class SettingsStore(private val context: Context) {

    val appearanceFlow: Flow<LauncherAppearance> = context.dataStore.data.map { prefs ->
        LauncherAppearance(
            darkTheme = prefs[Keys.DARK_THEME] ?: true,
            glassStyle = when (prefs[Keys.GLASS_STYLE]) {
                "SOFT" -> GlassStyle.SOFT
                else -> GlassStyle.FROSTED
            },
            animSpeeds = AnimSpeeds(
                iconsMs = prefs[Keys.ICONS_MS] ?: 220,
                contextMenuMs = prefs[Keys.CONTEXT_MENU_MS] ?: 180,
                notificationShadeMs = prefs[Keys.SHADE_MS] ?: 260
            )
        )
    }

    suspend fun setDarkTheme(value: Boolean) {
        context.dataStore.edit { it[Keys.DARK_THEME] = value }
    }

    suspend fun setGlassStyle(style: GlassStyle) {
        context.dataStore.edit { it[Keys.GLASS_STYLE] = style.name }
    }

    suspend fun setIconsSpeedMs(ms: Int) {
        context.dataStore.edit { it[Keys.ICONS_MS] = ms }
    }

    suspend fun setContextMenuSpeedMs(ms: Int) {
        context.dataStore.edit { it[Keys.CONTEXT_MENU_MS] = ms }
    }

    suspend fun setShadeSpeedMs(ms: Int) {
        context.dataStore.edit { it[Keys.SHADE_MS] = ms }
    }
}
