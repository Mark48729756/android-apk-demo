package com.glass.launcher.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap
)

/**
 * Читает список всех приложений с ярлыком запуска (то, что обычно видно в app drawer).
 * Декодирование иконок в Bitmap — тяжёлая операция для 100+ приложений на слабом устройстве,
 * поэтому вызывающий код должен запускать это на Dispatchers.Default (см. loadInstalledAppsAsync).
 */
fun loadInstalledApps(context: Context): List<AppInfo> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN, null).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
    }
    val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)

    return resolved
        .mapNotNull { ri ->
            val appInfo: ApplicationInfo = ri.activityInfo?.applicationInfo ?: return@mapNotNull null
            val label = ri.loadLabel(pm)?.toString() ?: appInfo.packageName
            val drawable: Drawable = ri.loadIcon(pm) ?: return@mapNotNull null
            AppInfo(
                label = label,
                packageName = appInfo.packageName,
                // Ограничиваем размер декодируемого bitmap — некоторые adaptive-иконки
                // растеризуются в неоправданно большое разрешение, это лишняя память и GC-нагрузка
                // на слабых устройствах при drawer с полусотней иконок.
                icon = drawable.toBitmap(width = 128, height = 128).asImageBitmap()
            )
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

fun launchApp(context: Context, packageName: String) {
    val pm = context.packageManager
    val launchIntent = pm.getLaunchIntentForPackage(packageName) ?: return
    context.startActivity(launchIntent)
}

/** Версия для вызова из Compose — уводит декодирование иконок с главного потока. */
suspend fun loadInstalledAppsAsync(context: Context): List<AppInfo> =
    withContext(Dispatchers.Default) { loadInstalledApps(context) }
