package com.glass.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.glass.launcher.data.AppInfo
import com.glass.launcher.data.SettingsStore
import com.glass.launcher.data.launchApp
import com.glass.launcher.data.loadInstalledAppsAsync
import com.glass.launcher.ui.screens.AppDrawerScreen
import com.glass.launcher.ui.screens.HomeScreen
import com.glass.launcher.ui.screens.SettingsScreen
import com.glass.launcher.ui.theme.GlassLauncherTheme
import com.glass.launcher.ui.theme.LauncherAppearance
import kotlinx.coroutines.launch

private enum class Screen { HOME, DRAWER, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LauncherRoot()
        }
    }
}

@Composable
private fun LauncherRoot() {
    val context = LocalContext.current
    val settingsStore = remember { SettingsStore(context) }
    val scope = rememberCoroutineScope()

    val appearance by settingsStore.appearanceFlow.collectAsState(
        initial = LauncherAppearance(
            darkTheme = true,
            glassStyle = com.glass.launcher.ui.theme.GlassStyle.FROSTED,
            animSpeeds = com.glass.launcher.ui.theme.AnimSpeeds()
        )
    )

    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    LaunchedEffect(Unit) {
        apps = loadInstalledAppsAsync(context)
    }

    var screen by remember { mutableStateOf(Screen.HOME) }

    GlassLauncherTheme(appearance = appearance) {
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                fadeIn(tween(appearance.animSpeeds.contextMenuMs)) togetherWith
                    fadeOut(tween(appearance.animSpeeds.contextMenuMs))
            },
            modifier = Modifier.fillMaxSize(),
            label = "screenTransition"
        ) { target ->
            when (target) {
                Screen.HOME -> HomeScreen(
                    dockApps = apps.take(5),
                    onOpenApp = { pkg -> launchApp(context, pkg) },
                    onOpenDrawer = { screen = Screen.DRAWER },
                    onOpenSettings = { screen = Screen.SETTINGS }
                )
                Screen.DRAWER -> AppDrawerScreen(
                    apps = apps,
                    onOpenApp = { pkg -> launchApp(context, pkg) }
                )
                Screen.SETTINGS -> SettingsScreen(
                    darkTheme = appearance.darkTheme,
                    onDarkThemeChange = { v -> scope.launch { settingsStore.setDarkTheme(v) } },
                    glassStyle = appearance.glassStyle,
                    onGlassStyleChange = { s -> scope.launch { settingsStore.setGlassStyle(s) } },
                    animSpeeds = appearance.animSpeeds,
                    onIconsSpeedChange = { ms -> scope.launch { settingsStore.setIconsSpeedMs(ms) } },
                    onContextMenuSpeedChange = { ms -> scope.launch { settingsStore.setContextMenuSpeedMs(ms) } },
                    onShadeSpeedChange = { ms -> scope.launch { settingsStore.setShadeSpeedMs(ms) } }
                )
            }
        }
    }
}
