package com.glass.launcher.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glass.launcher.ui.components.GlassSurface
import com.glass.launcher.ui.components.GlassToggle
import com.glass.launcher.ui.theme.AccentBlue
import com.glass.launcher.ui.theme.AnimSpeeds
import com.glass.launcher.ui.theme.GlassStyle
import com.glass.launcher.ui.theme.LocalLauncherAppearance

/**
 * Экран "Настройки рабочего стола".
 * Три независимых слайдера скорости (иконки / контекстное меню / шторка уведомлений)
 * вместо одного общего пункта "Скорость анимации", как просил пользователь.
 */
@Composable
fun SettingsScreen(
    darkTheme: Boolean,
    onDarkThemeChange: (Boolean) -> Unit,
    glassStyle: GlassStyle,
    onGlassStyleChange: (GlassStyle) -> Unit,
    animSpeeds: AnimSpeeds,
    onIconsSpeedChange: (Int) -> Unit,
    onContextMenuSpeedChange: (Int) -> Unit,
    onShadeSpeedChange: (Int) -> Unit
) {
    val appearance = LocalLauncherAppearance.current
    val textColor = if (appearance.darkTheme) Color.White else Color.Black
    val subColor = textColor.copy(alpha = 0.6f)

    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Настройки рабочего стола",
                color = textColor,
                fontSize = 24.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        item {
            SettingsCard(title = "Внешний вид") {
                SettingRow(
                    title = "Тёмная тема",
                    textColor = textColor
                ) {
                    GlassToggle(checked = darkTheme, onCheckedChange = onDarkThemeChange)
                }
                SettingDivider()
                GlassStylePicker(
                    selected = glassStyle,
                    onSelect = onGlassStyleChange,
                    textColor = textColor,
                    subColor = subColor
                )
            }
        }

        item {
            SettingsCard(title = "Скорость анимации") {
                SpeedSlider(
                    label = "Иконки",
                    valueMs = animSpeeds.iconsMs,
                    onChange = onIconsSpeedChange,
                    textColor = textColor,
                    subColor = subColor
                )
                SettingDivider()
                SpeedSlider(
                    label = "Контекстные меню",
                    valueMs = animSpeeds.contextMenuMs,
                    onChange = onContextMenuSpeedChange,
                    textColor = textColor,
                    subColor = subColor
                )
                SettingDivider()
                SpeedSlider(
                    label = "Шторка уведомлений",
                    valueMs = animSpeeds.notificationShadeMs,
                    onChange = onShadeSpeedChange,
                    textColor = textColor,
                    subColor = subColor
                )
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val appearance = LocalLauncherAppearance.current
    val textColor = if (appearance.darkTheme) Color.White else Color.Black

    GlassSurface(style = appearance.glassStyle, cornerRadius = 24.dp, showReflection = false) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                title,
                color = textColor.copy(alpha = 0.55f),
                fontSize = 13.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            content()
        }
    }
}

@Composable
private fun SettingRow(
    title: String,
    textColor: Color,
    trailing: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = textColor, fontSize = 16.sp)
        trailing()
    }
}

@Composable
private fun SettingDivider() {
    androidx.compose.foundation.layout.Spacer(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    )
}

@Composable
private fun GlassStylePicker(
    selected: GlassStyle,
    onSelect: (GlassStyle) -> Unit,
    textColor: Color,
    subColor: Color
) {
    Column {
        Text("Стиль стекла", color = textColor, fontSize = 16.sp, modifier = Modifier.padding(bottom = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassOptionChip(
                label = "Soft glass",
                selected = selected == GlassStyle.SOFT,
                onClick = { onSelect(GlassStyle.SOFT) },
                textColor = textColor
            )
            GlassOptionChip(
                label = "Frosted glass",
                selected = selected == GlassStyle.FROSTED,
                onClick = { onSelect(GlassStyle.FROSTED) },
                textColor = textColor
            )
        }
    }
}

@Composable
private fun GlassOptionChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    textColor: Color
) {
    val appearance = LocalLauncherAppearance.current
    GlassSurface(
        style = appearance.glassStyle,
        cornerRadius = 16.dp,
        showReflection = false,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                label,
                color = if (selected) AccentBlue else textColor,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun SpeedSlider(
    label: String,
    valueMs: Int,
    onChange: (Int) -> Unit,
    textColor: Color,
    subColor: Color
) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = textColor, fontSize = 15.sp)
            Text(
                speedLabelFor(valueMs),
                color = subColor,
                fontSize = 13.sp
            )
        }
        Slider(
            value = valueMs.toFloat(),
            onValueChange = { onChange(it.toInt()) },
            valueRange = 80f..500f,
            colors = SliderDefaults.colors(
                thumbColor = AccentBlue,
                activeTrackColor = AccentBlue,
                inactiveTrackColor = textColor.copy(alpha = 0.15f)
            )
        )
    }
}

private fun speedLabelFor(ms: Int): String = when {
    ms <= 150 -> "Быстро"
    ms <= 300 -> "Обычно"
    else -> "Медленно"
}
