package com.glass.launcher.ui.components

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.glass.launcher.ui.theme.FrostedGlassEdge
import com.glass.launcher.ui.theme.FrostedGlassTint
import com.glass.launcher.ui.theme.GlassStyle
import com.glass.launcher.ui.theme.SoftGlassEdge
import com.glass.launcher.ui.theme.SoftGlassTint

/**
 * Liquid-glass поверхность в духе iOS 26 / Android 2.5D glass:
 * полупрозрачная заливка + blur того, что позади (Android 12+),
 * + верхний диагональный блик + тонкая светлая кромка + зеркальное
 * отражение (reflection) самой панели под ней, затухающее вниз —
 * ключевой узнаваемый признак liquid glass, а не просто blur.
 *
 * SOFT   — теплее, чуть прозрачнее, мягкий широкий блик.
 * FROSTED— холоднее, плотнее (более матовое), блик уже и резче.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    style: GlassStyle,
    cornerRadius: Dp = 28.dp,
    shape: Shape = RoundedCornerShape(cornerRadius),
    showReflection: Boolean = true,
    content: @Composable () -> Unit
) {
    val tint = if (style == GlassStyle.SOFT) SoftGlassTint else FrostedGlassTint
    val edge = if (style == GlassStyle.SOFT) SoftGlassEdge else FrostedGlassEdge
    val blurRadius = if (style == GlassStyle.SOFT) 18.dp else 28.dp

    // Один combined-brush (заливка + диагональный блик) вместо двух отдельных
    // .background() слоёв — меньше проходов отрисовки на каждый кадр.
    val combinedBrush = Brush.linearGradient(
        colors = listOf(edge, tint, tint),
        start = Offset(0f, 0f),
        end = Offset(420f, 520f)
    )

    Box {
        if (showReflection) {
            // Зеркальное отражение самой панели, размещённое ПОД ней (не поверх):
            // тот же контур сдвинут вниз на собственную высоту, перевёрнут по Y
            // и затухает через alpha-градиент — так свет/жидкость отражают то,
            // что "стоит" на поверхности стекла.
            Box(
                modifier = modifier
                    .graphicsLayer {
                        scaleY = -1f
                        alpha = 0.35f
                        translationY = size.height + 4f
                    }
                    .clip(shape)
                    .background(combinedBrush, shape)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Black.copy(alpha = 0.05f), Color.Black.copy(alpha = 0.65f))
                        )
                    )
            )
        }

        Box(
            modifier = modifier
                .clip(shape)
                .then(
                    // Преломление (refraction) фона — главный признак liquid glass,
                    // не просто blur. Работает на Android 13+ (RuntimeShader), на более
                    // старых версиях модификатор no-op — деградирует до плоского стекла.
                    Modifier.liquidGlassRefraction(strength = if (style == GlassStyle.SOFT) 0.45f else 0.3f)
                )
                .then(
                    // Настоящий фоновый блур доступен с Android 12 (API 31) и это дорогая
                    // GPU-операция — используем только на крупных статичных панелях
                    // (dock, карточки настроек), никогда на элементах внутри скролл-списков.
                    if (Build.VERSION.SDK_INT >= 31) Modifier.blur(blurRadius) else Modifier
                )
                .background(combinedBrush, shape)
        ) {
            content()
        }
    }
}

/**
 * Лёгкая версия стекла для мелких элементов (иконки в drawer/dock).
 * Без Modifier.blur() — на списках из 20-30+ иконок настоящий blur на бюджетном железе
 * даёт заметные просадки FPS. Вместо него — статичный радиальный блик + тень,
 * визуально даёт тот же эффект "выпуклой стеклянной капли", но почти бесплатно по GPU.
 */
@Composable
fun GlassIconChip(
    modifier: Modifier = Modifier,
    style: GlassStyle,
    size: Dp,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(size * 0.28f)
    val baseTint = if (style == GlassStyle.SOFT) SoftGlassTint else FrostedGlassTint
    val highlight = if (style == GlassStyle.SOFT) SoftGlassEdge else FrostedGlassEdge

    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(baseTint, shape)
            // Верхний блик — диагональный, имитирует выпуклость 2.5D-стекла
            .background(
                Brush.radialGradient(
                    colors = listOf(highlight, Color.Transparent),
                    center = Offset(size.value * 0.30f, size.value * 0.24f),
                    radius = size.value * 0.85f
                ),
                shape
            )
            // Нижний край — лёгкое затемнение вместо shadow(): shadow() рендерит каждую
            // иконку в отдельный GPU-layer, что на списке из 20-30+ штук заметно нагружает
            // слабое железо. Плоский градиент даёт похожий эффект объёма почти бесплатно.
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.16f)),
                    startY = 0.55f, endY = 1f
                ),
                shape
            ),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
