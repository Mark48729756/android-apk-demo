package com.glass.launcher.ui.components

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.glass.launcher.ui.theme.FrostedGlassEdge
import com.glass.launcher.ui.theme.FrostedGlassTint
import com.glass.launcher.ui.theme.GlassStyle
import com.glass.launcher.ui.theme.SoftGlassEdge
import com.glass.launcher.ui.theme.SoftGlassTint

/**
 * Liquid-glass поверхность в духе iOS 26 / Android 2.5D glass:
 * полупрозрачная заливка + blur того, что позади (Android 12+),
 * + верхний диагональный блик + тонкая светлая кромка.
 *
 * SOFT   — теплее, чуть прозрачнее, мягкий широкий блик.
 * FROSTED— холоднее, плотнее (более матовое), блик уже и резче.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    style: GlassStyle,
    cornerRadius: Dp = 28.dp,
    shape: Shape = RoundedCornerShape(cornerRadius),
    content: @Composable () -> Unit
) {
    val tint = if (style == GlassStyle.SOFT) SoftGlassTint else FrostedGlassTint
    val edge = if (style == GlassStyle.SOFT) SoftGlassEdge else FrostedGlassEdge
    val blurRadius = if (style == GlassStyle.SOFT) 18.dp else 28.dp

    Box(
        modifier = modifier
            .clip(shape)
            .then(
                // Настоящий фоновый блур доступен с Android 12 (API 31).
                if (Build.VERSION.SDK_INT >= 31) Modifier.blur(blurRadius) else Modifier
            )
            .background(tint, shape)
            .background(
                Brush.linearGradient(
                    colors = listOf(edge, Color.Transparent, Color.Transparent),
                    start = Offset(0f, 0f),
                    end = Offset(400f, 500f)
                ),
                shape
            )
    ) {
        content()
    }
}

/** Тонкая обводка-кромка поверх GlassSurface для эффекта толщины стекла. */
@Composable
fun glassBorderBrush(style: GlassStyle): Brush {
    val c = if (style == GlassStyle.SOFT) SoftGlassEdge else FrostedGlassEdge
    return Brush.verticalGradient(listOf(c, Color.Transparent))
}
