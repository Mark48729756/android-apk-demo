#!/system/bin/sh
D=/data/local/tmp/dp; P=com.depthparallax; T=/data/data/$P/files
mkdir -p $T
cp $D/photo.jpg $D/depth.png $T/
if [ -f $D/cleanbg.jpg ]; then cp $D/cleanbg.jpg $T/; else rm -f $T/cleanbg.jpg; fi
[ -f $D/mask.png ] && cp $D/mask.png $T/
[ -f $T/config.json ] || cp /data/adb/depthparallax/config.json $T/ 2>/dev/null
U=$(stat -c %u /data/data/$P)
chown -R $U:$U $T; restorecon -R $T
am start -a android.service.wallpaper.CHANGE_LIVE_WALLPAPER --es android.service.wallpaper.extra.LIVE_WALLPAPER_COMPONENT $P/.ParallaxService >/dev/null 2>&1
echo ok
