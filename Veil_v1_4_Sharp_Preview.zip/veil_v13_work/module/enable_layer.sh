#!/system/bin/sh
# Explicit opt-in helper only. Never edit enabled_accessibility_services
# directly: Android must let the user grant this capability in Settings.
am start -a android.settings.ACCESSIBILITY_SETTINGS >/dev/null 2>&1
echo "Открой Veil в настройках специальных возможностей и включи вручную."
