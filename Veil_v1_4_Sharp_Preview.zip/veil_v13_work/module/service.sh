#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
mkdir -p /data/adb/depthparallax
[ -f /data/adb/depthparallax/config.json ] || echo '{"strength":0.6,"smooth":0.85,"zoom":1.12,"cut":-1,"feather":0.06,"overlay":false}' > /data/adb/depthparallax/config.json
# v1.1 migration: stop auto-enabling the Accessibility overlay. Earlier
# releases enabled it from boot scripts, which could interfere with System UI.
if [ ! -f /data/adb/depthparallax/.overlay_safe_v1_1 ]; then
  for CFG in /data/adb/depthparallax/config.json /data/data/com.depthparallax/files/config.json; do
    if [ -f "$CFG" ]; then
      sed -i 's/"overlay"[[:space:]]*:[[:space:]]*true/"overlay":false/' "$CFG"
      restorecon "$CFG" 2>/dev/null
    fi
  done
  CURRENT=$(settings get secure enabled_accessibility_services 2>/dev/null)
  if [ -n "$CURRENT" ] && [ "$CURRENT" != "null" ]; then
    FILTERED=$(printf '%s' "$CURRENT" | sed 's#^com.depthparallax/com.depthparallax.SubjectOverlayService:##; s#:com.depthparallax/com.depthparallax.SubjectOverlayService:#:#g; s#:com.depthparallax/com.depthparallax.SubjectOverlayService$##; s#^com.depthparallax/com.depthparallax.SubjectOverlayService$##')
    settings put secure enabled_accessibility_services "$FILTERED" 2>/dev/null
  fi
  touch /data/adb/depthparallax/.overlay_safe_v1_1
fi
# Never force-enable an AccessibilityService from a boot script. The user
# can opt in manually from Veil settings and Android's Accessibility screen.
