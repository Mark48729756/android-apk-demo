# Veil v1.3 — Robust foreground fallback

## Fix
- Fixed the hard failure when semantic segmentation returns no foreground candidates.
- Accepts the strongest usable segmentation mask even when label/score metadata differs between Transformers.js versions.
- If no usable segmentation mask exists, builds a soft center-weighted matte from the depth estimate instead of aborting the whole photo workflow.
- Keeps previous image data untouched until the new pipeline completes.

## Quality note
The depth-derived fallback is approximate and works best when the main subject is near the center. It is a resilience fallback, not a substitute for a dedicated foreground segmentation model.

## Validation
JavaScript syntax and ZIP integrity can be checked locally; Android Gradle build and on-device WebView/AI model behavior require Android SDK, dependencies, and a target device.


### v1.4 — Sharp preview and source resolution
- Keeps a higher-resolution source image (up to 1280 px on the long edge) for preview and background reconstruction; AI inference remains on a smaller device-adaptive copy.
- Raises the preview mesh density and reduces default parallax strength to limit visible stretching.
- This improves source sharpness, but does not replace accurate foreground segmentation; masks and reconstructed background can still need refinement.
