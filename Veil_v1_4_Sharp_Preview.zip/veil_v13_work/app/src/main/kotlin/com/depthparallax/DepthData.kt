package com.depthparallax

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import org.json.JSONObject
import java.io.File

/** Общий наклон телефона: один сенсор на обои и на верхний слой, чтобы слои двигались синхронно. */
object Tilt : SensorEventListener {
    @Volatile var cx = 0f
    @Volatile var cy = 0f
    @Volatile var onMotion: (() -> Unit)? = null
    private var tx = 0f
    private var ty = 0f
    private var smooth = 0.85f
    private var users = 0
    private var sm: SensorManager? = null

    @Synchronized fun start(ctx: Context, smooth: Float) {
        this.smooth = smooth
        if (users++ == 0) {
            val m = ctx.applicationContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            sm = m
            m.registerListener(this, m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_UI)
        }
    }

    @Synchronized fun stop() {
        if (users > 0 && --users == 0) sm?.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        tx = (-e.values[0] / 5f).coerceIn(-1f, 1f)
        ty = ((e.values[2] / 9.8f - 0.7f) * 2f).coerceIn(-1f, 1f)
        val oldX = cx; val oldY = cy
        cx += (tx - cx) * (1 - smooth)
        cy += (ty - cy) * (1 - smooth)
        if (kotlin.math.abs(cx - oldX) + kotlin.math.abs(cy - oldY) > 0.0015f) onMotion?.invoke()
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}

/** Настройки эффекта (config.json в filesDir приложения). */
data class Cfg(
    var strength: Float = 0.6f, var smooth: Float = 0.85f, var zoom: Float = 1.12f,
    var cut: Float = -1f, var feather: Float = 0.06f, var overlay: Boolean = false
) {
    companion object {
        fun load(ctx: Context): Cfg {
            val c = Cfg()
            try {
                val j = JSONObject(File(ctx.filesDir, "config.json").readText())
                c.strength = j.optDouble("strength", 0.6).toFloat()
                c.smooth = j.optDouble("smooth", 0.85).toFloat()
                c.zoom = j.optDouble("zoom", 1.12).toFloat()
                c.cut = j.optDouble("cut", -1.0).toFloat()
                c.feather = j.optDouble("feather", 0.06).toFloat()
                c.overlay = j.optBoolean("overlay", false)
            } catch (_: Exception) {}
            return c
        }

        fun save(ctx: Context, c: Cfg) {
            val j = JSONObject()
            j.put("strength", c.strength.toDouble()); j.put("smooth", c.smooth.toDouble())
            j.put("zoom", c.zoom.toDouble()); j.put("cut", c.cut.toDouble())
            j.put("feather", c.feather.toDouble()); j.put("overlay", c.overlay)
            File(ctx.filesDir, "config.json").writeText(j.toString())
        }
    }
}

/** Фон + вырезанный объект (маска из карты глубины) + глубина для сетки. Кэшируется на процесс. */
class DepthData private constructor(
    val w: Int, val h: Int, val bg: Bitmap, val subject: Bitmap,
    private val depth: FloatArray, val strength: Float, val smooth: Float, val zoom: Float, val overlay: Boolean,
    private val stamp: Long
) {
    /** Заполняет сетку вершин по текущему наклону для выбранной плоскости глубины. */
    fun fill(verts: FloatArray, foreground: Boolean = false) {
        // Foreground moves farther than the wallpaper plane, creating a real
        // two-plane depth effect instead of moving both layers identically.
        val layer = if (foreground) 1.72f else 1f
        val z = zoom * if (foreground) 1.006f else 1f
        val amp = w * 0.07f * strength * 2f * layer
        val cx = Tilt.cx
        val cy = Tilt.cy
        var k = 0
        for (j in 0..N) for (i in 0..N) {
            val d = depth[j * (N + 1) + i]
            val px = i * w / N.toFloat() - w / 2f
            val py = j * h / N.toFloat() - h / 2f
            val perspective = 1f + d.coerceIn(-0.5f, 0.5f) * 0.035f
            verts[k++] = px * z * perspective + w / 2f - cx * d * amp
            verts[k++] = py * z * perspective + h / 2f - cy * d * amp
        }
    }

    companion object {
        const val N = 48
        private var cache: DepthData? = null

        @Synchronized
        fun get(ctx: Context, w: Int, h: Int): DepthData? {
            val dir = ctx.filesDir
            val f = File(dir, "photo.jpg"); val d = File(dir, "depth.png"); val cf = File(dir, "config.json")
            if (!f.exists() || !d.exists() || w <= 1 || h <= 1) return null
            val st = f.lastModified() + d.lastModified() + File(dir, "mask.png").lastModified() + File(dir, "cleanbg.jpg").lastModified() + cf.lastModified()
            cache?.let { if (it.w == w && it.h == h && it.stamp == st) return it }
            return build(ctx, w, h, Cfg.load(ctx), st)?.also { cache = it }
        }

        /** Сборка без кэша (используется и для превью в настройках). */
        fun build(ctx: Context, w: Int, h: Int, cfg: Cfg, st: Long): DepthData? {
            val dir = ctx.filesDir
            val f = File(dir, "photo.jpg"); val d = File(dir, "depth.png")
            if (!f.exists() || !d.exists() || w <= 1 || h <= 1) return null
            val strength = cfg.strength; val smooth = cfg.smooth; val cut = cfg.cut; val feather = cfg.feather
            // Keep pixel processing bounded on high-resolution phones. Mesh vertices
            // still span the full display; only source bitmaps are downscaled.
            val renderScale = minOf(1f, 900f / maxOf(w, h).toFloat())
            val rw = maxOf(1, (w * renderScale).toInt())
            val rh = maxOf(1, (h * renderScale).toInt())
            val p = BitmapFactory.decodeFile(f.path) ?: return null
            val cleanFile = File(dir, "cleanbg.jpg")
            val cleanSource = if (cleanFile.exists()) BitmapFactory.decodeFile(cleanFile.path) else null
            val dm = BitmapFactory.decodeFile(d.path) ?: run { p.recycle(); cleanSource?.recycle(); return null }
            val maskFile = File(dir, "mask.png")
            val suppliedMask = if (maskFile.exists()) BitmapFactory.decodeFile(maskFile.path) else null
            val ar = w.toFloat() / h
            fun crop(b: Bitmap): Bitmap {
                val cw: Int; val ch: Int
                if (b.width.toFloat() / b.height > ar) { ch = b.height; cw = (ch * ar).toInt() }
                else { cw = b.width; ch = (cw / ar).toInt() }
                return Bitmap.createBitmap(b, (b.width - cw) / 2, (b.height - ch) / 2, cw, ch)
            }
            fun scaledCrop(b: Bitmap): Bitmap {
                val cropped = crop(b)
                val scaled = Bitmap.createScaledBitmap(cropped, rw, rh, true)
                // createScaledBitmap may return its input unchanged when the
                // dimensions already match. Keep an independent copy because
                // the decoded source bitmaps are recycled immediately below.
                val independent = scaled.copy(Bitmap.Config.ARGB_8888, false)
                if (scaled !== cropped && scaled !== b) scaled.recycle()
                if (cropped !== b) cropped.recycle()
                return independent
            }
            val original = scaledCrop(p)
            val bgSource = cleanSource ?: p
            val bg = scaledCrop(bgSource)
            val dFull = scaledCrop(dm)
            val maskFull = suppliedMask?.let { scaledCrop(it) }
            p.recycle(); if (cleanSource !== p) cleanSource?.recycle()
            dm.recycle(); suppliedMask?.recycle()

            // Normalize the depth map by robust percentiles. This preserves
            // useful depth when the supplied map occupies only a narrow range.
            val dp = IntArray(rw * rh)
            dFull.getPixels(dp, 0, rw, 0, 0, rw, rh)
            dFull.recycle()
            val hist = IntArray(256)
            for (v in dp) hist[(v shr 16) and 255]++
            fun percentile(target: Int): Int {
                var sum = 0
                for (i in 0..255) {
                    sum += hist[i]
                    if (sum >= target) return i
                }
                return 255
            }
            val low = percentile((dp.size * 0.02f).toInt()).coerceAtMost(253)
            val high = percentile((dp.size * 0.98f).toInt()).coerceAtLeast(low + 2)
            val range = (high - low).toFloat()
            for (i in dp.indices) {
                val raw = (dp[i] shr 16) and 255
                val value = (((raw - low) / range) * 255f).toInt().coerceIn(0, 255)
                dp[i] = (value shl 16) or (value shl 8) or value
            }
            val normalized = dp

            // Sample a dense 64x64 mesh directly from the normalized map.
            // Bilinear sampling avoids allocating another full-size bitmap.
            val depth = FloatArray((N + 1) * (N + 1))
            for (gy in 0..N) for (gx in 0..N) {
                val fx = gx * (rw - 1).toFloat() / N
                val fy = gy * (rh - 1).toFloat() / N
                val x0 = fx.toInt().coerceIn(0, rw - 1)
                val y0 = fy.toInt().coerceIn(0, rh - 1)
                val x1 = (x0 + 1).coerceAtMost(rw - 1)
                val y1 = (y0 + 1).coerceAtMost(rh - 1)
                val ax = fx - x0
                val ay = fy - y0
                fun value(x: Int, y: Int) = ((normalized[y * rw + x] shr 16) and 255) / 255f
                val top = value(x0, y0) * (1f - ax) + value(x1, y0) * ax
                val bottom = value(x0, y1) * (1f - ax) + value(x1, y1) * ax
                depth[gy * (N + 1) + gx] = top * (1f - ay) + bottom * ay - 0.5f
            }

            // Prefer the semantic foreground matte generated by the segmentation
            // model in WebUI. Fall back to depth-threshold extraction for old projects.
            val bp = IntArray(rw * rh)
            // Extract foreground pixels from the untouched source image;
            // the background plane uses the reconstructed clean plate.
            original.getPixels(bp, 0, rw, 0, 0, rw, rh)
            original.recycle()
            val mp = maskFull?.let { IntArray(rw * rh).also { a -> it.getPixels(a, 0, rw, 0, 0, rw, rh); it.recycle() } }
            if (mp != null) {
                for (i in bp.indices) {
                    val a = (mp[i] shr 16) and 255
                    bp[i] = (a shl 24) or (bp[i] and 0x00FFFFFF)
                }
            } else {
                val th = if (cut >= 0f) cut else otsu(normalized)
                val lo = th - feather.coerceAtLeast(0.002f)
                val hi = th + feather.coerceAtLeast(0.002f)
                for (y in 0 until rh) for (x in 0 until rw) {
                    var sum = 0
                    for (oy in -1..1) for (ox in -1..1) {
                        val sx = (x + ox).coerceIn(0, rw - 1)
                        val sy = (y + oy).coerceIn(0, rh - 1)
                        sum += (normalized[sy * rw + sx] shr 16) and 255
                    }
                    val g = sum / (9f * 255f)
                    val t = ((g - lo) / (hi - lo)).coerceIn(0f, 1f)
                    val a = (t * t * (3f - 2f * t) * 255f).toInt()
                    val idx = y * rw + x
                    bp[idx] = (a shl 24) or (bp[idx] and 0x00FFFFFF)
                }
            }
            val subject = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888)
            subject.setPixels(bp, 0, rw, 0, 0, rw, rh)

            return DepthData(w, h, bg, subject, depth, strength, smooth, cfg.zoom, cfg.overlay, st)
        }

        private fun otsu(px: IntArray): Float {
            val hist = IntArray(256)
            for (v in px) hist[(v shr 16) and 255]++
            val total = px.size
            var sum = 0.0; for (i in 0..255) sum += i * hist[i].toDouble()
            var sb = 0.0; var wB = 0; var best = 0.0; var th = 128
            for (i in 0..255) {
                wB += hist[i]; if (wB == 0) continue
                val wF = total - wB; if (wF == 0) break
                sb += i * hist[i].toDouble()
                val mB = sb / wB; val mF = (sum - sb) / wF
                val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
                if (v > best) { best = v; th = i }
            }
            return th / 255f
        }
    }
}
