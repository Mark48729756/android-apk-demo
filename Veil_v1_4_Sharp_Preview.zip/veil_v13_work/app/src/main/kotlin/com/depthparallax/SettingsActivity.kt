package com.depthparallax

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.concurrent.thread

/** Меню настроек эффекта. Открывается кнопкой Actions модуля или из WebUI. */
class SettingsActivity : Activity() {
    private lateinit var cfg: Cfg
    private var cutManual = 0.5f
    private val h = Handler(Looper.getMainLooper())
    private lateinit var preview: PreviewView
    private var gen = 0
    private val accent = 0xFF7A4BFF.toInt()
    private var cBg = 0; private var cCard = 0; private var cText = 0; private var cSub = 0
    private var cutSeek: SeekBar? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        cBg = if (night) 0xFF000000.toInt() else 0xFFF2F2F7.toInt()
        cCard = if (night) 0xFF1C1C1E.toInt() else Color.WHITE
        cText = if (night) 0xFFF5F5F7.toInt() else 0xFF1C1C1E.toInt()
        cSub = if (night) 0x99EBEBF5.toInt() else 0x993C3C43.toInt()
        cfg = Cfg.load(this)
        cutManual = if (cfg.cut >= 0f) cfg.cut else 0.5f

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(40)) }
        val sv = ScrollView(this).apply { setBackgroundColor(cBg); isFillViewport = true; addView(root) }
        setContentView(sv)

        // шапка
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), 0, 0, dp(18)) }
        head.addView(ImageView(this).apply { setImageDrawable(getDrawable(R.mipmap.ic_launcher)); layoutParams = LinearLayout.LayoutParams(dp(56), dp(56)) })
        val tl = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        tl.addView(TextView(this).apply { text = "Veil"; textSize = 30f; typeface = Typeface.create("sans-serif", Typeface.BOLD); setTextColor(cText) })
        tl.addView(TextView(this).apply { text = "Настройки эффекта"; textSize = 15f; setTextColor(cSub) })
        head.addView(tl); root.addView(head)

        // превью
        val pc = card(root)
        pc.addView(TextView(this).apply { text = "ОБЪЕКТ ПОВЕРХ ЧАСОВ"; textSize = 12f; setTextColor(cSub); setPadding(dp(4), 0, 0, dp(10)) })
        preview = PreviewView(this)
        pc.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(380)))

        // параллакс
        val c1 = card(root)
        sectionTitle(c1, "ПАРАЛЛАКС")
        slider(c1, "Сила эффекта", 0f, 1f, { cfg.strength }, { cfg.strength = it })
        slider(c1, "Плавность", 0f, 0.98f, { cfg.smooth }, { cfg.smooth = it })
        slider(c1, "Масштаб (запас по краям)", 1f, 1.3f, { cfg.zoom }, { cfg.zoom = it })

        // объект
        val c2 = card(root)
        sectionTitle(c2, "ОБЪЕКТ")
        switch(c2, "Объект поверх часов (доступ к специальным возможностям)", cfg.overlay) {
            cfg.overlay = it
            if (it) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        switch(c2, "Автоматический порог", cfg.cut < 0f) {
            cfg.cut = if (it) -1f else cutManual
            cutSeek?.isEnabled = !it; cutSeek?.alpha = if (it) 0.4f else 1f
        }
        cutSeek = slider(c2, "Порог (что считать объектом)", 0f, 1f, { cutManual }, { cutManual = it; if (cfg.cut >= 0f) cfg.cut = it })
        cutSeek?.isEnabled = cfg.cut >= 0f; cutSeek?.alpha = if (cfg.cut >= 0f) 1f else 0.4f
        slider(c2, "Мягкость края", 0f, 0.2f, { cfg.feather }, { cfg.feather = it })

        // сброс
        root.addView(Button(this).apply {
            text = "Сбросить"; isAllCaps = false; setTextColor(accent); textSize = 16f
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0x1F7A4BFF) }
            setOnClickListener { cfg = Cfg(); Cfg.save(this@SettingsActivity, cfg); recreate() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))

        rebuildPreview()
    }

    override fun onPause() { super.onPause(); Cfg.save(this, cfg) }

    private fun card(parent: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(cCard) }
        }
        parent.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(14) })
        return c
    }

    private fun sectionTitle(p: LinearLayout, t: String) =
        p.addView(TextView(this).apply { text = t; textSize = 12f; setTextColor(cSub); setPadding(dp(4), 0, 0, dp(6)) })

    private fun schedulePreview() { h.removeCallbacks(refresh); h.postDelayed(refresh, 250) }
    private val refresh = Runnable { rebuildPreview() }

    private fun rebuildPreview() {
        val my = ++gen
        val dm = resources.displayMetrics
        val pw = dm.widthPixels / 4; val ph = dm.heightPixels / 4
        val snap = cfg.copy()
        thread {
            val d = DepthData.build(applicationContext, pw, ph, snap, 0L)
            runOnUiThread { if (my == gen) { preview.d = d; preview.invalidate() } }
        }
    }

    private fun slider(p: LinearLayout, title: String, min: Float, max: Float, get: () -> Float, set: (Float) -> Unit): SeekBar {
        val hd = LinearLayout(this).apply { setPadding(dp(4), dp(10), dp(4), 0) }
        val tv = TextView(this).apply { text = title; textSize = 16f; setTextColor(cText) }
        val vv = TextView(this).apply { text = "%.2f".format(get()); textSize = 16f; setTextColor(cSub) }
        hd.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); hd.addView(vv)
        p.addView(hd)
        val sb = SeekBar(this).apply {
            this.max = 1000; progress = ((get() - min) / (max - min) * 1000).toInt().coerceIn(0, 1000)
            progressTintList = ColorStateList.valueOf(accent); thumbTintList = ColorStateList.valueOf(accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, pr: Int, user: Boolean) {
                    if (!user) return
                    val v = min + pr / 1000f * (max - min); set(v); vv.text = "%.2f".format(v); schedulePreview()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { Cfg.save(this@SettingsActivity, cfg) }
            })
        }
        p.addView(sb)
        return sb
    }

    private fun switch(p: LinearLayout, title: String, on: Boolean, cb: (Boolean) -> Unit) {
        p.addView(Switch(this).apply {
            text = title; textSize = 16f; setTextColor(cText); isChecked = on; setPadding(dp(4), dp(10), dp(4), dp(10))
            setOnCheckedChangeListener { _, v -> cb(v); Cfg.save(this@SettingsActivity, cfg); schedulePreview() }
        })
    }

    private class PreviewView(c: Context) : View(c) {
        var d: DepthData? = null
        private val dim = Paint().apply { color = 0xAA000000.toInt() }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 15f * c.resources.displayMetrics.density; textAlign = Paint.Align.CENTER }
        private val bgp = Paint().apply { color = Color.BLACK }
        override fun onDraw(cv: Canvas) {
            val r = RectF(0f, 0f, width.toFloat(), height.toFloat())
            val path = Path().apply { addRoundRect(r, 40f, 40f, Path.Direction.CW) }
            cv.clipPath(path); cv.drawRect(r, bgp)
            val x = d
            if (x == null) { cv.drawText("Сначала выбери фото в WebUI", width / 2f, height / 2f, txt); return }
            val ar = x.w.toFloat() / x.h
            val dh = height.toFloat(); val dw = dh * ar
            val dst = Rect(((width - dw) / 2).toInt(), 0, ((width + dw) / 2).toInt(), height)
            cv.drawBitmap(x.bg, null, dst, null)
            cv.drawRect(dst, dim)
            cv.drawBitmap(x.subject, null, dst, null)
        }
    }
}
