package com.depthparallax

import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

class ParallaxService : WallpaperService() {
    override fun onCreateEngine(): Engine = E()

    inner class E : Engine() {
        private val h = Handler(Looper.getMainLooper())
        private var data: DepthData? = null
        private val verts = FloatArray((DepthData.N + 1) * (DepthData.N + 1) * 2)
        private var w = 1; private var hh = 1
        private var vis = false; private var tilting = false
        @Volatile private var loading = false

        // Render on sensor changes instead of forcing a permanent 30 FPS loop.
        // The sensor callback coalesces updates onto the main thread.
        private val loop = Runnable { if (vis) draw() }
        private fun scheduleMotionFrame() {
            h.removeCallbacks(loop)
            h.post(loop)
        }

        private fun load() {
            if (loading) return
            loading = true
            val targetW = w; val targetH = hh
            kotlin.concurrent.thread(name = "VeilWallpaperLoad") {
                val loaded = DepthData.get(applicationContext, targetW, targetH)
                h.post { if (loaded != null) data = loaded; loading = false; if (vis) draw() }
            }
        }

        private fun stopTilt() { if (tilting) { Tilt.stop(); tilting = false } }

        private fun draw() {
            val d = data ?: return
            val s = surfaceHolder
            val c = (try { s.lockHardwareCanvas() } catch (_: Exception) { s.lockCanvas() }) ?: return
            try {
                d.fill(verts)
                c.drawBitmapMesh(d.bg, DepthData.N, DepthData.N, verts, 0, null, 0, null)
            } finally { s.unlockCanvasAndPost(c) }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, f: Int, width: Int, height: Int) {
            w = width; hh = height; load(); draw()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            vis = visible
            if (visible) {
                load()
                if (!tilting) { Tilt.start(applicationContext, data?.smooth ?: 0.85f); tilting = true }
                Tilt.onMotion = { scheduleMotionFrame() }
                scheduleMotionFrame()
            } else {
                Tilt.onMotion = null
                stopTilt()
                h.removeCallbacks(loop)
            }
        }

        override fun onDestroy() { Tilt.onMotion = null; stopTilt(); h.removeCallbacks(loop) }
    }
}
