plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.depthparallax"
    compileSdk = 34
    defaultConfig { applicationId = "com.depthparallax"; minSdk = 33; targetSdk = 34; versionCode = 14; versionName = "1.4" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
