package com.embededly.Gallery

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage

@Composable
fun TrashScreen(onClose: () -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    var items by remember { mutableStateOf<List<Media>>(emptyList()) }
    var sel by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) { items = loadMedia(ctx, "date_modified", true, true, true, trashed = true) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) { sel = emptySet(); reload++; onChanged() }
    }
    val target = if (sel.isEmpty()) items else items.filter { it.id in sel }
    BackHandler { if (sel.isNotEmpty()) sel = emptySet() else onClose() }

    Column(Modifier.fillMaxSize().background(pal.bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = pal.fg) }
            Text(t(R.string.s_020), color = pal.fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Text(t(R.string.s_101),
            color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        Box(Modifier.weight(1f)) {
            if (items.isEmpty()) Text(t(R.string.s_102), color = pal.sub, modifier = Modifier.align(Alignment.Center))
            LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                items(items, key = { it.id }) { m ->
                    val on = m.id in sel
                    Box(Modifier.aspectRatio(1f).clickable { sel = if (on) sel - m.id else sel + m.id }) {
                        AsyncImage(m.uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        if (on) Box(Modifier.fillMaxSize().background(pal.accent.copy(alpha = .45f)))
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(enabled = items.isNotEmpty(), modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = pal.accent),
                onClick = { trashSender(ctx, target, false)?.let { launcher.launch(IntentSenderRequest.Builder(it).build()) } }) {
                Text(if (sel.isEmpty()) t(R.string.s_103) else t(R.string.s_restore_n, sel.size), color = Color.White)
            }
            OutlinedButton(enabled = items.isNotEmpty(), modifier = Modifier.weight(1f),
                onClick = { deleteSender(ctx, target)?.let { launcher.launch(IntentSenderRequest.Builder(it).build()) } }) {
                Text(if (sel.isEmpty()) t(R.string.s_104) else t(R.string.s_delete_n, sel.size), color = pal.fg)
            }
        }
    }
}
