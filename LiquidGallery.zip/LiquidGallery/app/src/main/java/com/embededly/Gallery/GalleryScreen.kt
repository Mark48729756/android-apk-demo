package com.embededly.Gallery

import android.app.Activity
import android.content.IntentSender
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.format.DateUtils
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlin.math.abs

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryScreen(launch: LaunchInfo) {
    val ctx = LocalContext.current
    val prefs = LocalPrefs.current
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current

    var media by remember { mutableStateOf<List<Media>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var trashCount by remember { mutableIntStateOf(0) }
    LaunchedEffect(prefs.sortKey.value, prefs.sortDesc.value, prefs.showPhotos.value, prefs.showVideos.value, reload) {
        media = loadMedia(ctx, prefs.sortKey.value, prefs.sortDesc.value, prefs.showPhotos.value, prefs.showVideos.value)
        loaded = true
    }

    LaunchedEffect(reload) {
        trashCount = if (android.os.Build.VERSION.SDK_INT >= 30) loadMedia(ctx, "date_modified", true, true, true, trashed = true).size else 0
    }
    DisposableEffect(Unit) {
        val h = Handler(Looper.getMainLooper())
        val r = Runnable { reload++ }
        val obs = object : ContentObserver(h) {
            override fun onChange(selfChange: Boolean) { h.removeCallbacks(r); h.postDelayed(r, 800) }
        }
        ctx.contentResolver.registerContentObserver(MediaStore.Files.getContentUri("external"), true, obs)
        onDispose { ctx.contentResolver.unregisterContentObserver(obs); h.removeCallbacks(r) }
    }

    var tab by remember { mutableIntStateOf(0) }
    var album by remember { mutableStateOf<Album?>(null) }
    var searchOn by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var viewer by remember { mutableStateOf<Int?>(null) }
    var extra by remember { mutableStateOf<List<Media>?>(null) }
    var settings by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<Media?>(null) }
    var trash by remember { mutableStateOf(false) }
    var listScreen by remember { mutableStateOf<Pair<String, List<Album>>?>(null) }
    var selected by remember { mutableStateOf<Set<Long>>(emptySet()) }
    val backdrop = rememberLayerBackdrop()

    fun group(l: List<Media>) = l.groupBy { it.bucketId }.map { (id, m) -> Album(id, m.first().bucket, m) }

    val hidden = prefs.hidden.value
    val allAlbums = remember(media) { group(media) }
    val visible = remember(media, hidden) { media.filter { it.bucketId.toString() !in hidden } }
    val albumSort = prefs.albumSort.value
    val albums = remember(visible, albumSort) {
        val g = group(visible)
        val sorted = when (albumSort) {
            "count" -> g.sortedByDescending { it.items.size }
            "name" -> g.sortedBy { it.name.lowercase() }
            else -> g
        }
        sorted
    }
    val curAlbum = album
    val shown = remember(visible, curAlbum, query) {
        visible.filter { (when (curAlbum?.id) { null, ALL_ID -> true; FAV_ID -> it.fav; VIDEO_ID -> it.isVideo; else -> it.bucketId == curAlbum?.id }) && (query.isBlank() || it.bucket.contains(query, true)) }
    }
    val shownAlbums = remember(albums, query) { albums.filter { query.isBlank() || it.name.contains(query, true) } }

    // открытие файла из другого приложения (ACTION_VIEW)
    var handled by remember { mutableStateOf(false) }
    LaunchedEffect(loaded) {
        val u = launch.viewUri
        if (loaded && u != null && !handled) {
            handled = true
            val i = media.indexOfFirst { it.uri == u }
            if (i >= 0) viewer = i else {
                val video = ctx.contentResolver.getType(u)?.startsWith("video") == true
                extra = listOf(Media(0, u, video, 0, "", 0)); viewer = 0
            }
        }
    }
    val viewList = extra ?: shown

    // системные подтверждения: корзина, избранное
    var afterOk by remember { mutableStateOf<(() -> Unit)?>(null) }
    val senderLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) afterOk?.invoke()
        afterOk = null
    }
    fun runSender(s: IntentSender?, ok: () -> Unit) {
        if (s == null) { ok(); return }
        afterOk = ok
        senderLauncher.launch(IntentSenderRequest.Builder(s).build())
    }
    fun requestDelete(list: List<Media>) {
        val s = try { trashSender(ctx, list, true) } catch (_: Exception) { null }
        runSender(s) { selected = emptySet(); viewer = null; extra = null; reload++ }
    }
    fun toggleFav(m: Media) {
        runSender(try { favSender(ctx, listOf(m), !m.fav) } catch (_: Exception) { null }) { reload++ }
    }

    BackHandler(trash) { trash = false }
    BackHandler(edit != null) { edit = null }
    BackHandler(edit == null && !trash && settings) { settings = false }
    BackHandler(edit == null && !trash && !settings && viewer == null && listScreen != null) { listScreen = null }
    BackHandler(edit == null && !settings && viewer != null) { viewer = null; extra = null }
    BackHandler(edit == null && !settings && viewer == null && selected.isNotEmpty()) { selected = emptySet() }
    BackHandler(edit == null && !settings && viewer == null && selected.isEmpty() && curAlbum != null) { album = null }

    val open: (Int) -> Unit = { i -> if (launch.pick) launch.onPick(shown[i].uri) else { extra = null; viewer = i } }
    val selecting = selected.isNotEmpty()

    // док прячется при прокрутке вниз и возвращается при прокрутке вверх
    var dockHidden by remember { mutableStateOf(false) }
    val nested = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -12f) dockHidden = true else if (available.y > 12f) dockHidden = false
                return Offset.Zero
            }
        }
    }
    val dockOffset by animateDpAsState(
        if (dockHidden && prefs.autoHideDock.value && !searchOn && !selecting) 150.dp else 0.dp,
        if (prefs.anim.value) spring(.8f, 400f) else snap(), label = "dock")
    val anim = prefs.anim.value
    val slideIn = if (anim) slideInHorizontally(tween(340)) { it } + fadeIn(tween(220)) else EnterTransition.None
    val slideOut = if (anim) slideOutHorizontally(tween(280)) { it } + fadeOut(tween(200)) else ExitTransition.None
    val lastViewer = remember { intArrayOf(0) }
    val lastEdit = remember { arrayOfNulls<Media>(1) }
    viewer?.let { lastViewer[0] = it }
    edit?.let { lastEdit[0] = it }

    Box(Modifier.fillMaxSize().background(pal.bg)) {
        Box(
            Modifier.fillMaxSize().nestedScroll(nested).layerBackdrop(backdrop)
                // жест: свайп влево/вправо — переключение вкладок
                .pointerInput(tab, selecting) {
                    var sum = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { sum = 0f },
                        onDragEnd = {
                            if (!selecting && abs(sum) > 160f) {
                                val t = if (sum < 0) 1 else 0
                                if (t != tab) { tab = t; if (t == 1) album = null }
                            }
                        },
                        onHorizontalDrag = { _, d -> sum += d }
                    )
                }
        ) {
            AnimatedContent(tab, transitionSpec = {
                if (!anim) EnterTransition.None togetherWith ExitTransition.None
                else if (targetState > initialState)
                    (slideInHorizontally(tween(340)) { it / 3 } + fadeIn(tween(340))) togetherWith
                        (slideOutHorizontally(tween(340)) { -it / 3 } + fadeOut(tween(200)))
                else
                    (slideInHorizontally(tween(340)) { -it / 3 } + fadeIn(tween(340))) togetherWith
                        (slideOutHorizontally(tween(340)) { it / 3 } + fadeOut(tween(200)))
            }, label = "tab") { t ->
                if (t == 0) PhotoGrid(shown, prefs.groupByDate.value && prefs.sortKey.value.startsWith("date"), curAlbum?.name ?: t(R.string.s_017),
                    if (curAlbum != null) t(R.string.s_items_n, shown.size) else t(R.string.s_018), selected,
                    onOpen = { i -> if (selecting) selected = selected.toggle(shown[i].id) else open(i) },
                    onLong = { i ->
                        if (!launch.pick) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            selected = selected.toggle(shown[i].id)
                        }
                    })
                else AlbumsScreen(visible, shownAlbums, trashCount,
                    onOpen = { album = it; tab = 0 },
                    onList = { title, list -> listScreen = title to list },
                    onTrash = { trash = true })
            }
        }

        AnimatedVisibility(selecting, Modifier.align(Alignment.TopCenter),
            enter = if (anim) slideInVertically { -it } + fadeIn() else EnterTransition.None,
            exit = if (anim) slideOutVertically { -it } + fadeOut() else ExitTransition.None) {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp)
                    .height(52.dp).clip(RoundedCornerShape(26.dp)).background(pal.glass.copy(alpha = .92f)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton({ selected = emptySet() }) { Icon(Icons.Outlined.Close, null, tint = pal.fg) }
                Text(t(R.string.s_selected_n, selected.size), color = pal.fg, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                IconButton({ shareMedia(ctx, shown.filter { it.id in selected }) }) { Icon(Icons.Outlined.Share, null, tint = pal.fg) }
                IconButton({ requestDelete(shown.filter { it.id in selected }) }) { Icon(Icons.Outlined.Delete, null, tint = pal.fg) }
            }
        }
        if (!selecting) {
            Box(Modifier.align(Alignment.TopEnd).statusBarsPadding()) {
                IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, null, tint = pal.fg) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text(t(R.string.s_019)) }, { menu = false; settings = true })
                    if (android.os.Build.VERSION.SDK_INT >= 30)
                        DropdownMenuItem({ Text(t(R.string.s_020)) }, { menu = false; trash = true })
                    DropdownMenuItem({ Text(t(R.string.s_021)) }, { menu = false; reload++ })
                }
            }
        }

        if (searchOn && !selecting) {
            Box(
                Modifier.align(Alignment.TopCenter).statusBarsPadding()
                    .padding(start = 12.dp, end = 56.dp, top = 4.dp)
                    .fillMaxWidth().height(48.dp)
                    .glassPanel(backdrop, 8f, 0f, 0f, pal.glass.copy(alpha = prefs.dockOpacity.value))
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                BasicTextField(query, { query = it }, singleLine = true,
                    textStyle = TextStyle(color = pal.fg, fontSize = 16.sp),
                    cursorBrush = SolidColor(pal.fg), modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        if (query.isEmpty()) Text(t(R.string.s_022), color = pal.sub, fontSize = 16.sp)
                        inner()
                    })
            }
        }

        GlassDock(
            backdrop, tab,
            onTab = { tab = it; if (it == 1) album = null },
            searchOn = searchOn,
            onSearch = { searchOn = !searchOn; if (!searchOn) query = "" },
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding()
                .padding(bottom = prefs.dockBottom.value.dp).offset(y = dockOffset)
        )

        AnimatedVisibility(viewer != null,
            enter = if (anim) fadeIn(tween(220)) + scaleIn(tween(340), initialScale = .9f) else EnterTransition.None,
            exit = if (anim) fadeOut(tween(180)) + scaleOut(tween(220), targetScale = .96f) else ExitTransition.None) {
            Viewer(viewList, lastViewer[0].coerceIn(0, (viewList.size - 1).coerceAtLeast(0)), prefs.slideshowSec.value,
                onFav = { m -> toggleFav(m) },
                onSetAs = { m -> setAs(ctx, m) },
                onClose = { viewer = null; extra = null },
                onShare = { m -> shareMedia(ctx, listOf(m)) },
                onEdit = { m -> edit = m },
                onDelete = { m -> requestDelete(listOf(m)) })
        }
        AnimatedVisibility(listScreen != null, enter = slideIn, exit = slideOut) {
            listScreen?.let { (title, list) ->
                AlbumListScreen(title, list, onOpen = { album = it; tab = 0; listScreen = null }, onBack = { listScreen = null })
            }
        }
        AnimatedVisibility(trash, enter = slideIn, exit = slideOut) { TrashScreen({ trash = false }) { reload++ } }
        AnimatedVisibility(settings, enter = slideIn, exit = slideOut) { SettingsScreen(allAlbums, { reload++ }) { settings = false } }
        AnimatedVisibility(edit != null,
            enter = if (anim) slideInVertically(tween(340)) { it } + fadeIn(tween(200)) else EnterTransition.None,
            exit = if (anim) slideOutVertically(tween(280)) { it } + fadeOut(tween(200)) else ExitTransition.None) {
            lastEdit[0]?.let { m ->
                val done: () -> Unit = { edit = null; viewer = null; extra = null; reload++ }
                if (m.isVideo) TrimScreen(m, { edit = null }, done) else CropScreen(m, { edit = null }, done)
            }
        }
    }
}

private fun Set<Long>.toggle(id: Long) = if (id in this) this - id else this + id

@Composable
private fun Header(title: String, sub: String) {
    val pal = LocalPal.current
    if (!LocalPrefs.current.showHeader.value) {
        Spacer(Modifier.statusBarsPadding().height(56.dp)); return
    }
    Column(Modifier.statusBarsPadding().padding(top = 56.dp, start = 20.dp, bottom = 16.dp)) {
        Text(title, color = pal.fg, fontSize = 44.sp, fontWeight = FontWeight.Bold)
        Text(sub, color = pal.sub, fontSize = 15.sp)
    }
}

private sealed interface Entry {
    data class H(val key: Long, val label: String) : Entry
    data class I(val m: Media, val idx: Int) : Entry
}

private fun buildEntries(items: List<Media>, grouped: Boolean): List<Entry> {
    if (!grouped) return items.mapIndexed { i, m -> Entry.I(m, i) }
    val zone = ZoneId.systemDefault()
    val now = System.currentTimeMillis()
    val out = ArrayList<Entry>(items.size + 32)
    var last = Long.MIN_VALUE
    items.forEachIndexed { i, m ->
        val day = Instant.ofEpochMilli(m.dateMs).atZone(zone).toLocalDate().toEpochDay()
        if (day != last) {
            last = day
            val start = LocalDate.ofEpochDay(day).atStartOfDay(zone).toInstant().toEpochMilli()
            out += Entry.H(day, DateUtils.getRelativeTimeSpanString(start, now, DateUtils.DAY_IN_MILLIS).toString())
        }
        out += Entry.I(m, i)
    }
    return out
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PhotoGrid(
    items: List<Media>, grouped: Boolean, title: String, sub: String, selected: Set<Long>,
    onOpen: (Int) -> Unit, onLong: (Int) -> Unit,
) {
    val prefs = LocalPrefs.current
    val pal = LocalPal.current
    val gap = prefs.gap.value.dp
    val entries = remember(items, grouped) { buildEntries(items, grouped) }
    LazyVerticalGrid(
        GridCells.Fixed(prefs.photoCols.value),
        Modifier.fillMaxSize()
            // жест: щипок двумя пальцами — меньше/больше колонок
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    var acc = 1f
                    do {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.changes.count { it.pressed } >= 2) acc *= ev.calculateZoom()
                    } while (ev.changes.any { it.pressed })
                    val c = prefs.photoCols.value
                    if (acc > 1.35f) prefs.photoCols.set((c - 1).coerceAtLeast(2))
                    else if (acc < .74f) prefs.photoCols.set((c + 1).coerceAtMost(6))
                }
            },
        contentPadding = PaddingValues(bottom = 130.dp),
        verticalArrangement = Arrangement.spacedBy(gap),
        horizontalArrangement = Arrangement.spacedBy(gap)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { Header(title, sub) }
        items(
            entries.size,
            key = { when (val e = entries[it]) { is Entry.H -> "h${e.key}"; is Entry.I -> e.m.id } },
            span = { if (entries[it] is Entry.H) GridItemSpan(maxLineSpan) else GridItemSpan(1) }
        ) { k ->
            when (val e = entries[k]) {
                is Entry.H -> Text(e.label, color = pal.fg, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 6.dp))
                is Entry.I -> {
                    val m = e.m
                    val sel = m.id in selected
                    Box((if (prefs.anim.value) Modifier.animateItem() else Modifier).aspectRatio(1f).background(pal.fg.copy(alpha = .06f))
                        .combinedClickable(onClick = { onOpen(e.idx) }, onLongClick = { onLong(e.idx) })) {
                        AsyncImage(m.uri, null, Modifier.fillMaxSize(),
                            contentScale = if (prefs.thumbFit.value) ContentScale.Fit else ContentScale.Crop)
                        if (m.isVideo && prefs.showDuration.value)
                            Text("▶ " + fmtDur(m.durationMs), color = Color.White, fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp))
                        if (m.fav) Text("♥", color = Color(0xFFFF375F), fontSize = 14.sp,
                            modifier = Modifier.align(Alignment.BottomStart).padding(6.dp))
                        AnimatedVisibility(sel, Modifier.matchParentSize(),
                            enter = if (prefs.anim.value) fadeIn() + scaleIn(initialScale = .85f) else EnterTransition.None,
                            exit = if (prefs.anim.value) fadeOut() + scaleOut(targetScale = .85f) else ExitTransition.None) {
                            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .35f))) {
                                Box(Modifier.align(Alignment.TopStart).padding(6.dp).size(22.dp).clip(CircleShape).background(pal.accent),
                                    contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(15.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
