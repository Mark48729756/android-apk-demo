package com.embededly.Gallery

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.SingletonImageLoader
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(allAlbums: List<Album>, onReload: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pal = LocalPal.current
    val p = LocalPrefs.current

    Column(Modifier.fillMaxSize().background(pal.bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = pal.fg) }
            Text(t(R.string.s_019), color = pal.fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).navigationBarsPadding().padding(bottom = 32.dp)) {

            Section(t(R.string.s_026)) {
                Choice(t(R.string.s_027), p.theme, listOf("dark" to t(R.string.s_028), "light" to t(R.string.s_029), "system" to t(R.string.s_030)))
                Switch1(t(R.string.s_031), t(R.string.s_032), p.amoled)
                AccentRow()
                Switch1(t(R.string.s_033), t(R.string.s_034), p.anim)
                Switch1(t(R.string.s_035), null, p.haptics)
            }

            Section("Liquid Glass") {
                Switch1(t(R.string.s_036), t(R.string.s_037), p.glass)
                Switch1(t(R.string.s_038), null, p.vibrancy)
                SliderF(t(R.string.s_039), p.dockBlur, 0f..24f) { "${it.roundToInt()} dp" }
                SliderF(t(R.string.s_040), p.dockRefH, 0f..32f) { "${it.roundToInt()} dp" }
                SliderF(t(R.string.s_041), p.dockRefA, 0f..64f) { "${it.roundToInt()} dp" }
                SliderF(t(R.string.s_042), p.lensBlur, 0f..8f) { "%.1f dp".format(it) }
                SliderF(t(R.string.s_043), p.lensRefH, 0f..40f) { "${it.roundToInt()} dp" }
                SliderF(t(R.string.s_044), p.lensRefA, 0f..80f) { "${it.roundToInt()} dp" }
                SliderF(t(R.string.s_045), p.lensTint, 0f..0.4f) { "${(it * 100).roundToInt()}%" }
                SliderF(t(R.string.s_046), p.lensGrow, 0f..0.3f) { "${(it * 100).roundToInt()}%" }
                SliderF(t(R.string.s_047), p.dockOpacity, 0.05f..1f) { "${(it * 100).roundToInt()}%" }
                SliderF(t(R.string.s_048), p.stiffness, 100f..1000f) { "${it.roundToInt()}" }
                SliderF(t(R.string.s_049), p.damping, 0.3f..1f) { "%.2f".format(it) }
                SliderI(t(R.string.s_050), p.dockHeight, 48..84) { "$it dp" }
                SliderI(t(R.string.s_051), p.dockBottom, 0..48) { "$it dp" }
                Switch1(t(R.string.s_052), null, p.dockLabels)
                Switch1(t(R.string.s_053), null, p.searchButton)
                Switch1(t(R.string.s_054), t(R.string.s_055), p.autoHideDock)
            }

            Section(t(R.string.s_056)) {
                SliderI(t(R.string.s_057), p.photoCols, 2..6) { "$it" }
                SliderI(t(R.string.s_058), p.albumCols, 2..4) { "$it" }
                SliderI(t(R.string.s_059), p.gap, 0..8) { "$it dp" }
                SliderI(t(R.string.s_060), p.albumRadius, 0..32) { "$it dp" }
                Switch1(t(R.string.s_061), null, p.thumbFit)
                Switch1(t(R.string.s_062), null, p.showDuration)
                Switch1(t(R.string.s_063), null, p.showHeader)
                Switch1(t(R.string.s_064), null, p.showAlbumCount)
                Switch1(t(R.string.s_065), t(R.string.s_066), p.groupByDate)
            }

            Section(t(R.string.s_067)) {
                Switch1(t(R.string.s_068), null, p.showPhotos)
                Switch1(t(R.string.s_069), null, p.showVideos)
                Choice(t(R.string.s_070), p.sortKey, listOf(
                    "date_added" to t(R.string.s_071), "date_modified" to t(R.string.s_006),
                    "_display_name" to t(R.string.s_072), "_size" to t(R.string.s_073)))
                Switch1(t(R.string.s_074), t(R.string.s_075), p.sortDesc)
                Choice(t(R.string.s_076), p.albumSort, listOf("recent" to t(R.string.s_077), "count" to t(R.string.s_078), "name" to t(R.string.s_079)))
            }

            Section(t(R.string.s_080)) {
                if (allAlbums.isEmpty()) Note(t(R.string.s_081))
                allAlbums.forEach { a ->
                    val id = a.id.toString()
                    val isHidden = id in p.hidden.value
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(a.name, color = pal.fg, fontSize = 16.sp, maxLines = 1)
                            Text(t(R.string.s_items_n, a.items.size), color = pal.sub, fontSize = 12.sp)
                        }
                        Switch(isHidden, { p.hidden.set(if (it) p.hidden.value + id else p.hidden.value - id) },
                            colors = swColors())
                    }
                }
            }

            Section(t(R.string.s_082)) {
                Choice(t(R.string.s_083), p.viewerBg, listOf("black" to t(R.string.s_084), "theme" to t(R.string.s_085)))
                Switch1(t(R.string.s_086), null, p.viewerFill)
                Switch1(t(R.string.s_087), null, p.viewerClose)
                Switch1(t(R.string.s_088), null, p.viewerCounter)
                SliderI(t(R.string.s_089), p.slideshowSec, 2..10) { t(R.string.s_sec_fmt, it) }
            }

            Section(t(R.string.s_090)) {
                Action(t(R.string.s_091), t(R.string.s_092)) {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", ctx.packageName, null)))
                }
                Action(t(R.string.s_093), t(R.string.s_094)) { onReload() }
                Action(t(R.string.s_095), null) {
                    SingletonImageLoader.get(ctx).let { it.memoryCache?.clear(); it.diskCache?.clear() }
                    Toast.makeText(ctx, t(R.string.s_096), Toast.LENGTH_SHORT).show()
                }
                Action(t(R.string.s_097), t(R.string.s_098)) {
                    p.resetAll(); onReload()
                    Toast.makeText(ctx, t(R.string.s_099), Toast.LENGTH_SHORT).show()
                }
                val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (_: Exception) { "?" }
                Note(t(R.string.s_about, ver))
            }
        }
    }
}

// ---------- кирпичики ----------
@Composable
private fun swColors(): SwitchColors {
    val pal = LocalPal.current
    return SwitchDefaults.colors(checkedTrackColor = pal.accent, checkedThumbColor = Color.White)
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Text(title.uppercase(), color = pal.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 20.dp, top = 24.dp, bottom = 8.dp))
    Column(Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp))
        .background(pal.fg.copy(alpha = .08f))) { content() }
}

@Composable
private fun Note(text: String) {
    Text(text, color = LocalPal.current.sub, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
}

@Composable
private fun Switch1(title: String, sub: String?, pref: Pref<Boolean>) {
    val pal = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = pal.fg, fontSize = 16.sp)
            if (sub != null) Text(sub, color = pal.sub, fontSize = 12.sp)
        }
        Switch(pref.value, { pref.set(it) }, colors = swColors())
    }
}

@Composable
private fun SliderF(title: String, pref: Pref<Float>, range: ClosedFloatingPointRange<Float>, fmt: (Float) -> String) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row {
            Text(title, color = pal.fg, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(fmt(pref.value), color = pal.sub, fontSize = 14.sp)
        }
        Slider(pref.value, { pref.set(it) }, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent))
    }
}

@Composable
private fun SliderI(title: String, pref: Pref<Int>, range: IntRange, fmt: (Int) -> String) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row {
            Text(title, color = pal.fg, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(fmt(pref.value), color = pal.sub, fontSize = 14.sp)
        }
        Slider(pref.value.toFloat(), { pref.set(it.roundToInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(), steps = range.last - range.first - 1,
            colors = SliderDefaults.colors(thumbColor = pal.accent, activeTrackColor = pal.accent))
    }
}

@Composable
private fun Choice(title: String, pref: Pref<String>, options: List<Pair<String, String>>) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(title, color = pal.fg, fontSize = 16.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (k, label) ->
                val sel = pref.value == k
                Text(label, color = if (sel) Color.White else pal.fg, fontSize = 14.sp,
                    modifier = Modifier.clip(CircleShape)
                        .background(if (sel) pal.accent else pal.fg.copy(alpha = .1f))
                        .clickable { pref.set(k) }.padding(horizontal = 14.dp, vertical = 8.dp))
            }
        }
    }
}

@Composable
private fun AccentRow() {
    val pal = LocalPal.current
    val p = LocalPrefs.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(t(R.string.s_100), color = pal.fg, fontSize = 16.sp)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ACCENTS.forEachIndexed { i, c ->
                Box(Modifier.size(34.dp).clip(CircleShape).background(c)
                    .border(if (p.accent.value == i) 3.dp else 0.dp, pal.fg, CircleShape)
                    .clickable { p.accent.set(i) })
            }
        }
    }
}

@Composable
private fun Action(title: String, sub: String?, onClick: () -> Unit) {
    val pal = LocalPal.current
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp)) {
        Text(title, color = pal.fg, fontSize = 16.sp)
        if (sub != null) Text(sub, color = pal.sub, fontSize = 12.sp)
    }
}
