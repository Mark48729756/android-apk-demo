package com.embededly.Gallery

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PhotoAlbum
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/** Стеклянная панель по настройкам; при выключенном «Liquid Glass» — обычная полупрозрачная заливка. */
@Composable
fun Modifier.glassPanel(backdrop: Backdrop, blurDp: Float, refH: Float, refA: Float, surface: Color): Modifier {
    val prefs = LocalPrefs.current
    if (!prefs.glass.value) return this.background(surface.copy(alpha = (surface.alpha + .35f).coerceAtMost(.95f)), CircleShape)
    val vib = prefs.vibrancy.value
    return this.drawBackdrop(
        backdrop, { CircleShape },
        effects = {
            if (vib) vibrancy()
            if (blurDp > 0f) blur(blurDp.dp.toPx())
            if (refH > 0f) lens(refH.dp.toPx(), refA.dp.toPx())
        },
        onDrawSurface = { drawRect(surface) }
    )
}

@Composable
fun GlassDock(
    backdrop: Backdrop, tab: Int, onTab: (Int) -> Unit,
    searchOn: Boolean, onSearch: () -> Unit, modifier: Modifier = Modifier,
) {
    val prefs = LocalPrefs.current
    val pal = LocalPal.current
    val haptic = LocalHapticFeedback.current
    val dockH = prefs.dockHeight.value.dp
    val seg = (dockH.value * 1.44f).dp
    val segPx = with(LocalDensity.current) { seg.toPx() }
    val scope = rememberCoroutineScope()
    val pos = remember { Animatable(tab.toFloat()) }
    var pressed by remember { mutableStateOf(false) }
    val spec: AnimationSpec<Float> =
        if (prefs.anim.value) spring(prefs.damping.value, prefs.stiffness.value) else snap()
    val grow by animateFloatAsState(if (pressed) prefs.lensGrow.value else 0f, spec, label = "grow")
    val onTabNow by rememberUpdatedState(onTab)
    val hapticOn by rememberUpdatedState(prefs.haptics.value)

    LaunchedEffect(tab) { if (!pressed) pos.animateTo(tab.toFloat(), spec) }

    val tabs = listOf(Icons.Outlined.Image to t(R.string.s_017), Icons.Outlined.PhotoAlbum to t(R.string.s_023))
    val idle = pal.fg.copy(alpha = .85f)
    val dockSurface = pal.glass.copy(alpha = prefs.dockOpacity.value)

    Row(modifier, horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(seg * 2, dockH)
                .glassPanel(backdrop, prefs.dockBlur.value, prefs.dockRefH.value, prefs.dockRefA.value, dockSurface)
                .pointerInput(segPx, spec) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        pressed = true
                        if (hapticOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        var x = down.position.x
                        fun target() = (x / segPx - .5f).coerceIn(0f, 1f)
                        scope.launch { pos.animateTo(target(), spec) }
                        drag(down.id) { ch ->
                            x = ch.position.x
                            scope.launch { pos.snapTo(target()) }
                            ch.consume()
                        }
                        val t = target().roundToInt()
                        pressed = false
                        scope.launch { pos.animateTo(t.toFloat(), spec) }
                        onTabNow(t)
                    }
                }
        ) {
            Row(Modifier.fillMaxSize()) {
                tabs.forEachIndexed { i, (icon, label) ->
                    val k = (1f - abs(pos.value - i)).coerceIn(0f, 1f)
                    val col = lerp(idle, pal.accent, k)
                    Column(Modifier.weight(1f).fillMaxHeight(), Arrangement.Center, Alignment.CenterHorizontally) {
                        Icon(icon, null, tint = col, modifier = Modifier.size(24.dp))
                        if (prefs.dockLabels.value) Text(label, color = col, fontSize = 10.5.sp)
                    }
                }
            }
            val w = seg * (1f + grow)
            val h = dockH * (1f + grow)
            Box(
                Modifier
                    .offset {
                        IntOffset(
                            (pos.value * segPx - (w.toPx() - segPx) / 2f).roundToInt(),
                            (-(h.toPx() - dockH.toPx()) / 2f).roundToInt()
                        )
                    }
                    .size(w, h)
                    .glassPanel(backdrop, prefs.lensBlur.value, prefs.lensRefH.value, prefs.lensRefA.value,
                        pal.fg.copy(alpha = prefs.lensTint.value))
            )
        }
        if (prefs.searchButton.value) {
            Box(
                Modifier.size(dockH)
                    .glassPanel(backdrop, prefs.dockBlur.value, prefs.dockRefH.value, prefs.dockRefA.value,
                        if (searchOn) pal.accent.copy(alpha = .45f) else dockSurface)
                    .clickable(remember { MutableInteractionSource() }, null) {
                        if (hapticOn) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onSearch()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Search, null, tint = if (searchOn) pal.accent else idle, modifier = Modifier.size(26.dp))
            }
        }
    }
}
