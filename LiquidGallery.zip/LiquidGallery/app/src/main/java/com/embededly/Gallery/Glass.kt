package com.embededly.Gallery

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import kotlin.math.roundToInt

/** Переключатель в стиле стекла (вместо Material Switch). */
@Composable
fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val pal = LocalPal.current
    val x by animateFloatAsState(if (checked) 1f else 0f, spring(.7f, 500f), label = "sw")
    Box(
        Modifier.size(52.dp, 32.dp).clip(CircleShape)
            .background(lerp(pal.fg.copy(alpha = .18f), pal.accent, x))
            .clickable(remember { MutableInteractionSource() }, null) { onChange(!checked) }
            .padding(3.dp)
    ) {
        Box(
            Modifier.offset(x = 20.dp * x).size(26.dp).clip(CircleShape).background(Color.White)
                .border(.5.dp, Color.Black.copy(alpha = .12f), CircleShape)
        )
    }
}

/** Ползунок в стиле стекла (вместо Material Slider). */
@Composable
fun GlassSlider(value: Float, range: ClosedFloatingPointRange<Float>, steps: Int = 0, onChange: (Float) -> Unit) {
    val pal = LocalPal.current
    var w by remember { mutableIntStateOf(0) }
    val span = range.endInclusive - range.start
    val frac = ((value - range.start) / span).coerceIn(0f, 1f)
    val onNow by rememberUpdatedState(onChange)
    fun at(x: Float): Float {
        val f = (x / w.coerceAtLeast(1)).coerceIn(0f, 1f)
        return if (steps > 0) range.start + (f * steps).roundToInt() * span / steps else range.start + f * span
    }
    Box(
        Modifier.fillMaxWidth().height(36.dp).padding(horizontal = 13.dp)
            .onSizeChanged { w = it.width }
            .pointerInput(range, steps) { detectTapGestures { onNow(at(it.x)) } }
            .pointerInput(range, steps) { detectHorizontalDragGestures { ch, _ -> ch.consume(); onNow(at(ch.position.x)) } }
    ) {
        Box(Modifier.align(Alignment.CenterStart).fillMaxWidth().height(6.dp).clip(CircleShape).background(pal.fg.copy(alpha = .15f)))
        Box(Modifier.align(Alignment.CenterStart).fillMaxWidth(frac).height(6.dp).clip(CircleShape).background(pal.accent))
        Box(
            Modifier.align(Alignment.CenterStart)
                .offset { IntOffset((w * frac - 13.dp.toPx()).roundToInt(), 0) }
                .size(26.dp).clip(CircleShape).background(Color.White)
                .border(.5.dp, Color.Black.copy(alpha = .12f), CircleShape)
        )
    }
}

/** Кнопка-«капсула» (вместо Material Button). */
@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, primary: Boolean = true, onClick: () -> Unit) {
    val pal = LocalPal.current
    Box(
        modifier.height(48.dp).graphicsLayer { alpha = if (enabled) 1f else .4f }
            .clip(CircleShape)
            .background(if (primary) pal.accent else pal.fg.copy(alpha = .12f))
            .border(1.dp, Color.White.copy(alpha = .16f), CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (primary) Color.White else pal.fg, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Стеклянное всплывающее меню (вместо Material DropdownMenu). Ставится в Box, положение — через modifier. */
@Composable
fun GlassMenu(
    visible: Boolean, backdrop: Backdrop, onDismiss: () -> Unit, modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    val pal = LocalPal.current
    if (visible) BackHandler(onBack = onDismiss)
    if (visible) Box(Modifier.fillMaxSize().clickable(remember { MutableInteractionSource() }, null) { onDismiss() })
    AnimatedVisibility(
        visible, modifier,
        enter = fadeIn(tween(140)) + scaleIn(spring(.75f, 500f), initialScale = .7f, transformOrigin = TransformOrigin(1f, 0f)),
        exit = fadeOut(tween(110)) + scaleOut(tween(120), targetScale = .85f, transformOrigin = TransformOrigin(1f, 0f)),
    ) {
        Column(
            Modifier.width(220.dp)
                .glassPanel(backdrop, 12f, 8f, 14f, pal.glass.copy(alpha = .62f), RoundedCornerShape(26.dp))
                .padding(vertical = 8.dp),
            content = content
        )
    }
}

@Composable
fun GlassMenuItem(text: String, onClick: () -> Unit) {
    val pal = LocalPal.current
    Text(text, color = pal.fg, fontSize = 16.sp,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 13.dp))
}

/** Стеклянное диалоговое окно (вместо Material AlertDialog). Ставится в Box на весь экран. */
@Composable
fun GlassDialog(backdrop: Backdrop, title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    BackHandler(onBack = onDismiss)
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = .45f))
            .clickable(remember { MutableInteractionSource() }, null) { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.padding(28.dp).fillMaxWidth()
                .glassPanel(backdrop, 16f, 10f, 18f, Color(0xFF1E1E22).copy(alpha = .72f), RoundedCornerShape(30.dp))
                .clickable(remember { MutableInteractionSource() }, null) { }
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            content()
            GlassButton("OK", Modifier.fillMaxWidth().padding(top = 6.dp)) { onDismiss() }
        }
    }
}
