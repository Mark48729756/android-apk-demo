package com.embededly.Gallery

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import com.kyant.backdrop.Backdrop
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Кнопка поиска в доке, которая «перетекает» в строку поиска и уезжает вверх (над клавиатуру).
 * progress: 0 = круглая кнопка в доке, 1 = строка над клавиатурой. Ставится прямо в корневой Box экрана.
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun SearchMorph(
    backdrop: Backdrop, from: Rect?, container: IntSize, on: Boolean, progress: Float,
    query: String, onQuery: (String) -> Unit, onToggle: () -> Unit,
) {
    if (from == null || container.width == 0) return
    val prefs = LocalPrefs.current
    val pal = LocalPal.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val density = LocalDensity.current
    val focus = remember { FocusRequester() }
    val kb = LocalSoftwareKeyboardController.current
    val fm = LocalFocusManager.current
    val ime = WindowInsets.ime
    val nav = WindowInsets.navigationBars
    val hapticOn = prefs.haptics.value

    // клавиатура открывается сама вместе с анимацией и закрывается при возврате
    LaunchedEffect(on) {
        if (on) {
            delay(120)
            try { focus.requestFocus() } catch (_: Exception) {}
            kb?.show()
            delay(250)
            try { focus.requestFocus() } catch (_: Exception) {}
            kb?.show()
        } else {
            fm.clearFocus()
            kb?.hide()
        }
    }

    val p = progress
    val screenW = container.width.toFloat()
    val screenH = container.height.toFloat()
    val margin = with(density) { 12.dp.toPx() }
    val barH = with(density) { 54.dp.toPx() }
    val fieldW = with(density) { (container.width.toDp() - 24.dp - 108.dp).coerceAtLeast(80.dp) }

    // положение и размер считаются на этапе layout, чтобы строка ехала вместе с клавиатурой
    fun rectNow(): FloatArray {
        val bottomInset = max(ime.getBottom(density), nav.getBottom(density)).toFloat()
        val tb = screenH - bottomInset - margin
        val tt = tb - barH
        return floatArrayOf(
            lerp(from.left, margin, p), lerp(from.top, tt, p),
            lerp(from.right, screenW - margin, p), lerp(from.bottom, tb, p)
        )
    }
    Box(
        Modifier
            .offset { val r = rectNow(); IntOffset(r[0].roundToInt(), r[1].roundToInt()) }
            .layout { measurable, _ ->
                val r = rectNow()
                val w = (r[2] - r[0]).roundToInt().coerceAtLeast(1)
                val h = (r[3] - r[1]).roundToInt().coerceAtLeast(1)
                val pl = measurable.measure(Constraints.fixed(w, h))
                layout(w, h) { pl.place(0, 0) }
            }
            .glassPanel(backdrop, 8f, 10f, 16f, pal.glass.copy(alpha = prefs.dockOpacity.value))
            .clip(CircleShape)
            // нажатие считается только внутри самой круглой/капсульной формы, а не по углам квадрата
            .pointerInput(on) {
                if (!on) detectTapGestures { o ->
                    val w = size.width.toFloat(); val h = size.height.toFloat(); val r = h / 2f
                    val cx = o.x.coerceIn(r, (w - r).coerceAtLeast(r))
                    val dx = o.x - cx; val dy = o.y - r
                    if (dx * dx + dy * dy <= r * r) {
                        if (hapticOn) haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                        onToggle()
                    }
                }
            }
    ) {
        val fieldAlpha = ((p - .45f) * 2.2f).coerceIn(0f, 1f)
        Icon(
            Icons.Outlined.Search, null,
            tint = pal.fg.copy(alpha = .85f),
            modifier = Modifier.align(Alignment.CenterStart).padding(start = 19.dp).size(26.dp)
        )
        Box(
            Modifier.align(Alignment.CenterStart).padding(start = 56.dp).requiredWidth(fieldW)
                .graphicsLayer { alpha = fieldAlpha }
        ) {
            BasicTextField(
                query, onQuery, singleLine = true,
                textStyle = TextStyle(color = pal.fg, fontSize = 17.sp),
                cursorBrush = SolidColor(pal.fg),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { kb?.hide() }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus),
                decorationBox = { inner ->
                    if (query.isEmpty()) Text(t(R.string.s_022), color = pal.sub, fontSize = 17.sp)
                    inner()
                }
            )
        }
        Box(
            Modifier.align(Alignment.CenterEnd).padding(end = 8.dp).size(40.dp)
                .graphicsLayer { alpha = fieldAlpha }
                .clip(CircleShape)
                .clickable(remember { MutableInteractionSource() }, null, enabled = on) { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.Close, null, tint = pal.fg, modifier = Modifier.size(22.dp))
        }
    }
}
