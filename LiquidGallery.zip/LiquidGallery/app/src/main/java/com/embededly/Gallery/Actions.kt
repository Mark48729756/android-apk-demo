package com.embededly.Gallery

import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.text.format.DateFormat
import android.text.format.Formatter
import java.io.File
import java.util.Date

fun shareMedia(ctx: Context, list: List<Media>) {
    if (list.isEmpty()) return
    val i = if (list.size == 1) Intent(Intent.ACTION_SEND)
        .putExtra(Intent.EXTRA_STREAM, list[0].uri)
        .setType(if (list[0].isVideo) "video/*" else "image/*")
    else Intent(Intent.ACTION_SEND_MULTIPLE)
        .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList<Uri>(list.map { it.uri }))
        .setType("*/*")
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try { ctx.startActivity(Intent.createChooser(i, null)) } catch (_: Exception) { }
}

/** null = всё удалено сразу (API 29) или нечего подтверждать; иначе — системный диалог подтверждения. */
fun deleteSender(ctx: Context, list: List<Media>): IntentSender? {
    val uris = list.map { it.uri }
    if (uris.isEmpty()) return null
    if (Build.VERSION.SDK_INT >= 30) return MediaStore.createDeleteRequest(ctx.contentResolver, uris).intentSender
    for (u in uris) try {
        ctx.contentResolver.delete(u, null, null)
    } catch (e: RecoverableSecurityException) {
        return e.userAction.actionIntent.intentSender
    } catch (_: Exception) { }
    return null
}

fun saveImage(ctx: Context, bmp: Bitmap): Uri? {
    val cr = ctx.contentResolver
    val v = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Gallery")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
    cr.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
    v.clear(); v.put(MediaStore.MediaColumns.IS_PENDING, 0)
    cr.update(uri, v, null, null)
    return uri
}

fun saveVideo(ctx: Context, f: File): Uri? {
    val cr = ctx.contentResolver
    val v = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${System.currentTimeMillis()}.mp4")
        put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Gallery")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val uri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return null
    cr.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
    v.clear(); v.put(MediaStore.MediaColumns.IS_PENDING, 0)
    cr.update(uri, v, null, null)
    return uri
}

fun mediaInfo(ctx: Context, m: Media): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    try {
        ctx.contentResolver.query(
            m.uri, arrayOf("_display_name", "_size", "mime_type", "date_modified", "width", "height", "relative_path"),
            null, null, null
        )?.use { c ->
            if (c.moveToFirst()) {
                fun s(n: String) = c.getColumnIndex(n).let { if (it >= 0) c.getString(it) else null }
                s("_display_name")?.let { out += t(R.string.s_001) to it }
                s("relative_path")?.let { out += t(R.string.s_002) to it }
                s("mime_type")?.let { out += t(R.string.s_003) to it }
                val w = s("width"); val h = s("height")
                if (!w.isNullOrBlank() && w != "0") out += t(R.string.s_004) to "$w × $h"
                s("_size")?.toLongOrNull()?.let { out += t(R.string.s_005) to Formatter.formatFileSize(ctx, it) }
                s("date_modified")?.toLongOrNull()?.let {
                    out += t(R.string.s_006) to DateFormat.format("dd.MM.yyyy HH:mm", Date(it * 1000)).toString()
                }
            }
        }
    } catch (_: Exception) { }
    if (m.isVideo && m.durationMs > 0) out += t(R.string.s_007) to fmtDur(m.durationMs)
    return out
}

/** В корзину (Android 11+) / удаление (Android 10). */
fun trashSender(ctx: Context, list: List<Media>, trash: Boolean): IntentSender? {
    if (list.isEmpty()) return null
    return if (Build.VERSION.SDK_INT >= 30)
        MediaStore.createTrashRequest(ctx.contentResolver, list.map { it.uri }, trash).intentSender
    else if (trash) deleteSender(ctx, list) else null
}

fun favSender(ctx: Context, list: List<Media>, fav: Boolean): IntentSender? =
    if (Build.VERSION.SDK_INT >= 30 && list.isNotEmpty())
        MediaStore.createFavoriteRequest(ctx.contentResolver, list.map { it.uri }, fav).intentSender
    else null

fun setAs(ctx: Context, m: Media) {
    val i = Intent(Intent.ACTION_ATTACH_DATA).setDataAndType(m.uri, "image/*")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION).putExtra("mimeType", "image/*")
    try { ctx.startActivity(Intent.createChooser(i, null)) } catch (_: Exception) { }
}
