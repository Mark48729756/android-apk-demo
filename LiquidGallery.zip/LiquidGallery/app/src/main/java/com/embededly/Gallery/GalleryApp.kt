package com.embededly.Gallery

import android.app.Application
import android.content.Context
import androidx.annotation.StringRes
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.SingletonImageLoader
import coil3.video.VideoFrameDecoder

lateinit var appCtx: Context

fun t(@StringRes id: Int): String = appCtx.getString(id)
fun t(@StringRes id: Int, vararg args: Any): String = appCtx.getString(id, *args)

class GalleryApp : Application(), SingletonImageLoader.Factory {
    override fun onCreate() { super.onCreate(); appCtx = this }
    override fun newImageLoader(context: PlatformContext): ImageLoader =
        ImageLoader.Builder(context).components { add(VideoFrameDecoder.Factory()) }.build()
}
