# Галерея (com.embededly.Gallery)

Нативная галерея на Kotlin + Jetpack Compose с liquid glass (Kyant0/AndroidLiquidGlass).

## Как получить готовый APK (без ПК, с телефона)
1. Создай репозиторий на github.com (можно приватный), загрузи в него ВСЁ содержимое этой папки (Add file → Upload files).
2. Открой вкладку Actions → «Build APK» → Run workflow (или просто дождись автозапуска после загрузки).
3. Через ~5 минут открой раздел Releases репозитория → скачай Gallery.apk → установи.
Каждая новая сборка подписана одним и тем же ключом (keystore/), поэтому ставится поверх прошлой.

## Для предустановки в ОС
См. папку rom/ (Android.bp и default-permissions). Для системной подписи замени keystore на ключ платформы.
