MIUXHook 0.6.0 — интерфейс на Miuix (compose-miuix-ui/miuix 0.9.4, стиль Xiaomi HyperOS).

Что внутри
  app/    приложение модуля: Compose + Miuix (TopAppBar с большим заголовком, NavigationBar, Card,
          SwitchPreference, SliderPreference, BasicComponent). Три вкладки: Модуль / Стекло / Диагностика.
          Хуки: HookEntry, SystemUiHooks (блюр SystemUI), GlassHooks, FluentHooks, PressSpring.
  miux/   только движок для хуков: шейдер стекла, GlassDrawable, пружины, свет от гироскопа, MiuxConfig.
          Старых виджетов MiUX (Switch, Slider, Dock, Toolbar, SettingsSheet...) больше нет.
  xposed-stub/  заглушка Xposed API для компиляции (в рантайме классы даёт Vector/LSPosed).

Сборка
  GitHub Actions (.github/workflows/build.yml): gradle :app:assembleRelease -> артефакт miuxhook (release + R8).
  Локально: Android Studio (свежая) или Gradle 9.7.1 + JDK 21: gradle :app:assembleRelease.
  Версии как в Miuix 0.9.4: AGP 9.4.1, Kotlin 2.4.20, compileSdk 37.

ВАЖНО: проект НЕ собирался и не запускался (в моей среде нет доступа к Maven). Код сверен с исходниками Miuix v0.9.4,
но мелкие ошибки компиляции возможны. Пришли лог сборки — поправлю.

После установки: Vector -> модуль -> включить, scope: SystemUI, Настройки, Рабочий стол + нужные приложения,
перезапустить их. Лог: Vector -> Логи, искать "MIUX".
