package de.robv.android.xposed;
public class XposedHelpers {
    public static Class<?> findClass(String n, ClassLoader l) { throw new RuntimeException("stub"); }
    public static XC_MethodHook.Unhook findAndHookMethod(Class<?> c, String m, Object... a) { throw new RuntimeException("stub"); }
    public static XC_MethodHook.Unhook findAndHookMethod(String c, ClassLoader l, String m, Object... a) { throw new RuntimeException("stub"); }
    public static Object getObjectField(Object o, String f) { throw new RuntimeException("stub"); }
    public static boolean getBooleanField(Object o, String f) { throw new RuntimeException("stub"); }
}
