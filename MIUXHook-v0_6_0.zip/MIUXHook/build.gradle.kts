buildscript {
    repositories { google(); mavenCentral() }
    // AGP 9 использует встроенный Kotlin; версию для Miuix 0.9.4 (собран на 2.4.x) задаём явно
    dependencies { classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.20") }
}
plugins {
    id("com.android.application") version "9.4.1" apply false
    id("com.android.library") version "9.4.1" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.20" apply false
}
