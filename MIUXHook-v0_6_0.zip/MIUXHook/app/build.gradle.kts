plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "dev.mark.miuxhook"
    compileSdk = 37
    defaultConfig {
        applicationId = "dev.mark.miuxhook"
        minSdk = 33
        targetSdk = 36
        versionCode = 4
        versionName = "0.6.0"
    }
    buildTypes {
        release {
            optimization.enable = true   // R8: без него Compose + Miuix раздувают APK
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")   // для установки без своего ключа
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    packaging { resources.excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "DebugProbesKt.bin", "kotlin-tooling-metadata.json") }
}
dependencies {
    implementation(project(":miux"))                     // движок стекла/пружин для хуков
    compileOnly(project(":xposed-stub"))                 // реальные классы Xposed даёт Vector/LSPosed
    val miuix = "0.9.4"
    implementation("top.yukonga.miuix.kmp:miuix-ui-android:$miuix")
    implementation("top.yukonga.miuix.kmp:miuix-preference-android:$miuix")
    implementation("top.yukonga.miuix.kmp:miuix-icons-android:$miuix")
    implementation("androidx.activity:activity-compose:1.13.0")
}
