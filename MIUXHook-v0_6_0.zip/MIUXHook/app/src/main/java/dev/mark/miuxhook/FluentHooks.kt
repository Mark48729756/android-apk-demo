package dev.mark.miuxhook

import android.animation.TimeInterpolator
import android.view.MotionEvent
import android.view.View
import android.view.ViewPropertyAnimator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import java.util.Collections
import java.util.WeakHashMap
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp

/** Fluent/iOS-подобное поведение: пружинное нажатие и пружинные анимации View.animate(). */
object FluentHooks {
    class Spring : TimeInterpolator {
        override fun getInterpolation(t: Float): Float {
            if (t >= 1f) return 1f
            return (1f - exp(-6.0 * t) * cos(2 * PI * 1.25 * t)).toFloat()
        }
    }

    fun install(press: Boolean, anim: Boolean) {
        if (press) {
            XposedHelpers.findAndHookMethod(View::class.java, "onTouchEvent", MotionEvent::class.java, object : XC_MethodHook() {
                override fun afterHookedMethod(p: XC_MethodHook.MethodHookParam) {
                    val v = p.thisObject as View
                    val e = p.args[0] as MotionEvent
                    if (!v.isClickable || !v.isEnabled) return
                    val max = 220 * v.resources.displayMetrics.density
                    if (v.width > max || v.height > max) return          // большие карточки и списки не трогаем
                    PressSpring.onTouch(v, e)
                }
            })
        }
        if (anim) {
            // публичный путь: сами помечаем аниматоры, которым приложение задало интерполятор (без скрытых полей)
            val custom = Collections.newSetFromMap(WeakHashMap<ViewPropertyAnimator, Boolean>())
            val own = ThreadLocal<Boolean>()
            XposedHelpers.findAndHookMethod(ViewPropertyAnimator::class.java, "setInterpolator", TimeInterpolator::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(p: XC_MethodHook.MethodHookParam) {
                        if (own.get() != true) custom.add(p.thisObject as ViewPropertyAnimator)
                    }
                })
            XposedHelpers.findAndHookMethod(ViewPropertyAnimator::class.java, "start", object : XC_MethodHook() {
                override fun beforeHookedMethod(p: XC_MethodHook.MethodHookParam) {
                    val a = p.thisObject as ViewPropertyAnimator
                    if (custom.contains(a)) return
                    own.set(true)
                    try { a.setInterpolator(Spring()) } catch (_: Throwable) {} finally { own.set(false) }
                }
            })
        }
    }
}
