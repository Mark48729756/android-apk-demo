package dev.mark.miuxhook.ui

import android.app.Activity
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedScroll.nestedScroll
import androidx.compose.ui.unit.dp
import dev.mark.miuxhook.Diag
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import top.yukonga.miuix.kmp.basic.BasicComponent
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.Refresh
import top.yukonga.miuix.kmp.utils.overScrollVertical

@Composable
fun DiagPage(activity: Activity, outer: PaddingValues) {
    val scrollBehavior = MiuixScrollBehavior()
    var tick by remember { mutableIntStateOf(0) }
    // getprop и датчики — не на главном потоке
    val report by produceState<List<Pair<Boolean?, String>>>(emptyList(), tick) {
        value = withContext(Dispatchers.IO) { Diag.report(activity) }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = "Диагностика",
                scrollBehavior = scrollBehavior,
                actions = { IconButton(onClick = { tick++ }) { Icon(MiuixIcons.Refresh, contentDescription = "Обновить") } },
            )
        },
    ) { pv ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().overScrollVertical().nestedScroll(scrollBehavior.nestedScrollConnection),
            contentPadding = PaddingValues(top = pv.calculateTopPadding(), bottom = outer.calculateBottomPadding() + 12.dp),
        ) {
            item {
                SmallTitle(text = "Это устройство")
                Card(modifier = Modifier.padding(horizontal = 12.dp)) {
                    report.forEach { (ok, line) ->
                        BasicComponent(
                            title = line,
                            startAction = { Text(text = when (ok) { true -> "✅"; false -> "❌"; null -> "•" }, modifier = Modifier.padding(end = 4.dp)) },
                        )
                    }
                }
            }
        }
    }
}
