package dev.mark.miuxhook.ui

import android.content.SharedPreferences
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedScroll.nestedScroll
import androidx.compose.ui.unit.dp
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.preference.SliderPreference
import top.yukonga.miuix.kmp.preference.SwitchPreference
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.utils.overScrollVertical

/** Переключатель, который сразу пишет в общий файл настроек (его читают хуки). */
@Composable
private fun PrefSwitch(prefs: SharedPreferences, key: String, title: String, summary: String?, def: Boolean) {
    var on by remember { mutableStateOf(prefs.getBoolean(key, def)) }
    SwitchPreference(
        title = title,
        summary = summary,
        checked = on,
        onCheckedChange = { on = it; prefs.edit().putBoolean(key, it).apply() },
    )
}

@Composable
fun ModulePage(prefs: SharedPreferences, outer: PaddingValues) {
    val scrollBehavior = MiuixScrollBehavior()
    Scaffold(
        topBar = { TopAppBar(title = "MIUX Hook", scrollBehavior = scrollBehavior) },
    ) { pv ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().overScrollVertical().nestedScroll(scrollBehavior.nestedScrollConnection),
            contentPadding = PaddingValues(top = pv.calculateTopPadding(), bottom = outer.calculateBottomPadding() + 12.dp),
        ) {
            item {
                SmallTitle(text = "Стекло")
                Card(modifier = Modifier.padding(horizontal = 12.dp)) {
                    PrefSwitch(prefs, "glass_blur_windows", "Стекло для окон с блюром", "Диалоги, шторки, попапы", true)
                    PrefSwitch(prefs, "glass_all_dialogs", "Стекло для всех диалогов", null, false)
                }
            }
            item {
                SmallTitle(text = "Fluent-физика")
                Card(modifier = Modifier.padding(horizontal = 12.dp)) {
                    PrefSwitch(prefs, "fluent_press", "Пружинное нажатие кнопок", null, true)
                    PrefSwitch(prefs, "fluent_anim", "Пружинные анимации", "Интерполятор для View.animate()", true)
                }
            }
            item {
                SmallTitle(text = "SystemUI")
                Card(modifier = Modifier.padding(horizontal = 12.dp)) {
                    var boost by remember { mutableFloatStateOf(prefs.getFloat("blur_boost", 1.3f)) }
                    SliderPreference(
                        title = "Усиление блюра",
                        summary = "Множитель радиуса блюра шторки, локскрина и центра управления",
                        value = boost,
                        onValueChange = { boost = it },
                        valueText = "×" + "%.2f".format(boost),
                        valueRange = 1f..2f,
                        onValueChangeFinished = { prefs.edit().putFloat("blur_boost", boost).apply() },
                    )
                }
            }
            item {
                Text(
                    text = "Включи модуль в Vector, отметь SystemUI, Настройки, Рабочий стол и нужные приложения, затем перезапусти их.",
                    modifier = Modifier.padding(horizontal = 28.dp, vertical = 16.dp),
                    style = MiuixTheme.textStyles.footnote1,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                )
            }
        }
    }
}
