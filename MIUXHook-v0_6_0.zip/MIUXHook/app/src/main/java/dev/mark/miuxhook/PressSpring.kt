package dev.mark.miuxhook

import android.view.MotionEvent
import android.view.View
import dev.mark.miux.Spring
import java.lang.ref.WeakReference
import java.util.WeakHashMap

/**
 * Пружинное нажатие для чужих кнопок. Одна пружина на View: нажатие меняет цель, а не перезапускает
 * анимацию, поэтому быстрый тап не «прыгает», а отпускание получает толчок и пружинит с перелётом.
 */
object PressSpring {
    private const val PRESSED = 0.92f
    private val springs = WeakHashMap<View, Spring>()

    fun onTouch(v: View, e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (springs[v] == null && (v.scaleX != 1f || v.scaleY != 1f)) return   // уже анимируется кем-то другим
                spring(v).animateTo(PRESSED)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                springs[v]?.let { it.animateTo(1f, it.velocity + 1.1f) }               // толчок при отпускании
        }
    }

    private fun spring(v: View): Spring = springs.getOrPut(v) {
        val ref = WeakReference(v)                                                      // без утечки View через WeakHashMap
        Spring(1f, 520f, 22f, restDelta = 0.001f, restSpeed = 0.02f).apply {
            onUpdate = { s -> ref.get()?.let { it.scaleX = s; it.scaleY = s } }
        }
    }
}
