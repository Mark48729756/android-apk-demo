package dev.mark.miuxhook

import android.view.View
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers

/**
 * Хуки на реальные точки блюра SystemUI (разбор APK HyperOS):
 *  - BlurUtils.applyBlur(ViewRootImpl, int, boolean)  - блюр окна (шторка, локскрин, ЦУ)
 *  - MiBlurCompat.setMiBackgroundBlurRadiusCompat(int, View) - блюр отдельных View
 * ViewRootImpl скрытый класс, поэтому тип параметра передаётся строкой.
 */
object SystemUiHooks {
    private var logged = 0
    private fun log(what: String, r: Int) {
        if (logged < 40) { logged++; XposedBridge.log("MIUX sysui blur: $what r=$r") }
    }

    fun install(cl: ClassLoader, boost: Float) {
        try {
            XposedHelpers.findAndHookMethod(
                "com.android.systemui.statusbar.BlurUtils", cl, "applyBlur",
                "android.view.ViewRootImpl", Int::class.javaPrimitiveType, Boolean::class.javaPrimitiveType,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(p: XC_MethodHook.MethodHookParam) {
                        val r = p.args[1] as Int
                        if (r > 0) { log("applyBlur", r); p.args[1] = (r * boost).toInt() }
                    }
                })
            XposedBridge.log("MIUX sysui: BlurUtils.applyBlur hooked")
        } catch (t: Throwable) { XposedBridge.log("MIUX sysui applyBlur: $t") }

        try {
            XposedHelpers.findAndHookMethod(
                "com.miui.systemui.util.MiBlurCompat", cl, "setMiBackgroundBlurRadiusCompat",
                Int::class.javaPrimitiveType, View::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(p: XC_MethodHook.MethodHookParam) {
                        val r = p.args[0] as Int
                        if (r > 0) { log("MiBlurCompat.radius", r); p.args[0] = (r * boost).toInt() }
                    }
                })
            XposedBridge.log("MIUX sysui: MiBlurCompat hooked")
        } catch (t: Throwable) { XposedBridge.log("MIUX sysui MiBlurCompat: $t") }
    }
}
