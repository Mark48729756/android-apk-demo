package dev.mark.miuxhook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XSharedPreferences
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import dev.mark.miux.MiuxConfig

class HookEntry : IXposedHookLoadPackage {
    override fun handleLoadPackage(lp: XC_LoadPackage.LoadPackageParam) {
        if (lp.packageName == "dev.mark.miuxhook") {
            // Это лишь доказывает, что Vector подгрузил модуль в его же приложение.
            try {
                XposedHelpers.findAndHookMethod("dev.mark.miuxhook.Diag", lp.classLoader, "isHooked",
                    object : XC_MethodHook() {
                        override fun beforeHookedMethod(p: XC_MethodHook.MethodHookParam) { p.result = true }
                    })
            } catch (t: Throwable) { XposedBridge.log("MIUX self: $t") }
            return
        }
        if (Hooks.installed) return
        Hooks.installed = true
        XposedBridge.log("MIUX loaded in ${lp.packageName}")

        var glassWin = true; var glassAll = false; var press = true; var anim = true
        var boost = 1.3f
        try {
            val sp = XSharedPreferences("dev.mark.miuxhook", "config")
            try { sp.makeWorldReadable() } catch (_: Throwable) {}
            sp.reload()
            Hooks.prefs = sp
            MiuxConfig.loadFrom(sp)
            glassWin = sp.getBoolean("glass_blur_windows", true)
            glassAll = sp.getBoolean("glass_all_dialogs", false)
            press = sp.getBoolean("fluent_press", true)
            anim = sp.getBoolean("fluent_anim", true)
            boost = sp.getFloat("blur_boost", 1.3f)
        } catch (t: Throwable) { XposedBridge.log("MIUX prefs (дефолты): $t") }

        if (lp.packageName == "com.android.systemui") {
            try { SystemUiHooks.install(lp.classLoader, boost) } catch (t: Throwable) { XposedBridge.log("MIUX sysui: $t") }
        }
        try { GlassHooks.install(glassWin, glassAll) } catch (t: Throwable) { XposedBridge.log("MIUX glass: $t") }
        try { FluentHooks.install(press, anim) } catch (t: Throwable) { XposedBridge.log("MIUX fluent: $t") }
    }
}
