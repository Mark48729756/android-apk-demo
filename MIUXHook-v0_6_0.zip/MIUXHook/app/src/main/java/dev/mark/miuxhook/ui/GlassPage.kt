package dev.mark.miuxhook.ui

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedScroll.nestedScroll
import androidx.compose.ui.unit.dp
import dev.mark.miux.MiuxConfig
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.TextButton
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.preference.SliderPreference
import top.yukonga.miuix.kmp.utils.overScrollVertical

/** Параметр стекла: [get]/[set] работают в единицах экрана (проценты для долей). */
private class Param(
    val title: String,
    val min: Float,
    val max: Float,
    val get: () -> Float,
    val set: (Float) -> Unit,
    val fmt: (Float) -> String,
)

private val shape = listOf(
    Param("Преломление", 0f, 60f, { MiuxConfig.strength }, { MiuxConfig.strength = it }, { "%.0f dp".format(it) }),
    Param("Ширина линзы", 6f, 70f, { MiuxConfig.bevel }, { MiuxConfig.bevel = it }, { "%.0f dp".format(it) }),
    Param("Блюр", 0f, 16f, { MiuxConfig.blur }, { MiuxConfig.blur = it }, { "%.1f dp".format(it) }),
    Param("Показатель преломления", 1.1f, 2.2f, { MiuxConfig.ior }, { MiuxConfig.ior = it }, { "%.2f".format(it) }),
)
private val look = listOf(
    Param("Аберрация", 0f, 30f, { MiuxConfig.aberration * 100 }, { MiuxConfig.aberration = it / 100 }, { "%.0f%%".format(it) }),
    Param("Светлость", 0f, 30f, { MiuxConfig.tint * 100 }, { MiuxConfig.tint = it / 100 }, { "%.0f%%".format(it) }),
    Param("Насыщенность", 50f, 200f, { MiuxConfig.saturation * 100 }, { MiuxConfig.saturation = it / 100 }, { "%.0f%%".format(it) }),
    Param("Блики", 0f, 200f, { MiuxConfig.specular * 100 }, { MiuxConfig.specular = it / 100 }, { "%.0f%%".format(it) }),
    Param("Свет от гироскопа", 0f, 200f, { MiuxConfig.gyro * 100 }, { MiuxConfig.gyro = it / 100 }, { "%.0f%%".format(it) }),
)
private val spring = listOf(
    Param("Жёсткость пружины", 100f, 800f, { MiuxConfig.stiffness }, { MiuxConfig.stiffness = it }, { "%.0f".format(it) }),
    Param("Затухание пружины", 8f, 50f, { MiuxConfig.damping }, { MiuxConfig.damping = it }, { "%.0f".format(it) }),
)

@Composable
private fun ParamRow(p: Param) {
    var v by remember { mutableFloatStateOf(p.get().coerceIn(p.min, p.max)) }
    SliderPreference(
        title = p.title,
        value = v,
        onValueChange = { v = it; p.set(it) },          // живое значение для превью в этом процессе
        valueText = p.fmt(v),
        valueRange = p.min..p.max,
        onValueChangeFinished = { MiuxConfig.save() },  // в файл, откуда читают хуки
    )
}

@Composable
fun GlassPage(outer: PaddingValues) {
    val scrollBehavior = MiuixScrollBehavior()
    var epoch by remember { mutableIntStateOf(0) }     // после сброса пересоздаём слайдеры
    Scaffold(
        topBar = { TopAppBar(title = "Стекло", scrollBehavior = scrollBehavior) },
    ) { pv ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().overScrollVertical().nestedScroll(scrollBehavior.nestedScrollConnection),
            contentPadding = PaddingValues(top = pv.calculateTopPadding(), bottom = outer.calculateBottomPadding() + 12.dp),
        ) {
            item {
                SmallTitle(text = "Форма линзы")
                Card(modifier = Modifier.padding(horizontal = 12.dp)) { key(epoch) { shape.forEach { ParamRow(it) } } }
            }
            item {
                SmallTitle(text = "Вид стекла")
                Card(modifier = Modifier.padding(horizontal = 12.dp)) { key(epoch) { look.forEach { ParamRow(it) } } }
            }
            item {
                SmallTitle(text = "Пружина")
                Card(modifier = Modifier.padding(horizontal = 12.dp)) { key(epoch) { spring.forEach { ParamRow(it) } } }
            }
            item {
                TextButton(
                    text = "Сбросить",
                    onClick = { MiuxConfig.reset(); epoch++ },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 16.dp),
                )
            }
        }
    }
}
