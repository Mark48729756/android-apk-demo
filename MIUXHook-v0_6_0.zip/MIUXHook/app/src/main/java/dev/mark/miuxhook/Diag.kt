package dev.mark.miuxhook

import android.app.Activity
import android.graphics.RuntimeShader
import android.hardware.SensorManager
import android.os.Build
import dev.mark.miux.GLASS_AGSL

object Diag {
    /** Vector подменяет результат на true в процессе самого модуля. Это НЕ проверка работы хуков в SystemUI. */
    @JvmStatic fun isHooked(): Boolean = false

    private fun prop(k: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("getprop", k))
        p.inputStream.bufferedReader().readText().trim().also { p.destroy() }
    } catch (_: Throwable) { "" }

    fun rom(): String {
        val os = prop("ro.mi.os.version.name"); val code = prop("ro.mi.os.version.code")
        val miui = prop("ro.miui.ui.version.name")
        return when {
            os.isNotEmpty() -> "HyperOS $os" + if (code.isNotEmpty()) " ($code)" else ""
            miui.isNotEmpty() -> "MIUI $miui"
            else -> "${Build.MANUFACTURER} ${Build.DISPLAY}"
        }
    }

    fun report(a: Activity): List<Pair<Boolean?, String>> {
        val out = ArrayList<Pair<Boolean?, String>>()
        out += null to "Устройство: ${Build.MANUFACTURER} ${Build.MODEL}"
        out += true to "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), нужен 13+"
        out += null to "Прошивка: ${rom()}"
        out += isHooked() to "Модуль загружен Vector в своё приложение"
        out += null to "Хуки в SystemUI/Настройках: Vector -> Логи -> искать «MIUX»"
        out += (try { RuntimeShader(GLASS_AGSL); true } catch (_: Throwable) { false }) to "Шейдер стекла (AGSL) компилируется"
        val sm = a.getSystemService(Activity.SENSOR_SERVICE) as SensorManager
        out += (sm.getDefaultSensor(9) != null || sm.getDefaultSensor(1) != null) to "Датчик наклона для света"
        out += (try { a.windowManager.isCrossWindowBlurEnabled } catch (_: Throwable) { false }) to
            "Системный блюр окон включён (экономия энергии может его выключать)"
        out += null to "persist.sys.background_blur_supported = ${prop("persist.sys.background_blur_supported")}"
        out += null to "persist.sys.bionic_material_supported = ${prop("persist.sys.bionic_material_supported")}"
        return out
    }
}
