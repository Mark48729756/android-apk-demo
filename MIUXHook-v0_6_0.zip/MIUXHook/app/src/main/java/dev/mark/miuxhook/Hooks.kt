package dev.mark.miuxhook

import de.robv.android.xposed.XSharedPreferences

object Hooks {
    @Volatile var installed = false
    @Volatile var prefs: XSharedPreferences? = null
}
