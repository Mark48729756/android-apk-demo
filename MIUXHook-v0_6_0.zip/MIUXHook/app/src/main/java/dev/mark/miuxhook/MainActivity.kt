package dev.mark.miuxhook

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import dev.mark.miux.MiuxConfig
import dev.mark.miuxhook.ui.MiuxHookApp

/** Интерфейс модуля целиком на Miuix (Compose, стиль Xiaomi HyperOS). */
class MainActivity : ComponentActivity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Файл читают хуки из других процессов (XSharedPreferences), поэтому пробуем world-readable.
        val prefs: SharedPreferences = try { getSharedPreferences("config", MODE_WORLD_READABLE) }
            catch (_: SecurityException) { getSharedPreferences("config", MODE_PRIVATE) }
        MiuxConfig.init(this, prefs)
        setContent { MiuxHookApp(activity = this, prefs = prefs) }
    }
}
