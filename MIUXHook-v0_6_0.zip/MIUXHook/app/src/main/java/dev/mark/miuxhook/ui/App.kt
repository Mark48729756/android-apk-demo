package dev.mark.miuxhook.ui

import android.app.Activity
import android.content.SharedPreferences
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import top.yukonga.miuix.kmp.basic.NavigationBar
import top.yukonga.miuix.kmp.basic.NavigationBarItem
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.extended.Info
import top.yukonga.miuix.kmp.icon.extended.Settings
import top.yukonga.miuix.kmp.icon.extended.Tune
import top.yukonga.miuix.kmp.theme.ColorSchemeMode
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.theme.ThemeController

@Composable
fun MiuxHookApp(activity: Activity, prefs: SharedPreferences) {
    // System = светлая/тёмная тема Miuix по настройке телефона (фирменный синий акцент HyperOS)
    val controller = remember { ThemeController(ColorSchemeMode.System) }
    MiuixTheme(controller = controller) {
        var tab by rememberSaveable { mutableStateOf(0) }
        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = MiuixIcons.Settings, label = "Модуль")
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = MiuixIcons.Tune, label = "Стекло")
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = MiuixIcons.Info, label = "Диагностика")
                }
            },
        ) { outer ->
            // нижний отступ под панель навигации передаём страницам, верхний каждая страница ставит сама (TopAppBar)
            val bottom = PaddingValues(bottom = outer.calculateBottomPadding())
            Box(Modifier.fillMaxSize()) {
                when (tab) {
                    0 -> ModulePage(prefs, bottom)
                    1 -> GlassPage(bottom)
                    else -> DiagPage(activity, bottom)
                }
            }
        }
    }
}
