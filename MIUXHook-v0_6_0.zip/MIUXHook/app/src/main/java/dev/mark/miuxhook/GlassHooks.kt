package dev.mark.miuxhook

import android.app.Activity
import android.app.Dialog
import android.view.View
import android.view.Window
import android.view.WindowManager
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import dev.mark.miux.GlassDrawable
import dev.mark.miux.MiuxConfig
import java.lang.ref.WeakReference
import java.util.Collections
import java.util.WeakHashMap

/**
 * Стекло для окон приложения. Окна, которые просят системный блюр (Window.setBackgroundBlurRadius),
 * получают настоящее жидкое стекло, преломляющее окно самой активити под ними.
 * Ограничение: источник картинки есть только внутри ОДНОГО процесса.
 */
object GlassHooks {
    private val glassed: MutableSet<Window> = Collections.newSetFromMap(WeakHashMap())

    @Volatile private var resumed = WeakReference<View?>(null)

    fun install(blurWindows: Boolean, allDialogs: Boolean) {
        // публичный путь: запоминаем окно активити, которая сейчас на экране (работает на любой версии Android)
        try {
            XposedHelpers.findAndHookMethod(Activity::class.java, "onResume", object : XC_MethodHook() {
                override fun afterHookedMethod(p: XC_MethodHook.MethodHookParam) {
                    resumed = WeakReference((p.thisObject as Activity).window?.decorView)
                }
            })
        } catch (t: Throwable) { XposedBridge.log("MIUX onResume hook: $t") }
        if (blurWindows) {
            XposedHelpers.findAndHookMethod(Window::class.java, "setBackgroundBlurRadius", Int::class.javaPrimitiveType,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(p: XC_MethodHook.MethodHookParam) {
                        if (glassed.contains(p.thisObject as Window)) p.args[0] = 0   // системный блюр больше не нужен
                    }
                    override fun afterHookedMethod(p: XC_MethodHook.MethodHookParam) {
                        if ((p.args[0] as Int) > 0) apply(p.thisObject as Window)
                    }
                })
        }
        if (allDialogs) {
            XposedHelpers.findAndHookMethod(Dialog::class.java, "show", object : XC_MethodHook() {
                override fun afterHookedMethod(p: XC_MethodHook.MethodHookParam) { apply((p.thisObject as Dialog).window) }
            })
        }
    }

    private fun apply(w: Window?) {
        try {
            w ?: return
            val decor = w.decorView
            if (decor.background is GlassDrawable) return
            if (findBackdrop(decor) == null) return        // под окном нечего преломлять
            Hooks.prefs?.let { it.reload(); MiuxConfig.loadFrom(it) }
            var cache = WeakReference<View?>(null)
            decor.background = GlassDrawable({
                var s = cache.get()
                if (s == null || !s.isAttachedToWindow) { s = findBackdrop(decor); cache = WeakReference(s) }
                s
            }, 28f)
            glassed.add(w)
            w.setBackgroundBlurRadius(0)
        } catch (t: Throwable) { XposedBridge.log("MIUX apply: $t") }
    }

    /** Окно активити под стеклом: сначала публичный путь (onResume), затем запасной — список окон процесса. */
    private fun findBackdrop(self: View): View? {
        resumed.get()?.let { if (it !== self && it.isAttachedToWindow && it.width > 0 && it.height > 0) return it }
        return try {
            val wmg = Class.forName("android.view.WindowManagerGlobal").getMethod("getInstance").invoke(null)
            val f = wmg!!.javaClass.getDeclaredField("mViews"); f.isAccessible = true
            @Suppress("UNCHECKED_CAST") val list = ArrayList(f.get(wmg) as List<View>)
            list.firstOrNull {
                it !== self && it.isAttachedToWindow && it.width > 0 && it.height > 0 &&
                    (it.layoutParams as? WindowManager.LayoutParams)?.type == WindowManager.LayoutParams.TYPE_BASE_APPLICATION
            }
        } catch (t: Throwable) { null }
    }
}
