# Точка входа Xposed и метод, который HookEntry подменяет по имени строкой
-keep class dev.mark.miuxhook.HookEntry { *; }
-keep class dev.mark.miuxhook.Diag { *; }
-keep class dev.mark.miuxhook.Hooks { *; }
# Движок стекла вызывается из чужих процессов
-keep class dev.mark.miux.** { *; }
-dontwarn de.robv.android.xposed.**
