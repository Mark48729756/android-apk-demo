package dev.mark.miux

import android.view.Choreographer
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.abs

/**
 * Физическая пружина:  m·x'' = -k·(x - target) - c·x'.
 * Решается АНАЛИТИЧЕСКИ (недо-/критическое/пере-демпфирование), поэтому устойчива при любом dt
 * и сохраняет скорость при смене цели — как в SwiftUI/UIKit-пружинах.
 * Если stiffness/damping не заданы (<= 0) — берутся из [MiuxConfig] и меняются на лету.
 * Вызывать только с главного потока.
 */
class Spring(
    var value: Float = 0f,
    var stiffness: Float = -1f,
    var damping: Float = -1f,
    var mass: Float = 1f,
    var restDelta: Float = 0.002f,
    var restSpeed: Float = 0.05f
) {
    var target = value; private set
    var velocity = 0f
    var onUpdate: ((Float) -> Unit)? = null
    var onEnd: (() -> Unit)? = null
    var isRunning = false; internal set

    fun animateTo(t: Float, v0: Float = velocity) { target = t; velocity = v0; start() }
    fun kick(dv: Float) { velocity += dv; start() }
    fun snapTo(v: Float) {
        value = v; target = v; velocity = 0f
        if (isRunning) { isRunning = false; SpringClock.remove(this) }
        onUpdate?.invoke(v)
    }
    fun cancel() { if (isRunning) { isRunning = false; SpringClock.remove(this) } }
    private fun start() { if (!isRunning) { isRunning = true; SpringClock.add(this) } }

    /** Один шаг; true — пружина ещё движется. */
    internal fun advance(dt: Float): Boolean {
        if (!isRunning) return false
        step(dt)
        if (abs(value - target) < restDelta && abs(velocity) < restSpeed) {
            value = target; velocity = 0f; isRunning = false
            onUpdate?.invoke(value); onEnd?.invoke()
            return false
        }
        onUpdate?.invoke(value)
        return true
    }

    private fun step(dtF: Float) {
        val k = (if (stiffness > 0f) stiffness else MiuxConfig.stiffness).toDouble()
        val c = (if (damping > 0f) damping else MiuxConfig.damping).toDouble()
        val m = mass.toDouble()
        val dt = dtF.toDouble()
        val w0 = sqrt(k / m)
        val z = c / (2.0 * sqrt(k * m))
        val x0 = (value - target).toDouble()
        val v0 = velocity.toDouble()
        val x: Double; val v: Double
        when {
            z < 0.999 -> {                                   // колебательный режим (с отскоком)
                val a = z * w0; val wd = w0 * sqrt(1.0 - z * z)
                val e = exp(-a * dt); val cs = cos(wd * dt); val sn = sin(wd * dt)
                val b = (v0 + a * x0) / wd
                x = e * (x0 * cs + b * sn)
                v = e * ((b * wd - a * x0) * cs - (a * b + x0 * wd) * sn)
            }
            z <= 1.001 -> {                                  // критическое
                val e = exp(-w0 * dt); val b = v0 + w0 * x0
                x = e * (x0 + b * dt)
                v = e * (v0 - w0 * b * dt)
            }
            else -> {                                        // сверхдемпфированное
                val s = sqrt(z * z - 1.0)
                val r1 = -w0 * (z - s); val r2 = -w0 * (z + s)
                val c2 = (v0 - r1 * x0) / (r2 - r1); val c1 = x0 - c2
                val e1 = exp(r1 * dt); val e2 = exp(r2 * dt)
                x = c1 * e1 + c2 * e2
                v = c1 * r1 * e1 + c2 * r2 * e2
            }
        }
        value = (target + x).toFloat(); velocity = v.toFloat()
    }
}

/** Единые часы для всех пружин: один Choreographer-колбэк на кадр, засыпает, когда всё успокоилось. */
object SpringClock : Choreographer.FrameCallback {
    private val active = ArrayList<Spring>()
    private var last = 0L
    private var posted = false

    fun add(s: Spring) {
        active.add(s)
        if (!posted) { posted = true; last = 0L; Choreographer.getInstance().postFrameCallback(this) }
    }
    fun remove(s: Spring) { active.remove(s) }

    override fun doFrame(frameTimeNanos: Long) {
        posted = false
        val dt = if (last == 0L) 1f / 60f else ((frameTimeNanos - last) / 1e9f).coerceIn(0.001f, 0.05f)
        last = frameTimeNanos
        for (s in active.toTypedArray()) if (!s.advance(dt)) active.remove(s)
        if (active.isNotEmpty()) { posted = true; Choreographer.getInstance().postFrameCallback(this) } else last = 0L
    }
}
