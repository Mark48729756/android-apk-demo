package dev.mark.miux

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import java.lang.ref.WeakReference
import kotlin.math.exp
import kotlin.math.sqrt

/** Тот, кто рисует стекло и хочет перерисоваться при смене света. Мёртвые подписчики вычищаются сами. */
interface LightSink {
    val alive: Boolean
    val rotation: Int get() = 0          // Surface.ROTATION_*
    fun onLightChanged()
}

/**
 * Свет от гироскопа. Источник света «висит» в мире, поэтому при наклоне телефона блик на гранях
 * стекла смещается. Берётся вектор гравитации (TYPE_GRAVITY, иначе акселерометр); отсчёт — от
 * медленно «плывущей» нейтральной позы, чтобы свет не зависел от того, как вы обычно держите телефон.
 * Сам свет движется через пружины → блик лениво догоняет наклон, как жидкость.
 * Датчик включается только пока есть живые подписчики.
 */
object GyroLight : SensorEventListener {
    const val DEF_X = -0.55f; const val DEF_Y = -0.70f; const val DEF_Z = 0.45f   // сверху-слева, под малым углом
    private const val GAIN = 1.7f

    /** Текущий свет в экранных осях: x вправо, y ВНИЗ, z к зрителю. Не нормализован. */
    val light = floatArrayOf(DEF_X, DEF_Y, DEF_Z)

    private val sinks = ArrayList<WeakReference<LightSink>>()
    private var sm: SensorManager? = null
    private var registered = false
    private var bx = 0f; private var by = 0f; private var hasBase = false; private var lastTs = 0L
    private val sx = Spring(DEF_X, 140f, 15f, restDelta = 0.001f, restSpeed = 0.01f)
    private val sy = Spring(DEF_Y, 140f, 15f, restDelta = 0.001f, restSpeed = 0.01f)

    init {
        sx.onUpdate = { light[0] = it; fire() }
        sy.onUpdate = { light[1] = it; fire() }
    }

    fun attach(ctx: Context, sink: LightSink) {
        if (sinks.none { it.get() === sink }) sinks.add(WeakReference(sink))
        if (!registered) start(ctx)
    }

    private fun start(ctx: Context) {
        try {
            val m = (ctx.applicationContext ?: ctx).getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return
            val s = m.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
            hasBase = false
            registered = m.registerListener(this, s, SensorManager.SENSOR_DELAY_UI, Handler(Looper.getMainLooper()))
            sm = m
        } catch (_: Throwable) { /* без датчика остаётся статичный свет */ }
    }

    private fun stop() {
        if (registered) { sm?.unregisterListener(this); registered = false }
    }

    private fun fire() {
        val it = sinks.iterator()
        while (it.hasNext()) {
            val s = it.next().get()
            if (s == null || !s.alive) it.remove() else s.onLightChanged()
        }
        if (sinks.isEmpty()) stop()
    }

    override fun onSensorChanged(e: SensorEvent) {
        val g = MiuxConfig.gyro
        if (g <= 0f) { sx.animateTo(DEF_X); sy.animateTo(DEF_Y); return }
        val n = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        if (n < 1e-3f) return
        val ux = e.values[0] / n; val uy = e.values[1] / n          // «мировой верх» в осях устройства
        val rot = sinks.firstNotNullOfOrNull { it.get()?.takeIf { s -> s.alive } }?.rotation ?: 0
        val (px, py) = when (rot) {                                 // в оси экрана (y вверх)
            1 -> -uy to ux
            2 -> -ux to -uy
            3 -> uy to -ux
            else -> ux to uy
        }
        val dt = if (lastTs == 0L) 0.06f else ((e.timestamp - lastTs) / 1e9f).coerceIn(0f, 0.25f)
        lastTs = e.timestamp
        if (!hasBase) { bx = px; by = py; hasBase = true }
        else { val a = 1f - exp(-dt / 4f); bx += (px - bx) * a; by += (py - by) * a }
        sx.animateTo((DEF_X + GAIN * g * (px - bx)).coerceIn(-1.3f, 1.3f))
        sy.animateTo((DEF_Y - GAIN * g * (py - by)).coerceIn(-1.3f, 1.3f))
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
