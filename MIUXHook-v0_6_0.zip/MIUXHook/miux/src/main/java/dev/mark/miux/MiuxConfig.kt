package dev.mark.miux

import android.content.Context
import android.content.SharedPreferences

/** Глобальные настройки стекла. В модуле читаются из XSharedPreferences, в приложении пишутся в общий файл. */
object MiuxConfig {
    var strength = 22f      // толщина стекла, dp (сила преломления)
    var bevel = 28f         // ширина выпуклой фаски, dp
    var blur = 3f
    var aberration = 0.08f; var tint = 0.07f
    var stiffness = 380f; var damping = 24f
    var ior = 1.5f          // показатель преломления
    var saturation = 1.15f  // насыщенность преломлённой картинки
    var specular = 1.0f     // яркость бликов
    var gyro = 1.0f         // насколько свет следует за наклоном (0 = статичный)
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context, shared: SharedPreferences? = null) {
        prefs = shared ?: ctx.applicationContext.getSharedPreferences("miux", Context.MODE_PRIVATE)
        loadFrom(prefs!!)
    }
    fun loadFrom(it: SharedPreferences) {
        strength = it.getFloat("strength", strength); bevel = it.getFloat("bevel", bevel)
        blur = it.getFloat("blur", blur); aberration = it.getFloat("aberration", aberration)
        tint = it.getFloat("tint", tint); stiffness = it.getFloat("stiffness", stiffness)
        damping = it.getFloat("damping", damping); ior = it.getFloat("ior", ior)
        saturation = it.getFloat("saturation", saturation); specular = it.getFloat("specular", specular)
        gyro = it.getFloat("gyro", gyro)
    }
    fun save() {
        prefs?.edit()?.putFloat("strength", strength)?.putFloat("bevel", bevel)?.putFloat("blur", blur)
            ?.putFloat("aberration", aberration)?.putFloat("tint", tint)
            ?.putFloat("stiffness", stiffness)?.putFloat("damping", damping)
            ?.putFloat("ior", ior)?.putFloat("saturation", saturation)
            ?.putFloat("specular", specular)?.putFloat("gyro", gyro)?.apply()
    }
    fun reset() {
        strength = 22f; bevel = 28f; blur = 3f; aberration = 0.08f; tint = 0.07f; stiffness = 380f; damping = 24f
        ior = 1.5f; saturation = 1.15f; specular = 1f; gyro = 1f
        save()
    }
}
