package dev.mark.miux

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.PixelFormat
import android.graphics.RenderNode
import android.graphics.RuntimeShader
import android.graphics.drawable.Drawable
import android.view.View
import kotlin.math.min

/**
 * Стеклянный Drawable: ставится фоном на ЛЮБОЙ View (в том числе чужой, из хука).
 * [sourceProvider] отдаёт View, чью картинку преломляем (например, окно активити под диалогом).
 * Свет берёт из [GyroLight] и сам перерисовывается при наклоне телефона.
 */
class GlassDrawable(private val sourceProvider: () -> View?, var cornerDp: Float = 28f) : Drawable(), LightSink {
    private val shader = RuntimeShader(GLASS_AGSL)
    private val node = RenderNode("miux-glass")

    override val alive: Boolean get() = (callback as? View)?.isAttachedToWindow == true
    override val rotation: Int get() = (callback as? View)?.display?.rotation ?: 0
    override fun onLightChanged() { invalidateSelf() }

    override fun draw(canvas: Canvas) {
        try { drawGlass(canvas) } catch (t: Throwable) { /* стекло не должно ронять чужое приложение */ }
    }

    private fun drawGlass(canvas: Canvas) {
        val v = callback as? View ?: return
        val src = sourceProvider() ?: return
        if (!canvas.isHardwareAccelerated) return
        val b = bounds; val w = b.width(); val h = b.height()
        if (w <= 0 || h <= 0) return
        GyroLight.attach(v.context, this)
        val den = v.resources.displayMetrics.density
        val loc = IntArray(2); val sl = IntArray(2)
        v.getLocationOnScreen(loc); src.getLocationOnScreen(sl)
        val ox = (loc[0] + b.left - sl[0]).toFloat(); val oy = (loc[1] + b.top - sl[1]).toFloat()
        node.setPosition(0, 0, w, h)
        val rec = node.beginRecording(w, h)
        rec.translate(-ox, -oy)
        src.draw(rec)
        node.endRecording()

        GlassPainter.apply(shader, w, h, min(cornerDp * den, min(w, h) / 2f), den, 0f)
        node.setRenderEffect(GlassPainter.effect(shader, den))
        canvas.save(); canvas.translate(b.left.toFloat(), b.top.toFloat())
        canvas.drawRenderNode(node)
        canvas.restore()
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java") override fun getOpacity() = PixelFormat.TRANSLUCENT
}
