plugins { id("com.android.library") }
android {
    namespace = "dev.mark.miux"
    compileSdk = 37
    defaultConfig { minSdk = 33 }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
