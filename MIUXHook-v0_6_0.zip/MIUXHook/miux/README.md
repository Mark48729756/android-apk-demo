# miux — движок Liquid Glass для хуков

Только ядро, без UI-виджетов (интерфейс приложения теперь на Miuix):
`Glass.kt` (AGSL-шейдер), `GlassDrawable.kt` (стекло как Drawable для чужих окон),
`Spring.kt` (пружины + часы), `GyroLight.kt` (свет от наклона), `MiuxConfig.kt` (настройки).
minSdk 33.
