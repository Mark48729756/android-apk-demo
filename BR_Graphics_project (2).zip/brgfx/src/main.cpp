// BR Graphics - Zygisk post-process filter for GTA:SA based mobile clients.
// Hooks eglSwapBuffers in the game's process (in memory only, no game files touched)
// and runs the finished frame through a fragment shader.
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <dlfcn.h>
#include <link.h>
#include <elf.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#include <algorithm>
#include "zygisk.hpp"

#define TAG "BRGFX"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static const char *CONFIG_PATH = "/data/adb/br_graphics/config.ini";

// ---------------------------------------------------------------- io helpers
static bool readAll(int fd, void *buf, size_t n) {
    char *p = (char *)buf;
    while (n) { ssize_t r = read(fd, p, n); if (r <= 0) return false; p += r; n -= r; }
    return true;
}
static bool writeAll(int fd, const void *buf, size_t n) {
    const char *p = (const char *)buf;
    while (n) { ssize_t r = write(fd, p, n); if (r <= 0) return false; p += r; n -= r; }
    return true;
}
static std::string readFile(const char *path) {
    std::string out;
    FILE *f = fopen(path, "r");
    if (!f) return out;
    char b[1024]; size_t n;
    while ((n = fread(b, 1, sizeof b, f)) > 0) out.append(b, n);
    fclose(f);
    return out;
}
static std::map<std::string, std::string> parseCfg(const std::string &txt, std::vector<std::string> *pkgs) {
    std::map<std::string, std::string> m;
    size_t i = 0;
    while (i < txt.size()) {
        size_t e = txt.find('\n', i);
        if (e == std::string::npos) e = txt.size();
        std::string line = txt.substr(i, e - i);
        i = e + 1;
        while (!line.empty() && (line.back() == '\r' || line.back() == ' ')) line.pop_back();
        if (line.empty() || line[0] == '#') continue;
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string k = line.substr(0, eq), v = line.substr(eq + 1);
        if (k == "package") { if (pkgs) pkgs->push_back(v); }
        else m[k] = v;
    }
    return m;
}

// ---------------------------------------------------------------- companion (root)
static void companion(int fd) {
    uint32_t len = 0;
    if (!readAll(fd, &len, 4) || len > 512) return;
    std::string name(len, 0);
    if (len && !readAll(fd, &name[0], len)) return;
    std::string cfg = readFile(CONFIG_PATH);
    std::vector<std::string> pkgs;
    auto kv = parseCfg(cfg, &pkgs);
    uint8_t match = 0;
    if (kv["enabled"] != "0")
        for (auto &p : pkgs) if (!p.empty() && name.find(p) != std::string::npos) match = 1;
    writeAll(fd, &match, 1);
    if (match) {
        uint32_t cl = cfg.size();
        writeAll(fd, &cl, 4);
        writeAll(fd, cfg.data(), cl);
    }
}

// ---------------------------------------------------------------- settings
struct Settings {
    float sharp = 0.35f, bloom = 0.25f, contrast = 1.08f, saturation = 1.12f, vignette = 0.28f,
          grain = 0.02f, motionblur = 0.22f, exposure = 1.0f, warmth = 0.03f;
} S;

static bool g_dump = true;
static bool g_post = false;
static bool g_patch = true;
static std::string g_require = "fog";
static float g_shContrast = 1.10f, g_shSat = 1.15f, g_shShadow = 0.35f, g_shGlow = 0.35f, g_shWarm = 0.03f;
static std::string g_pkg;

static float getf(std::map<std::string, std::string> &m, const char *k, float d) {
    auto it = m.find(k);
    return it == m.end() ? d : (float)atof(it->second.c_str());
}

// ---------------------------------------------------------------- GL post process
static const char *VS =
    "attribute vec2 aPos; varying vec2 vUV;\n"
    "void main(){ vUV = aPos*0.5+0.5; gl_Position = vec4(aPos,0.0,1.0); }\n";

static const char *FS =
    "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
    "varying vec2 vUV;\n"
    "uniform sampler2D uCur; uniform sampler2D uPrev;\n"
    "uniform vec2 uTexel; uniform float uTime;\n"
    "uniform float uSharp,uBloom,uContrast,uSat,uVig,uGrain,uMB,uExp,uWarm;\n"
    "vec3 T(vec2 p){ return texture2D(uCur,p).rgb; }\n"
    "float hash(vec2 p){ return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453); }\n"
    "void main(){\n"
    "  vec2 uv = vUV;\n"
    "  vec3 c = T(uv);\n"
    "  vec3 n=T(uv+vec2(0.0,uTexel.y)), s=T(uv-vec2(0.0,uTexel.y));\n"
    "  vec3 e=T(uv+vec2(uTexel.x,0.0)), w=T(uv-vec2(uTexel.x,0.0));\n"
    "  vec3 avg=(n+s+e+w)*0.25;\n"
    "  vec3 mn=min(c,min(min(n,s),min(e,w))), mx=max(c,max(max(n,s),max(e,w)));\n"
    "  c = clamp(c + (c-avg)*uSharp*2.0, mn-0.05, mx+0.05);\n"
    "  vec3 b = vec3(0.0);\n"
    "  vec2 r1 = uTexel*4.0, r2 = uTexel*9.0;\n"
    "  b += max(T(uv+vec2( r1.x,0.0))-0.65,0.0)+max(T(uv+vec2(-r1.x,0.0))-0.65,0.0);\n"
    "  b += max(T(uv+vec2(0.0, r1.y))-0.65,0.0)+max(T(uv+vec2(0.0,-r1.y))-0.65,0.0);\n"
    "  b += max(T(uv+r1)-0.65,0.0)+max(T(uv-r1)-0.65,0.0)+max(T(uv+vec2(r1.x,-r1.y))-0.65,0.0)+max(T(uv+vec2(-r1.x,r1.y))-0.65,0.0);\n"
    "  b += max(T(uv+vec2( r2.x,0.0))-0.65,0.0)+max(T(uv+vec2(-r2.x,0.0))-0.65,0.0);\n"
    "  b += max(T(uv+vec2(0.0, r2.y))-0.65,0.0)+max(T(uv+vec2(0.0,-r2.y))-0.65,0.0);\n"
    "  c += b*(uBloom/12.0)*2.0;\n"
    "  c = mix(c, texture2D(uPrev,uv).rgb, uMB);\n"
    "  c *= uExp;\n"
    "  c.r *= 1.0+uWarm; c.b *= 1.0-uWarm;\n"
    "  c = (c-0.5)*uContrast+0.5;\n"
    "  float l = dot(c, vec3(0.299,0.587,0.114));\n"
    "  c = mix(vec3(l), c, uSat);\n"
    "  c = clamp(c,0.0,1.0);\n"
    "  c = mix(c, c*c*(3.0-2.0*c), 0.25);\n"
    "  float d = length((uv-0.5)*vec2(1.0,0.8));\n"
    "  c *= 1.0 - uVig*smoothstep(0.30,0.85,d);\n"
    "  c += (hash(uv/uTexel*0.37+uTime)-0.5)*uGrain;\n"
    "  gl_FragColor = vec4(clamp(c,0.0,1.0),1.0);\n"
    "}\n";

struct FX {
    EGLContext ctx = EGL_NO_CONTEXT;
    GLuint prog = 0, texCur = 0, texPrev = 0;
    GLint W = 0, H = 0;
    GLint uCur = 0, uPrev = 0, uTexel = 0, uTime = 0, uSharp = 0, uBloom = 0, uContrast = 0,
          uSat = 0, uVig = 0, uGrain = 0, uMB = 0, uExp = 0, uWarm = 0;
    bool failed = false;
};
static FX fx;

static GLuint compile(GLenum type, const char *src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char log[512]; glGetShaderInfoLog(s, 512, nullptr, log); LOGE("shader: %s", log); glDeleteShader(s); return 0; }
    return s;
}
static bool initFX() {
    GLuint vs = compile(GL_VERTEX_SHADER, VS), fs = compile(GL_FRAGMENT_SHADER, FS);
    if (!vs || !fs) return false;
    fx.prog = glCreateProgram();
    glAttachShader(fx.prog, vs); glAttachShader(fx.prog, fs);
    glBindAttribLocation(fx.prog, 0, "aPos");
    glLinkProgram(fx.prog);
    GLint ok = 0; glGetProgramiv(fx.prog, GL_LINK_STATUS, &ok);
    if (!ok) { LOGE("link failed"); return false; }
#define U(n, s) fx.n = glGetUniformLocation(fx.prog, s)
    U(uCur,"uCur"); U(uPrev,"uPrev"); U(uTexel,"uTexel"); U(uTime,"uTime"); U(uSharp,"uSharp");
    U(uBloom,"uBloom"); U(uContrast,"uContrast"); U(uSat,"uSat"); U(uVig,"uVig"); U(uGrain,"uGrain");
    U(uMB,"uMB"); U(uExp,"uExp"); U(uWarm,"uWarm");
#undef U
    glGenTextures(1, &fx.texCur); glGenTextures(1, &fx.texPrev);
    fx.W = fx.H = 0;
    return true;
}
static void setupTex(GLuint t, int unit, int w, int h) {
    glActiveTexture(GL_TEXTURE0 + unit);
    glBindTexture(GL_TEXTURE_2D, t);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glCopyTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 0, 0, w, h, 0);
}

static void drawFX(EGLDisplay, int w, int h) {
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (w != fx.W || h != fx.H) {
        setupTex(fx.texCur, 0, w, h);
        setupTex(fx.texPrev, 1, w, h);
        fx.W = w; fx.H = h;
    }
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, fx.texCur);
    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, w, h);

    glDisable(GL_BLEND); glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glDisable(GL_SCISSOR_TEST); glDisable(GL_STENCIL_TEST); glDisable(GL_DITHER);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    glViewport(0, 0, w, h);
    glUseProgram(fx.prog);
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, fx.texPrev);
    glUniform1i(fx.uCur, 0); glUniform1i(fx.uPrev, 1);
    glUniform2f(fx.uTexel, 1.0f / w, 1.0f / h);
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    glUniform1f(fx.uTime, (float)(ts.tv_nsec % 1000000) / 1000000.0f);
    glUniform1f(fx.uSharp, S.sharp); glUniform1f(fx.uBloom, S.bloom);
    glUniform1f(fx.uContrast, S.contrast); glUniform1f(fx.uSat, S.saturation);
    glUniform1f(fx.uVig, S.vignette); glUniform1f(fx.uGrain, S.grain);
    glUniform1f(fx.uMB, S.motionblur); glUniform1f(fx.uExp, S.exposure);
    glUniform1f(fx.uWarm, S.warmth);
    static const GLfloat quad[] = {-1, -1, 1, -1, -1, 1, 1, 1};
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, quad);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    // keep the output as "previous frame" for motion blur
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, fx.texPrev);
    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, w, h);
}

static void renderFX(EGLDisplay dpy, EGLSurface surf) {
    if (fx.failed) return;
    EGLContext cur = eglGetCurrentContext();
    if (cur == EGL_NO_CONTEXT) return;
    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH, &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    if (w < 64 || h < 64) return;

    // ---- save state
    GLint prog, arrBuf, elemBuf, fbo, actTex, tex0, tex1, vp[4], attr0;
    GLboolean cm[4];
    GLboolean blend = glIsEnabled(GL_BLEND), depth = glIsEnabled(GL_DEPTH_TEST),
              cull = glIsEnabled(GL_CULL_FACE), scis = glIsEnabled(GL_SCISSOR_TEST),
              sten = glIsEnabled(GL_STENCIL_TEST), dith = glIsEnabled(GL_DITHER);
    glGetIntegerv(GL_CURRENT_PROGRAM, &prog);
    glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &arrBuf);
    glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &elemBuf);
    glGetIntegerv(GL_FRAMEBUFFER_BINDING, &fbo);
    glGetIntegerv(GL_ACTIVE_TEXTURE, &actTex);
    glGetIntegerv(GL_VIEWPORT, vp);
    glGetBooleanv(GL_COLOR_WRITEMASK, cm);
    glGetVertexAttribiv(0, GL_VERTEX_ATTRIB_ARRAY_ENABLED, &attr0);
    glActiveTexture(GL_TEXTURE0); glGetIntegerv(GL_TEXTURE_BINDING_2D, &tex0);
    glActiveTexture(GL_TEXTURE1); glGetIntegerv(GL_TEXTURE_BINDING_2D, &tex1);

    bool ready = true;
    if (cur != fx.ctx) {
        fx = FX();
        fx.ctx = cur;
        if (!initFX()) { fx.failed = true; ready = false; LOGE("init failed, filter disabled"); }
        else LOGI("filter initialised %dx%d", w, h);
    }
    if (ready) drawFX(dpy, w, h);

    // ---- restore state
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, tex1);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, tex0);
    glActiveTexture(actTex);
    if (!attr0) glDisableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, arrBuf);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, elemBuf);
    glUseProgram(prog);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glViewport(vp[0], vp[1], vp[2], vp[3]);
    glColorMask(cm[0], cm[1], cm[2], cm[3]);
    if (blend) glEnable(GL_BLEND); else glDisable(GL_BLEND);
    if (depth) glEnable(GL_DEPTH_TEST); else glDisable(GL_DEPTH_TEST);
    if (cull) glEnable(GL_CULL_FACE); else glDisable(GL_CULL_FACE);
    if (scis) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST);
    if (sten) glEnable(GL_STENCIL_TEST); else glDisable(GL_STENCIL_TEST);
    if (dith) glEnable(GL_DITHER); else glDisable(GL_DITHER);
}

// ---------------------------------------------------------------- GOT hook of eglSwapBuffers
typedef EGLBoolean (*SwapFn)(EGLDisplay, EGLSurface);
static SwapFn origSwap = nullptr;
static EGLBoolean mySwap(EGLDisplay d, EGLSurface s) {
    renderFX(d, s);
    return origSwap(d, s);
}


// ---------------------------------------------------------------- game shader dump / override
typedef void (*SrcFn)(GLuint, GLsizei, const GLchar *const *, const GLint *);
static SrcFn origSource = nullptr;


// builds the code injected at the end of main() of a game fragment shader
static std::string patchFrag(const std::string &src) {
    size_t mainPos = src.find("void main");
    size_t last = src.rfind('}');
    if (mainPos == std::string::npos || last == std::string::npos || last < mainPos) return src;
    char code[1400];
    snprintf(code, sizeof code,
        "\n  { /*BRGFX_PATCHED*/\n"
        "    vec3 _c = gl_FragColor.rgb;\n"
        "    float _l = dot(_c, vec3(0.299,0.587,0.114));\n"
        "    _c *= 1.0 + %.4f * 0.0;\n"
        "    _c.r *= 1.0 + %.4f; _c.b *= 1.0 - %.4f;\n"
        "    _c = mix(vec3(_l), _c, %.4f);\n"
        "    _c = (_c - 0.5) * %.4f + 0.5;\n"
        "    float _s = 1.0 - smoothstep(0.0, 0.55, _l);\n"
        "    _c *= 1.0 - %.4f * _s;\n"
        "    _c += max(_c - 0.75, 0.0) * %.4f;\n"
        "    gl_FragColor.rgb = clamp(_c, 0.0, 1.0);\n"
        "  }\n",
        0.0f, g_shWarm, g_shWarm, g_shSat, g_shContrast, g_shShadow, g_shGlow);
    std::string out = src;
    out.insert(last, code);
    return out;
}
static bool wantPatch(const std::string &src, GLint type) {
    if (!g_patch || type != GL_FRAGMENT_SHADER) return false;
    if (src.find("gl_FragColor") == std::string::npos) return false;
    if (src.find("gl_FragData") != std::string::npos) return false;
    if (src.find("BRGFX_PATCHED") != std::string::npos) return false;
    if (src.find("sampler2D") == std::string::npos) return false;
    if (!g_require.empty()) {
        std::string low = src;
        std::transform(low.begin(), low.end(), low.begin(), ::tolower);
        if (low.find(g_require) == std::string::npos) return false;
    }
    return true;
}
static std::map<GLuint, std::string> g_origSrc;
static std::mutex g_mx;
typedef void (*CompFn)(GLuint);
static CompFn origCompile = nullptr;

static std::string shDir() { return "/storage/emulated/0/Android/data/" + g_pkg + "/files/brshaders"; }
static void mk(const std::string &p) { mkdir(p.c_str(), 0777); }

static void mySource(GLuint sh, GLsizei count, const GLchar *const *str, const GLint *len) {
    std::string src;
    for (GLsizei i = 0; i < count; i++) {
        if (!str[i]) continue;
        if (len && len[i] >= 0) src.append(str[i], len[i]); else src.append(str[i]);
    }
    uint32_t h = 2166136261u;
    for (unsigned char ch : src) { h ^= ch; h *= 16777619u; }
    GLint t = 0; glGetShaderiv(sh, GL_SHADER_TYPE, &t);
    char nm[64]; snprintf(nm, sizeof nm, "%08x_%s.glsl", h, t == GL_VERTEX_SHADER ? "vert" : "frag");
    std::string base = shDir();
    mk("/storage/emulated/0/Android/data/" + g_pkg + "/files");
    mk(base); mk(base + "/dump"); mk(base + "/override");
    std::string ov = readFile((base + "/override/" + nm).c_str());
    if (g_dump) {
        std::string dp = base + "/dump/" + nm;
        if (access(dp.c_str(), F_OK) != 0) {
            FILE *f = fopen(dp.c_str(), "w");
            if (f) { fwrite(src.data(), 1, src.size(), f); fclose(f); }
        }
    }
    if (!ov.empty()) {
        LOGI("override shader %s", nm);
        const GLchar *p = ov.c_str();
        origSource(sh, 1, &p, nullptr);
        return;
    }
    if (wantPatch(src, t)) {
        std::string np = patchFrag(src);
        { std::lock_guard<std::mutex> lk(g_mx); g_origSrc[sh] = src; }
        LOGI("patched fragment shader %s", nm);
        const GLchar *p = np.c_str();
        origSource(sh, 1, &p, nullptr);
        return;
    }
    const GLchar *p = src.c_str();
    origSource(sh, 1, &p, nullptr);
}

// if a patched shader fails to compile, fall back to the game's original source
static void myCompile(GLuint sh) {
    origCompile(sh);
    std::string orig;
    {
        std::lock_guard<std::mutex> lk(g_mx);
        auto it = g_origSrc.find(sh);
        if (it == g_origSrc.end()) return;
        orig = it->second;
        g_origSrc.erase(it);
    }
    GLint ok = 1; glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        LOGE("patched shader %u failed, restoring original", sh);
        const GLchar *p = orig.c_str();
        origSource(sh, 1, &p, nullptr);
        origCompile(sh);
    }
}

#if defined(__LP64__)
typedef Elf64_Rela Rel; typedef Elf64_Sym Sym;
#define R_SYM(i) ELF64_R_SYM(i)
#else
typedef Elf32_Rel Rel; typedef Elf32_Sym Sym;
#define R_SYM(i) ELF32_R_SYM(i)
#endif

static std::vector<uintptr_t> patchedSlots;

static void patchSlot(uintptr_t addr, void *fn) {
    for (auto a : patchedSlots) if (a == addr) return;
    long pg = sysconf(_SC_PAGESIZE);
    uintptr_t page = addr & ~(uintptr_t)(pg - 1);
    if (mprotect((void *)page, pg, PROT_READ | PROT_WRITE) != 0) return;
    *(void **)addr = fn;
    patchedSlots.push_back(addr);
    LOGI("hooked eglSwapBuffers slot %p", (void *)addr);
}

static int phdrCb(struct dl_phdr_info *info, size_t, void *) {
    const char *name = info->dlpi_name ? info->dlpi_name : "";
    if (strstr(name, "libEGL") || strstr(name, "brgfx") || strstr(name, "libGLES") || strstr(name, "libc.so")) return 0;
    uintptr_t base = info->dlpi_addr;
    const ElfW(Dyn) *dyn = nullptr;
    for (int i = 0; i < info->dlpi_phnum; i++)
        if (info->dlpi_phdr[i].p_type == PT_DYNAMIC) dyn = (const ElfW(Dyn) *)(base + info->dlpi_phdr[i].p_vaddr);
    if (!dyn) return 0;
    auto fix = [&](uintptr_t p) { return p < base ? base + p : p; };
    uintptr_t symtab = 0, strtab = 0, jmprel = 0, rel = 0;
    size_t pltsz = 0, relsz = 0;
    for (; dyn->d_tag != DT_NULL; dyn++) {
        switch (dyn->d_tag) {
            case DT_SYMTAB: symtab = fix(dyn->d_un.d_ptr); break;
            case DT_STRTAB: strtab = fix(dyn->d_un.d_ptr); break;
            case DT_JMPREL: jmprel = fix(dyn->d_un.d_ptr); break;
            case DT_PLTRELSZ: pltsz = dyn->d_un.d_val; break;
#if defined(__LP64__)
            case DT_RELA: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELASZ: relsz = dyn->d_un.d_val; break;
#else
            case DT_REL: rel = fix(dyn->d_un.d_ptr); break;
            case DT_RELSZ: relsz = dyn->d_un.d_val; break;
#endif
        }
    }
    if (!symtab || !strtab) return 0;
    auto scan = [&](uintptr_t tbl, size_t sz) {
        if (!tbl) return;
        Rel *r = (Rel *)tbl;
        for (size_t i = 0; i < sz / sizeof(Rel); i++) {
            uint32_t si = R_SYM(r[i].r_info);
            if (!si) continue;
            const char *nm = (const char *)strtab + ((Sym *)symtab)[si].st_name;
            if (g_post && strcmp(nm, "eglSwapBuffers") == 0) patchSlot(base + r[i].r_offset, (void *)mySwap);
            else if (origSource && strcmp(nm, "glShaderSource") == 0) patchSlot(base + r[i].r_offset, (void *)mySource);
            else if (origCompile && strcmp(nm, "glCompileShader") == 0) patchSlot(base + r[i].r_offset, (void *)myCompile);
        }
    };
    scan(jmprel, pltsz);
    scan(rel, relsz);
    return 0;
}

static void *hookThread(void *) {
    void *egl = dlopen("libEGL.so", RTLD_NOW);
    origSwap = egl ? (SwapFn)dlsym(egl, "eglSwapBuffers") : nullptr;
    if (!origSwap) { LOGE("no eglSwapBuffers"); return nullptr; }
    void *gl = dlopen("libGLESv2.so", RTLD_NOW);
    origSource = gl ? (SrcFn)dlsym(gl, "glShaderSource") : nullptr;
    origCompile = gl ? (CompFn)dlsym(gl, "glCompileShader") : nullptr;
    // game libs are loaded some time after process start -> keep scanning
    for (int i = 0; i < 600; i++) {
        dl_iterate_phdr(phdrCb, nullptr);
        usleep(i < 100 ? 200000 : 1000000);
    }
    return nullptr;
}

// ---------------------------------------------------------------- Zygisk module
class BRModule : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api *api, JNIEnv *env) override { this->api = api; this->env = env; }

    void preAppSpecialize(zygisk::AppSpecializeArgs *args) override {
        const char *nn = env->GetStringUTFChars(args->nice_name, nullptr);
        std::string name = nn ? nn : "";
        if (nn) env->ReleaseStringUTFChars(args->nice_name, nn);

        int fd = api->connectCompanion();
        if (fd >= 0) {
            uint32_t len = name.size();
            writeAll(fd, &len, 4);
            writeAll(fd, name.data(), len);
            uint8_t match = 0;
            if (readAll(fd, &match, 1) && match) {
                uint32_t cl = 0;
                if (readAll(fd, &cl, 4) && cl < 65536) {
                    std::string cfg(cl, 0);
                    if (readAll(fd, &cfg[0], cl)) {
                        auto kv = parseCfg(cfg, nullptr);
                        S.sharp = getf(kv, "sharpness", S.sharp);
                        S.bloom = getf(kv, "bloom", S.bloom);
                        S.contrast = getf(kv, "contrast", S.contrast);
                        S.saturation = getf(kv, "saturation", S.saturation);
                        S.vignette = getf(kv, "vignette", S.vignette);
                        S.grain = getf(kv, "grain", S.grain);
                        S.motionblur = getf(kv, "motion_blur", S.motionblur);
                        S.exposure = getf(kv, "exposure", S.exposure);
                        S.warmth = getf(kv, "warmth", S.warmth);
                        g_dump = getf(kv, "dump_shaders", 1) != 0;
                        g_post = getf(kv, "post_filter", 1) != 0;
                        g_patch = getf(kv, "shader_patch", 1) != 0;
                        g_shContrast = getf(kv, "sh_contrast", g_shContrast);
                        g_shSat = getf(kv, "sh_saturation", g_shSat);
                        g_shShadow = getf(kv, "sh_shadow_depth", g_shShadow);
                        g_shGlow = getf(kv, "sh_glow", g_shGlow);
                        g_shWarm = getf(kv, "sh_warmth", g_shWarm);
                        if (kv.count("patch_require")) g_require = kv["patch_require"];
                        g_pkg = name;
                        active = true;
                    }
                }
            }
            close(fd);
        }
        if (!active) api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!active) return;
        LOGI("attached to game process");
        pthread_t t;
        pthread_create(&t, nullptr, hookThread, nullptr);
        pthread_detach(t);
    }

private:
    zygisk::Api *api = nullptr;
    JNIEnv *env = nullptr;
    bool active = false;
};

REGISTER_ZYGISK_MODULE(BRModule)
REGISTER_ZYGISK_COMPANION(companion)
