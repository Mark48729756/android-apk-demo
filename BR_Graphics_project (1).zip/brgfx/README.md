# BR Graphics (Magisk + Zygisk)

1. Create a GitHub repo, upload this whole folder, open Actions -> build -> download artifact `BR_Graphics.zip`.
2. Magisk: enable Zygisk (Settings), install the zip from Modules, reboot.
3. Check the real package name: `pm list packages | grep -i -E "black|russia"` and fix `package=` in
   /data/adb/br_graphics/config.ini if needed.
4. Start the game. Log: `logcat -s BRGFX`  (should show "hooked eglSwapBuffers").
5. Tune /data/adb/br_graphics/config.ini, fully restart the game.

Settings to try if it looks wrong: motion_blur=0 (HUD ghosting), bloom=0.1, grain=0.
If the screen is black/flickers: enabled=0 and send me the `logcat -s BRGFX` output.

Optional files: see module/overlay/README.txt.

## Game shaders (real in-scene shaders)
Start the game once with dump_shaders=1. Shaders appear in
/sdcard/Android/data/<package>/files/brshaders/dump/. Copy a file to ../override/ (same name),
edit it, restart the game. Send the dump folder to Claude to get ready-made replacements.
